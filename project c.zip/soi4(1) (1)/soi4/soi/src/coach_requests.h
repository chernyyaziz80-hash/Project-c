#ifndef COACH_REQUESTS_H
#define COACH_REQUESTS_H

#include <glib.h>

typedef struct {
    char id_demande[50];        /* ID unique de la demande */
    char id_membre[50];         /* ID du membre qui demande */
    char nom_coach[100];        /* Nom du coach demandé */
    char date_seance[20];       /* Date de la séance (JJ/MM/YYYY) */
    int heure_seance;           /* Heure de la séance (0-23) */
    int minute_seance;          /* Minute de la séance (0-59) */
    char statut[20];            /* Statut : "en attente", "acceptée", "refusée" */
} CoachRequest;

/* Fonctions CRUD */
CoachRequest* create_coach_request(const char *id_membre, const char *nom_coach,
                                   const char *date_seance, int heure, int minute);
void add_coach_request_to_list(GList **list, CoachRequest *request);
void load_coach_requests_from_file(GList **list, const char *filepath);
void save_coach_requests_to_file(GList *list, const char *filepath);
void delete_coach_request_from_list(GList **list, const char *id_demande);
void free_coach_request(CoachRequest *request);
void free_coach_requests_list(GList *list);

#endif
