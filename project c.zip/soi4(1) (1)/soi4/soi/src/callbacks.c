#include <gtk/gtk.h>
#include <string.h>
#include "callbacks.h"
#include "support.h"
#include "interface.h"
#include "members.h"
#include "coach_requests.h"
#include "coaches.h"
#include "centres.h"
#include "centre_requests.h"
#include "event.h"
#include "fichier.h"
#include "cours_request.h"

/* ===== PROTOTYPES ===== */
void init_admin_event_stats_tree(GtkWidget *win);
void update_admin_taux_occupation(GtkWidget *win);
void update_membre_event_stats(GtkWidget *win);




#define GLADE_HOOKUP_OBJECT(component,widget,name) \
  g_object_set_data_full (G_OBJECT (component), name, \
    gtk_widget_ref (widget), (GDestroyNotify) gtk_widget_unref)

#define GLADE_HOOKUP_OBJECT_NO_REF(component,widget,name) \
  g_object_set_data (G_OBJECT (component), name, widget)
#include "equipment.h"
/* Prototype de la fonction FaceID */
GtkWidget *FACEID_SCANNER = NULL;
GtkWidget *FACEID_SPINNER = NULL;

gboolean faceid_animation_step(gpointer data);
gboolean close_scanner_and_show_popup(gpointer data);
gboolean show_faceid_popup(gpointer data);

extern GtkWidget *WIN_SIGN_UP;
extern GtkWidget *WIN_LOGIN;
extern GtkWidget *WIN_ADMIN;
extern GtkWidget *WIN_MEMBRE;
extern GtkWidget *WIN_ENTRAINEUR;

/* Variables globales pour la gestion des membres */
static GList *g_members = NULL;
static GtkWidget *WIN_AJOUT_MEMBRE = NULL;
static char g_members_filepath[256] = "../membres.txt";

/* Variables globales pour la gestion des demandes de coach privé */
static GList *g_coach_requests = NULL;
static char g_coach_requests_filepath[256] = "../demandes_coach.txt";
  

/* Variables globales pour la gestion des coaches */
static GList *g_coaches = NULL;
static char g_coaches_filepath[256] = "../coaches.txt";

/* Variables globales pour la gestion des centres */
static GList *g_centres = NULL;
static char g_centres_filepath[256] = "../centres.txt";

/* Variables globales pour la gestion des demandes d'inscription entraineur à centre */
static GList *g_centre_requests = NULL;
static char g_centre_requests_filepath[256] = "../demandes_centre.txt";
static char g_current_trainer_id[50] = "";  /* ID de l'entraineur connecté */

/* Variables globales pour la gestion des équipements */
GList *g_equipments = NULL;
GList *g_reservations = NULL;
char g_equipments_filepath[256] = "../equipements.txt";
char g_reservations_filepath[256] = "../reservations.txt";



/* ===========================
   EVENEMENTS : EDITION DIRECTE AU CLIC
   TreeView name = "clist_evenements"
   =========================== */

void on_evenement_cell_edited(GtkCellRendererText *renderer,
                              gchar *path_string,
                              gchar *new_text,
                              gpointer user_data)
{
    GtkWidget *tree = lookup_widget(WIN_ADMIN, "clist_evenements");
    if (!tree) return;

    GtkTreeModel *model = gtk_tree_view_get_model(GTK_TREE_VIEW(tree));
    GtkTreePath *path = gtk_tree_path_new_from_string(path_string);
    GtkTreeIter iter;

    if (gtk_tree_model_get_iter(model, &iter, path)) {
        int column = GPOINTER_TO_INT(user_data);

        /* Update TreeView directly */
        gtk_list_store_set(GTK_LIST_STORE(model), &iter, column, new_text, -1);
        g_print("✔ Cellule modifiée (col=%d) => %s\n", column, new_text);
    }

    gtk_tree_path_free(path);
}

gboolean on_clist_evenements_button_press_event(GtkWidget *tree,
                                                GdkEventButton *event,
                                                gpointer user_data)
{
    if (event->type != GDK_BUTTON_PRESS || event->button != 1)
        return FALSE;

    GtkTreePath *path = NULL;
    GtkTreeViewColumn *column = NULL;

    if (gtk_tree_view_get_path_at_pos(GTK_TREE_VIEW(tree),
                                      (gint)event->x,
                                      (gint)event->y,
                                      &path,
                                      &column,
                                      NULL,
                                      NULL))
    {
        /* Empêcher l'édition de l'ID (colonne 0) */
        int col_index = gtk_tree_view_column_get_sort_column_id(column);
        if (col_index != 0) {
            gtk_tree_view_set_cursor(GTK_TREE_VIEW(tree),
                                     path,
                                     column,
                                     TRUE);
        }

        gtk_tree_path_free(path);
        return TRUE;
    }

    return FALSE;
}


void init_evenements_treeview(void)
{
    GtkWidget *tree = lookup_widget(WIN_ADMIN, "clist_evenements");
    if (!tree) return;

    if (gtk_tree_view_get_model(GTK_TREE_VIEW(tree)) != NULL)
        return;

    GtkListStore *store = gtk_list_store_new(
        6,
        G_TYPE_STRING, /* ID */
        G_TYPE_STRING, /* Nom */
        G_TYPE_STRING, /* Coach */
        G_TYPE_STRING, /* Places */
        G_TYPE_STRING, /* Période */
        G_TYPE_STRING  /* Statut */
    );

    gtk_tree_view_set_model(GTK_TREE_VIEW(tree), GTK_TREE_MODEL(store));
    g_object_unref(store);

    const char *titles[6] = {"ID", "Nom", "Coach", "Places", "Période", "Statut"};

    for (int i = 0; i < 6; i++) {
        GtkCellRenderer *renderer = gtk_cell_renderer_text_new();

        if (i != 0) { // ID non modifiable
            g_object_set(renderer, "editable", TRUE, NULL);
            g_signal_connect(renderer, "edited",
                             G_CALLBACK(on_evenement_cell_edited),
                             GINT_TO_POINTER(i));
        }

        gtk_tree_view_insert_column_with_attributes(
            GTK_TREE_VIEW(tree),
            -1,
            titles[i],
            renderer,
            "text", i,
            NULL
        );
    }

    /* 🔥 CLIC = ÉDITION DIRECTE */
    g_signal_connect(tree, "button-press-event",
                     G_CALLBACK(on_clist_evenements_button_press_event),
                     NULL);

    g_print("✔ clist_evenements : édition sur TOUTES les colonnes activée\n");
}

const char* detect_role_from_password(const char *mdp)
{
    if (strncmp(mdp, "253", 3) == 0)
        return "entraineur";

    if (strncmp(mdp, "111", 3) == 0)
        return "membre";

    if (strncmp(mdp, "999", 3) == 0)
        return "admin";

    return NULL;  /* prefixe inconnu */
}

void
on_buttonOpenSignup_clicked(GtkButton *button, gpointer user_data)
{
    g_print("OUVERTURE SIGN UP...\n");

    g_print(">>> BOUTON SIGNUP CLIQUÉ\n");

    if (WIN_SIGN_UP == NULL)
        WIN_SIGN_UP = create_sign_up();

    gtk_widget_show(WIN_SIGN_UP);
}

 
void prefixe_role(char role[], char prefixe[])
{
    if (strcmp(role, "entraineur") == 0)
        strcpy(prefixe, "253");
    else if (strcmp(role, "membre") == 0)
        strcpy(prefixe, "111");
    else if (strcmp(role, "admin") == 0)
        strcpy(prefixe, "999");
    else
        strcpy(prefixe, "");
}

void
on_button_signup_clicked(GtkButton *button, gpointer user_data)
{
    GtkWidget *entry_id    = lookup_widget(GTK_WIDGET(button), "entryIdentifiantSignup");
    GtkWidget *entry_mdp   = lookup_widget(GTK_WIDGET(button), "entryMotdepasseSignup");
    GtkWidget *entry_conf  = lookup_widget(GTK_WIDGET(button), "entryConfirmSignup");
    GtkWidget *combo_role  = lookup_widget(GTK_WIDGET(button), "comboboxRole");
    GtkWidget *label_info  = lookup_widget(GTK_WIDGET(button), "labelMessageSignup");

    char id[20], mdp[20], conf[20], role[20], prefixe[10];

    strcpy(id, gtk_entry_get_text(GTK_ENTRY(entry_id)));
    strcpy(mdp, gtk_entry_get_text(GTK_ENTRY(entry_mdp)));
    strcpy(conf, gtk_entry_get_text(GTK_ENTRY(entry_conf)));

    /* 🔹 LIRE LE ROLE DE MANIÈRE SÉCURISÉE */
    gchar *r = gtk_combo_box_get_active_text(GTK_COMBO_BOX(combo_role));

    if (r == NULL) {
        gtk_label_set_text(GTK_LABEL(label_info), "Veuillez choisir un rôle !");
        return;
    }

    strcpy(role, r);
    g_free(r);

    /* 🔹 OBTENIR LE PRÉFIXE */
    prefixe_role(role, prefixe);

    /* 🔹 Vérification identifiant */
    if (strlen(id) > 8) {
        gtk_label_set_text(GTK_LABEL(label_info), "Identifiant max 8 caractères !");
        return;
    }

    /* 🔹 VALIDATION: Vérifier que l'identifiant existe dans le fichier approprié */
    int user_exists = 0;
    const char *filepath = NULL;
    
    if (strcmp(role, "membre") == 0) {
        filepath = "../membres.txt";
    } else if (strcmp(role, "entraineur") == 0) {
        filepath = "../coaches.txt";
    } else if (strcmp(role, "admin") == 0) {
        /* Admin n'a pas besoin de vérification (créé manuellement) */
        user_exists = 1;
    }

    /* Vérifier l'existence de l'utilisateur dans le fichier */
    if (filepath) {
        FILE *f = fopen(filepath, "r");
        if (!f) {
            /* Essayer le chemin sans ../ */
            filepath = (strcmp(role, "membre") == 0) ? "membres.txt" : "coaches.txt";
            f = fopen(filepath, "r");
        }
        
        if (f) {
            char line[256];
            while (fgets(line, sizeof(line), f)) {
                char file_id[50];
                sscanf(line, "%[^|]", file_id);  /* Lire jusqu'au premier | */
                
                if (strcmp(file_id, id) == 0) {
                    user_exists = 1;
                    break;
                }
            }
            fclose(f);
        }
    }

    if (!user_exists) {
        char msg[150];
        const char *type = (strcmp(role, "membre") == 0) ? "membre" : "entraineur";
        sprintf(msg, "❌ Cet identifiant n'existe pas dans la liste des %ss !", type);
        gtk_label_set_text(GTK_LABEL(label_info), msg);
        g_print("⚠ Signup refusé: %s n'existe pas dans %s\n", id, filepath);
        return;
    }

    /* 🔹 Vérification du mot de passe */
    if (strncmp(mdp, prefixe, 3) != 0) {
        char msg[100];
        sprintf(msg, "Le mot de passe doit commencer par %s", prefixe);
        gtk_label_set_text(GTK_LABEL(label_info), msg);
        return;
    }

    /* 🔹 Vérification confirmation */
    if (strcmp(mdp, conf) != 0) {
        gtk_label_set_text(GTK_LABEL(label_info), "Mot de passe ≠ confirmation !");
        return;
    }

    /* 🔹 Sauvegarder dans fichier */
    FILE *f = fopen("utilisateurs.txt", "a");
    if (f) {
        fprintf(f, "%s %s %s\n", id, mdp, role);
        fclose(f);
    }

    gtk_label_set_text(GTK_LABEL(label_info), "✔ Inscription réussie !");
    g_print("✔ Signup réussi: %s (%s)\n", id, role);

    /* 🔹 AFFICHER LOGIN APRÈS INSCRIPTION */
    gtk_widget_hide(WIN_SIGN_UP);
    gtk_widget_show(WIN_LOGIN);
}

/* Callback : Retour au login depuis signup */
void on_button_back_to_login_clicked(GtkButton *button, gpointer user_data)
{
    g_print(">>> BOUTON RETOUR AU LOGIN CLIQUÉ\n");

    /* Masquer la fenêtre de signup */
    gtk_widget_hide(WIN_SIGN_UP);

    /* Afficher la fenêtre de login */
    gtk_widget_show(WIN_LOGIN);
}

/* =======================================================
 *  🔐 LOGIN + ACCÈS AVEC CONTRÔLE
 * ======================================================= */
void
on_button_login_clicked(GtkWidget *objet_graphique, gpointer user_data)
{
    GtkWidget *input_id = lookup_widget(objet_graphique, "entryIdentifiant");
    GtkWidget *input_mdp = lookup_widget(objet_graphique, "entryMotdepasse");
    GtkWidget *output_label = lookup_widget(objet_graphique, "labelMessage_");

    char identifiant[50];
    char motdepasse[50];

    strcpy(identifiant, gtk_entry_get_text(GTK_ENTRY(input_id)));
    strcpy(motdepasse, gtk_entry_get_text(GTK_ENTRY(input_mdp)));

    /* 1️⃣ Vérification : identifiant enregistré ? */
    FILE *f = fopen("utilisateurs.txt", "r");
    if (!f) {
        gtk_label_set_text(GTK_LABEL(output_label), "⚠ Fichier utilisateurs manquant !");
        return;
    }

    char id_file[50], mdp_file[50], role_file[30];
    int trouve = 0;

    while (fscanf(f, "%s %s %s", id_file, mdp_file, role_file) != EOF)
    {
        if (strcmp(identifiant, id_file) == 0 &&
            strcmp(motdepasse, mdp_file) == 0)
        {
            trouve = 1;
            break;
        }
    }
    fclose(f);

    if (!trouve) {
        gtk_label_set_text(GTK_LABEL(output_label),
                           "❌ Identifiant ou mot de passe incorrect.");
        return;
    }

    /* 2️⃣ Détection automatique du rôle via préfixe mdp */
    const char *detected_role = detect_role_from_password(motdepasse);

    if (!detected_role) {
        gtk_label_set_text(GTK_LABEL(output_label),
                           "⚠ Mot de passe invalide (prefixe inconnu) !");
        return;
    }

    /* 3️⃣ Ouvrir la bonne fenêtre selon le rôle détecté */
    if (strcmp(detected_role, "admin") == 0)
    {
        if (!WIN_ADMIN) {
            WIN_ADMIN = create_login_admin();
            init_members_interface();
            init_evenements_treeview();


            
            /* Initialiser l'interface des équipements */
            GtkWidget *clist5 = lookup_widget(WIN_ADMIN, "clist5");
            if (clist5) {
                init_equipments_interface(clist5);
            }

            /* Initialiser l'historique des réservations (admin) */
            GtkWidget *treeview_admin_reservations = lookup_widget(WIN_ADMIN, "treeview_admin_reservations");
            if (treeview_admin_reservations) {
                init_admin_reservations_interface(treeview_admin_reservations);
            }
            
            /* Initialiser les statistiques des entraineurs */
            GtkWidget *treeview12 = lookup_widget(WIN_ADMIN, "treeview12");
            if (treeview12) {
                init_trainers_statistics_interface(treeview12);
            }
            
            /* Initialiser le TreeView des centres */
            GtkWidget *treeview8 = lookup_widget(WIN_ADMIN, "treeview8");
            if (treeview8) {
                init_centres_interface(treeview8);
            }
            
            /* Initialiser le TreeView des demandes d'inscription à centre */
            GtkWidget *treeview_centre_requests = lookup_widget(WIN_ADMIN, "treeview_centre_requests");
            if (treeview_centre_requests) {
                init_centre_requests_for_admin_interface(treeview_centre_requests);
            }
        }

        gtk_widget_show(WIN_ADMIN);
        init_admin_event_stats_tree(WIN_ADMIN);
        update_admin_taux_occupation(WIN_ADMIN);


        gtk_widget_hide(WIN_LOGIN);
    }
    else if (strcmp(detected_role, "entraineur") == 0)
    {
        if (!WIN_ENTRAINEUR)
            WIN_ENTRAINEUR = create_login_entraineurs();  // ✔ CORRECT

        /* Stocker l'ID de l'entraineur connecté */
        strncpy(g_current_trainer_id, identifiant, sizeof(g_current_trainer_id) - 1);
        g_current_trainer_id[sizeof(g_current_trainer_id) - 1] = '\0';
        g_print("✔ Entraineur connecté : %s\n", identifiant);

        /* Pré-remplir entry84 avec l'ID de l'entraineur */
        GtkWidget *entry84 = lookup_widget(WIN_ENTRAINEUR, "entry84");
        if (entry84) {
            gtk_entry_set_text(GTK_ENTRY(entry84), identifiant);
        }

        /* Initialiser le TreeView des demandes avec l'ID de l'entraineur */
        extern void init_trainer_centre_requests_on_startup(GtkWidget *tree, const char *trainer_id);
        GtkWidget *trainer_requests_tree = lookup_widget(WIN_ENTRAINEUR, "treeview_trainer_requests");
        if (trainer_requests_tree) {
            init_trainer_centre_requests_on_startup(trainer_requests_tree, identifiant);
        }

        /* Initialiser le TreeView des réservations de l'entraineur */
        extern void init_trainer_reservations_interface(GtkWidget *tree);
        GtkWidget *treeview_my_reservations = lookup_widget(WIN_ENTRAINEUR, "treeview_my_reservations");
        if (treeview_my_reservations) {
            init_trainer_reservations_interface(treeview_my_reservations);
        }
        
        /* Initialiser le TreeView des demandes de coach pour l'entraineur */
        GtkWidget *tableau_demandes_coach = lookup_widget(WIN_ENTRAINEUR, "tableau_demandes_coach_entraineur");
        if (tableau_demandes_coach) {
            init_coach_requests_for_trainers_interface(tableau_demandes_coach);
        }
        
        /* Initialiser le TreeView des centres disponibles pour inscription */
        GtkWidget *treeview10 = lookup_widget(WIN_ENTRAINEUR, "treeview10");
        if (treeview10) {
            init_centres_interface_for_trainers(treeview10);
        }
        
        /* Initialiser l'interface de réservation d'équipement pour l'entraineur */
        GtkWidget *fixed105 = lookup_widget(WIN_ENTRAINEUR, "fixed105");
        if (fixed105) {
            init_equipment_reservation_interface(fixed105);
        }

        gtk_widget_show(WIN_ENTRAINEUR);
        gtk_widget_hide(WIN_LOGIN);
    }
    else if (strcmp(detected_role, "membre") == 0)
    {
        if (!WIN_MEMBRE)
          WIN_MEMBRE = create_WindowMembre();



        /* Définir l'ID du membre connecté avec son username */
        set_current_member_id(identifiant);
        g_print("✔ Membre connecté : %s\n", identifiant);

        /* Initialiser le TreeView des notifications après définition de l'ID */
        GtkWidget *tableau_notifications = lookup_widget(WIN_MEMBRE, "tableau_notifications_coach");
        if (tableau_notifications) {
            init_coach_notifications_interface(tableau_notifications);
        }
        
        /* Initialiser le TreeView des coaches disponibles */
        GtkWidget *tableau_coaches = lookup_widget(WIN_MEMBRE, "tableau_des_coach_prive");
        if (tableau_coaches) {
            init_coaches_interface(tableau_coaches);
        }

        gtk_widget_show(WIN_MEMBRE);

        gtk_widget_hide(WIN_LOGIN);
    }  
}

/* =======================================================
 *  🟢 Ajout d’un événement dans le tableau admin
 * ======================================================= */
void on_buttonAjoutEvenement_clicked(GtkButton *button, gpointer user_data)
{
    GtkWidget *tree = lookup_widget(WIN_ADMIN, "clist_evenements");

    /* ---------------------------------------------------------
       1️⃣ AUTO-INITIALISATION DU TREEVIEW SI MODELE = NULL
       --------------------------------------------------------- */
    GtkListStore *store = GTK_LIST_STORE(
        gtk_tree_view_get_model(GTK_TREE_VIEW(tree))
    );

    if (store == NULL) {
        g_print("⚠ Store NULL → Création automatique...\n");

        store = gtk_list_store_new(6,
            G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,
            G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

        gtk_tree_view_set_model(GTK_TREE_VIEW(tree), GTK_TREE_MODEL(store));
        g_object_unref(store);

        GtkCellRenderer *r;
        const char *titles[6] = {"ID","Nom","Coach","Places","Période","Statut"};

        for (int i=0; i<6; i++) {
            r = gtk_cell_renderer_text_new();
            gtk_tree_view_insert_column_with_attributes(
                GTK_TREE_VIEW(tree), -1, titles[i], r, "text", i, NULL);
        }

        g_print("✔ Nouveau modèle TreeView créé.\n");
    }

    /* ---------------------------------------------------------
       2️⃣ LECTURE DES WIDGETS FORMULAIRE
       --------------------------------------------------------- */
    GtkWidget *win_form = gtk_widget_get_toplevel(GTK_WIDGET(button));

    GtkWidget *id        = lookup_widget(win_form, "entryIdEvenement");
    GtkWidget *nom       = lookup_widget(win_form, "comboNomEvenement");
    GtkWidget *coach     = lookup_widget(win_form, "comboCoach");
    GtkWidget *nbPlaces  = lookup_widget(win_form, "spinNbPlaces");
    GtkWidget *radioMatin     = lookup_widget(win_form, "radioMatin");
    GtkWidget *radioApresMidi = lookup_widget(win_form, "radioApresMidi");
    GtkWidget *radioSoir      = lookup_widget(win_form, "radioSoir");
    GtkWidget *checkOuvert    = lookup_widget(win_form, "checkOuvert");

    char idTxt[50], nomTxt[50], coachTxt[50], nbPlacesTxt[10];
    char per[20], statut[20];

    strcpy(idTxt, gtk_entry_get_text(GTK_ENTRY(id)));
    strcpy(nomTxt, gtk_combo_box_get_active_text(GTK_COMBO_BOX(nom)));
    strcpy(coachTxt, gtk_combo_box_get_active_text(GTK_COMBO_BOX(coach)));
    sprintf(nbPlacesTxt, "%d", gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(nbPlaces)));

    if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(radioMatin)))
        strcpy(per, "Matin");
    else if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(radioApresMidi)))
        strcpy(per, "Après-midi");
    else
        strcpy(per, "Soir");

    if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(checkOuvert)))
        strcpy(statut, "Ouvert");
    else
        strcpy(statut, "Fermé");

    /* ---------------------------------------------------------
       3️⃣ AJOUT DE LA LIGNE DANS LE STORE
       --------------------------------------------------------- */
    GtkTreeIter iter;
    gtk_list_store_append(store, &iter);

    gtk_list_store_set(store, &iter,
        0, idTxt,
        1, nomTxt,
        2, coachTxt,
        3, nbPlacesTxt,
        4, per,
        5, statut,
        -1);

    g_print("🎉 LIGNE AJOUTÉE À 100% DANS LE TREEVIEW 🎉\n");
    init_admin_event_stats_tree(WIN_ADMIN);
    update_admin_taux_occupation(WIN_ADMIN);


}


void
on_buttonOuvrirAjoutEvenement_clicked(GtkButton *button, gpointer user_data)
{
    if (WIN_AJOUT == NULL)
        WIN_AJOUT = create_l_ajout_d__un___v__nement_();

    gtk_widget_show(WIN_AJOUT);
}

void on_buttonSupprimerEvenement_clicked(GtkButton *button, gpointer user_data)
{
    g_print(">>> BOUTON SUPPRIMER EVENEMENT CLIQUÉ\n");

    if (!WIN_ADMIN) {
        g_warning("❌ WIN_ADMIN NULL");
        return;
    }

    GtkWidget *tree = lookup_widget(WIN_ADMIN, "clist_evenements");
    if (!tree) {
        g_warning("❌ TreeView clist_evenements introuvable");
        return;
    }

    GtkTreeSelection *selection =
        gtk_tree_view_get_selection(GTK_TREE_VIEW(tree));

    GtkTreeModel *model;
    GtkTreeIter iter;

    if (!gtk_tree_selection_get_selected(selection, &model, &iter)) {
        g_warning("⚠ Aucun événement sélectionné");
        return;
    }

    /* Récupérer l’ID juste pour affichage */
    gchar *id_event = NULL;
    gtk_tree_model_get(model, &iter, 0, &id_event, -1);

    GtkWidget *dialog = gtk_message_dialog_new(
        GTK_WINDOW(WIN_ADMIN),
        GTK_DIALOG_MODAL,
        GTK_MESSAGE_QUESTION,
        GTK_BUTTONS_YES_NO,
        "Supprimer cet événement ?"
    );

    int rep = gtk_dialog_run(GTK_DIALOG(dialog));
    gtk_widget_destroy(dialog);

    if (rep == GTK_RESPONSE_YES) {
        gtk_list_store_remove(GTK_LIST_STORE(model), &iter);
        g_print("✔ Événement supprimé : %s\n", id_event);
    }

    g_free(id_event);
}

void on_buttonRechercherId_clicked(GtkButton *button, gpointer user_data)
{
    g_print(">>> BOUTON RECHERCHER EVENEMENT CLIQUÉ\n");

    /* 1️⃣ Récupérer l'entry */
    GtkWidget *entry = lookup_widget(WIN_ADMIN, "entryRechercheId");
    if (!entry) {
        g_warning("❌ entryRechercheId introuvable");
        return;
    }

    const char *idSearch = gtk_entry_get_text(GTK_ENTRY(entry));
    if (strlen(idSearch) == 0) {
        g_warning("⚠ Champ ID vide");
        return;
    }

    /* 2️⃣ Récupérer le TreeView */
    GtkWidget *tree = lookup_widget(WIN_ADMIN, "clist_evenements");
    if (!tree) {
        g_warning("❌ clist_evenements introuvable");
        return;
    }

    GtkTreeModel *model = gtk_tree_view_get_model(GTK_TREE_VIEW(tree));
    GtkTreeSelection *selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(tree));

    gtk_tree_selection_unselect_all(selection);

    GtkTreeIter iter;
    gboolean found = FALSE;

    /* 3️⃣ Parcourir toutes les lignes */
    if (gtk_tree_model_get_iter_first(model, &iter)) {
        do {
            gchar *idRow = NULL;
            gtk_tree_model_get(model, &iter, 0, &idRow, -1); // colonne 0 = ID

            if (idRow && strcmp(idRow, idSearch) == 0) {

                GtkTreePath *path = gtk_tree_model_get_path(model, &iter);

                /* 🔴 OBLIGATOIRE POUR COLORATION */
                gtk_widget_grab_focus(tree);
                gtk_tree_view_set_cursor(
                    GTK_TREE_VIEW(tree),
                    path,
                    NULL,
                    FALSE
                );
                gtk_tree_selection_select_path(selection, path);

                gtk_tree_view_scroll_to_cell(
                    GTK_TREE_VIEW(tree),
                    path,
                    NULL,
                    TRUE,
                    0.5,
                    0.5
                );

                gtk_tree_path_free(path);

                g_print("✔ EVENEMENT TROUVÉ ET COLORÉ : %s\n", idRow);
                found = TRUE;
                g_free(idRow);
                break;
            }

            if (idRow)
                g_free(idRow);

        } while (gtk_tree_model_iter_next(model, &iter));
    }

    if (!found)
        g_warning("❌ Aucun événement trouvé avec cet ID");
}


void on_buttonResetRecherche_clicked(GtkButton *button, gpointer user_data)
{
    g_print(">>> RÉINITIALISATION DE LA RECHERCHE\n");

    /* 1️⃣ Effacer l'entry */
    GtkWidget *entry = lookup_widget(WIN_ADMIN, "entryRechercheId");
    if (entry)
        gtk_entry_set_text(GTK_ENTRY(entry), "");

    /* 2️⃣ TreeView */
    GtkWidget *tree = lookup_widget(WIN_ADMIN, "clist_evenements");
    if (!tree) {
        g_warning("❌ clist_evenements introuvable");
        return;
    }

    GtkTreeSelection *selection =
        gtk_tree_view_get_selection(GTK_TREE_VIEW(tree));
    gtk_tree_selection_unselect_all(selection);

    /* 3️⃣ Scroll en haut */
    GtkTreePath *top = gtk_tree_path_new_from_string("0");
    gtk_tree_view_scroll_to_cell(
        GTK_TREE_VIEW(tree),
        top,
        NULL,
        TRUE,
        0,
        0
    );
    gtk_tree_path_free(top);

    g_print("✔ Recherche réinitialisée\n");
}
void update_admin_taux_occupation(GtkWidget *win)
{
    GtkWidget *label = lookup_widget(win, "labelTauxOccupation");
    if (!label) return;

    GtkWidget *tree = lookup_widget(win, "clist_evenements");
    if (!tree) return;

    GtkTreeModel *model = gtk_tree_view_get_model(GTK_TREE_VIEW(tree));
    if (!model) return;

    GtkTreeIter iter;
    gboolean valid;

    int totalPlaces = 0;
    int eventsOuverts = 0;

    valid = gtk_tree_model_get_iter_first(model, &iter);
    while (valid) {
        gchar *places = NULL;
        gchar *statut = NULL;

        gtk_tree_model_get(model, &iter,
                           3, &places,   // colonne Places
                           5, &statut,   // colonne Statut
                           -1);

        if (places)
            totalPlaces += atoi(places);

        if (statut && strcmp(statut, "Ouvert") == 0)
            eventsOuverts++;

        g_free(places);
        g_free(statut);

        valid = gtk_tree_model_iter_next(model, &iter);
    }

    /* Approximation simple */
    int placesUtilisees = eventsOuverts * 10;

    int taux = 0;
    if (totalPlaces > 0)
        taux = (placesUtilisees * 100) / totalPlaces;

    char buf[100];
    sprintf(buf, "Taux d’occupation : %d %%", taux);
    gtk_label_set_text(GTK_LABEL(label), buf);
}

void init_admin_event_stats_tree(GtkWidget *win)
{
    GtkWidget *treeStats = lookup_widget(win, "treeviewStatsEvents");
    if (!treeStats) return;

    GtkListStore *store;
    GtkTreeModel *model = gtk_tree_view_get_model(GTK_TREE_VIEW(treeStats));

    /* Création du modèle si nécessaire */
    if (!model) {
        store = gtk_list_store_new(
            2,
            G_TYPE_STRING,   // Statistique
            G_TYPE_STRING    // Valeur
        );

        gtk_tree_view_set_model(GTK_TREE_VIEW(treeStats), GTK_TREE_MODEL(store));
        g_object_unref(store);

        GtkCellRenderer *renderer;
        const char *titles[] = {"Statistique", "Valeur"};

        for (int i = 0; i < 2; i++) {
            renderer = gtk_cell_renderer_text_new();
            gtk_tree_view_insert_column_with_attributes(
                GTK_TREE_VIEW(treeStats),
                -1,
                titles[i],
                renderer,
                "text", i,
                NULL
            );
        }
    } else {
        store = GTK_LIST_STORE(model);
        gtk_list_store_clear(store);
    }

    /* === CALCUL DES STATISTIQUES À PARTIR DES ÉVÉNEMENTS === */
    GtkWidget *treeEvents = lookup_widget(win, "clist_evenements");
    if (!treeEvents) return;

    GtkTreeModel *eventModel = gtk_tree_view_get_model(GTK_TREE_VIEW(treeEvents));
    if (!eventModel) return;

    GtkTreeIter iter;
    gboolean valid;

    int total = 0;
    int ouverts = 0;
    int fermes = 0;
    int totalPlaces = 0;

    valid = gtk_tree_model_get_iter_first(eventModel, &iter);
    while (valid) {
        gchar *statut = NULL;
        gchar *places = NULL;

        gtk_tree_model_get(eventModel, &iter,
                           3, &places,   // colonne Places
                           5, &statut,   // colonne Statut
                           -1);

        total++;

        if (statut && strcmp(statut, "Ouvert") == 0)
            ouverts++;
        else
            fermes++;

        if (places)
            totalPlaces += atoi(places);

        g_free(statut);
        g_free(places);

        valid = gtk_tree_model_iter_next(eventModel, &iter);
    }

    /* === REMPLISSAGE DE LA TREEVIEW STATS === */
    GtkTreeIter it;

    char buf[50];

    gtk_list_store_append(store, &it);
    gtk_list_store_set(store, &it,
        0, "Total événements",
        1, (sprintf(buf, "%d", total), buf),
        -1);

    gtk_list_store_append(store, &it);
    gtk_list_store_set(store, &it,
        0, "Événements ouverts",
        1, (sprintf(buf, "%d", ouverts), buf),
        -1);

    gtk_list_store_append(store, &it);
    gtk_list_store_set(store, &it,
        0, "Événements fermés",
        1, (sprintf(buf, "%d", fermes), buf),
        -1);

    gtk_list_store_append(store, &it);
    gtk_list_store_set(store, &it,
        0, "Total places",
        1, (sprintf(buf, "%d", totalPlaces), buf),
        -1);
}


void remplir_treeviewAllEvents(GtkWidget *tree)
{
    if (!tree) {
        g_warning("⚠️ treeviewAllEvents introuvable !");
        return;
    }

    GtkListStore *store;
    GtkTreeModel *model = gtk_tree_view_get_model(GTK_TREE_VIEW(tree));

    /* Création du modèle + colonnes si première fois */
    if (model == NULL)
    {
        store = gtk_list_store_new(
            3,
            G_TYPE_STRING,   // 0 : ID
            G_TYPE_STRING,   // 1 : Nom
            G_TYPE_STRING    // 2 : Date
        );

        gtk_tree_view_set_model(GTK_TREE_VIEW(tree), GTK_TREE_MODEL(store));
        g_object_unref(store);

        GtkCellRenderer *renderer;
        const char *titles[3] = {"ID", "Nom", "Date"};

        for (int i = 0; i < 3; i++) {
            renderer = gtk_cell_renderer_text_new();
            gtk_tree_view_insert_column_with_attributes(
                GTK_TREE_VIEW(tree),
                -1,
                titles[i],
                renderer,
                "text", i,
                NULL
            );
        }
    }
    else {
        store = GTK_LIST_STORE(model);
        gtk_list_store_clear(store);   // vider avant de remplir
    }

    /* ====== DONNÉES DE TEST ====== */
    GtkTreeIter iter;

    gtk_list_store_append(store, &iter);
    gtk_list_store_set(store, &iter,
                       0, "EV001",
                       1, "Yoga Matin",
                       2, "06/12/2025",
                       -1);

    gtk_list_store_append(store, &iter);
    gtk_list_store_set(store, &iter,
                       0, "EV002",
                       1, "Boxe Avancée",
                       2, "07/12/2025",
                       -1);

    gtk_list_store_append(store, &iter);
    gtk_list_store_set(store, &iter,
                       0, "EV003",
                       1, "Zumba Soir",
                       2, "08/12/2025",
                       -1);

    g_print("✔ TreeView ALL EVENTS rempli (mode test)\n");
}
void creer_event_requests_test(void)
{
    GList *list = NULL;

    EventRequest *r1 = create_event_request(
        "ER001",
        "M001",
        "EV001",
        "Yoga Matin",
        "06/12/2025",
        "en attente"
    );

    EventRequest *r2 = create_event_request(
        "ER002",
        "M001",
        "EV002",
        "Boxe Avancée",
        "07/12/2025",
        "acceptée"
    );

    EventRequest *r3 = create_event_request(
        "ER003",
        "M002",
        "EV003",
        "Zumba Soir",
        "08/12/2025",
        "refusée"
    );

    list = g_list_append(list, r1);
    list = g_list_append(list, r2);
    list = g_list_append(list, r3);

    save_event_requests_to_file(list, "event_requests.txt");
    free_event_requests_list(list);

    g_print("DONNEES DE TEST EVENEMENTS CREEES\n");
}

void on_WindowMembre_show(GtkWidget *win, gpointer user_data)
{
    GtkWidget *treeEvents = lookup_widget(win, "treeviewAllEvents");
    remplir_treeviewAllEvents(treeEvents);

    GtkWidget *treeReq  = lookup_widget(win, "treeviewEventsMembre");
    GtkWidget *entryID  = lookup_widget(win, "entryIdMembre");

    const char *idMembre = gtk_entry_get_text(GTK_ENTRY(entryID));
    if (idMembre && strlen(idMembre) > 0) {
        init_membre_event_requests_interface(treeReq, idMembre);

        /* 🔥 AJOUT IMPORTANT : stats membre */
        update_membre_event_stats(win);
    }

    /* ===== INITIALISATION HScale ===== */
    GtkWidget *hscale = lookup_widget(win, "hscaleStatutDemande");
    GtkWidget *label  = lookup_widget(win, "labelStatutDemande");

    if (hscale) {
        gtk_range_set_range(GTK_RANGE(hscale), 0, 2);
        gtk_range_set_value(GTK_RANGE(hscale), 0);
        gtk_widget_set_sensitive(hscale, FALSE);
    }

    if (label) {
        gtk_label_set_text(GTK_LABEL(label), "Aucune demande envoyée");
    }
    GtkWidget *treeCours = lookup_widget(win, "treeviewchoix");
    if (treeCours) {
        init_cours_choix_interface(treeCours);
    }

}


void on_buttonInscrireEvenement_clicked(GtkButton *button, gpointer user_data)
{
    g_print(">>> BOUTON S'INSCRIRE À UN ÉVÉNEMENT CLIQUÉ\n");

    GtkWidget *win = gtk_widget_get_toplevel(GTK_WIDGET(button));

    GtkWidget *treeEvents = lookup_widget(win, "treeviewAllEvents");
    GtkWidget *treeReq    = lookup_widget(win, "treeviewEventsMembre");
    GtkWidget *entryID    = lookup_widget(win, "entryIdMembre");

    if (!treeEvents || !treeReq || !entryID) {
        g_warning("❌ Widgets introuvables");
        return;
    }

    const char *idMembre = gtk_entry_get_text(GTK_ENTRY(entryID));
    if (!idMembre || strlen(idMembre) == 0) {
        GtkWidget *d = gtk_message_dialog_new(
            GTK_WINDOW(win),
            GTK_DIALOG_MODAL,
            GTK_MESSAGE_ERROR,
            GTK_BUTTONS_OK,
            "Veuillez entrer votre ID de membre !"
        );
        g_signal_connect(d, "response", G_CALLBACK(gtk_widget_destroy), NULL);
        gtk_widget_show(d);
        return;
    }

    GtkTreeSelection *selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(treeEvents));
    GtkTreeModel *modelEvents;
    GtkTreeIter iterEvents;

    if (!gtk_tree_selection_get_selected(selection, &modelEvents, &iterEvents)) {
        GtkWidget *d = gtk_message_dialog_new(
            GTK_WINDOW(win),
            GTK_DIALOG_MODAL,
            GTK_MESSAGE_ERROR,
            GTK_BUTTONS_OK,
            "Veuillez sélectionner un événement !"
        );
        g_signal_connect(d, "response", G_CALLBACK(gtk_widget_destroy), NULL);
        gtk_widget_show(d);
        return;
    }

    gchar *id_evt = NULL, *nom_evt = NULL, *date_evt = NULL;
    gtk_tree_model_get(modelEvents, &iterEvents,
                       0, &id_evt,
                       1, &nom_evt,
                       2, &date_evt,
                       -1);

    GList *event_requests = load_event_requests_from_file("event_requests.txt");

    char id_demande[40];
    snprintf(id_demande, sizeof(id_demande), "ER%ld", time(NULL));

    EventRequest *req = create_event_request(
        id_demande,
        idMembre,
        id_evt,
        nom_evt,
        date_evt,
        "en attente"
    );

    event_requests = g_list_append(event_requests, req);
    save_event_requests_to_file(event_requests, "event_requests.txt");
    free_event_requests_list(event_requests);

    GtkListStore *storeReq;
    GtkTreeModel *modelReq = gtk_tree_view_get_model(GTK_TREE_VIEW(treeReq));

    if (!modelReq) {
        storeReq = gtk_list_store_new(3, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
        gtk_tree_view_set_model(GTK_TREE_VIEW(treeReq), GTK_TREE_MODEL(storeReq));
        g_object_unref(storeReq);

        const char *titles[] = {"Événement", "Date", "Statut"};
        for (int i = 0; i < 3; i++) {
            GtkCellRenderer *renderer = gtk_cell_renderer_text_new();
            gtk_tree_view_insert_column_with_attributes(
                GTK_TREE_VIEW(treeReq), -1, titles[i], renderer, "text", i, NULL
            );
        }
    } else {
        storeReq = GTK_LIST_STORE(modelReq);
    }

    GtkTreeIter iterReq;
    gtk_list_store_append(storeReq, &iterReq);
    gtk_list_store_set(storeReq, &iterReq,
                       0, nom_evt,
                       1, date_evt,
                       2, "⏳ En attente",
                       -1);

    /* ===== STATUT VISUEL : EN ATTENTE ===== */
    GtkWidget *hscale = lookup_widget(win, "hscaleStatutDemande");
    GtkWidget *label  = lookup_widget(win, "labelStatutDemande");

    if (hscale) {
        gtk_range_set_value(GTK_RANGE(hscale), 1);
        gtk_widget_queue_draw(hscale);
    }

    if (label) {
        gtk_label_set_text(GTK_LABEL(label),
            "⏳ Demande envoyée – en attente de validation");
    }

    GtkWidget *ok = gtk_message_dialog_new(
        GTK_WINDOW(win),
        GTK_DIALOG_MODAL,
        GTK_MESSAGE_INFO,
        GTK_BUTTONS_OK,
        "Demande envoyée avec succès !"
    );
    g_signal_connect(ok, "response", G_CALLBACK(gtk_widget_destroy), NULL);
    gtk_widget_show(ok);

    g_free(id_evt);
    g_free(nom_evt);
    g_free(date_evt);

    g_print("✔ Inscription créée (%s)\n", id_demande);
    update_membre_event_stats(win);

}

void init_membre_event_requests_interface(GtkWidget *tree, const char *idMembre)
{
    if (!tree)
        return;

    GtkListStore *store;
    GtkTreeModel *model = gtk_tree_view_get_model(GTK_TREE_VIEW(tree));

    /* Création du modèle si première fois */
    if (!model) {
        store = gtk_list_store_new(3,
            G_TYPE_STRING,
            G_TYPE_STRING,
            G_TYPE_STRING
        );

        gtk_tree_view_set_model(GTK_TREE_VIEW(tree), GTK_TREE_MODEL(store));
        g_object_unref(store);

        const char *titles[] = {"Événement", "Date", "Statut"};
        for (int i = 0; i < 3; i++) {
            GtkCellRenderer *renderer = gtk_cell_renderer_text_new();
            gtk_tree_view_insert_column_with_attributes(
                GTK_TREE_VIEW(tree),
                -1,
                titles[i],
                renderer,
                "text", i,
                NULL
            );
        }
    } else {
        store = GTK_LIST_STORE(model);
    }

    /* === AJOUT DIRECT D’UNE LIGNE (TEST GARANTI) === */
    GtkTreeIter iter;
    gtk_list_store_append(store, &iter);
    gtk_list_store_set(store, &iter,
        0, "Yoga Matin",
        1, "06/12/2025",
        2, "⏳ En attente",
        -1);
}
void update_membre_event_stats(GtkWidget *win)
{
    GtkWidget *tree = lookup_widget(win, "treeviewEventsMembre");
    if (!tree) return;

    GtkTreeModel *model = gtk_tree_view_get_model(GTK_TREE_VIEW(tree));
    if (!model) return;

    GtkTreeIter iter;
    gboolean valid;

    int total = 0;
    int pending = 0;
    int accepted = 0;
    int refused = 0;

    valid = gtk_tree_model_get_iter_first(model, &iter);
    while (valid) {
        gchar *statut = NULL;

        gtk_tree_model_get(model, &iter,
                           2, &statut,   // colonne Statut
                           -1);

        total++;

        if (statut) {
            if (g_str_has_prefix(statut, "⏳"))
                pending++;
            else if (g_str_has_prefix(statut, "✔"))
                accepted++;
            else if (g_str_has_prefix(statut, "✗"))
                refused++;
        }

        g_free(statut);
        valid = gtk_tree_model_iter_next(model, &iter);
    }

    char buf[100];

    GtkWidget *l1 = lookup_widget(win, "labelMembreTotal");
    GtkWidget *l2 = lookup_widget(win, "labelMembrePending");
    GtkWidget *l3 = lookup_widget(win, "labelMembreAccepted");
    GtkWidget *l4 = lookup_widget(win, "labelMembreRefused");

    if (l1) {
        sprintf(buf, "📌 Mes demandes : %d", total);
        gtk_label_set_text(GTK_LABEL(l1), buf);
    }

    if (l2) {
        sprintf(buf, "⏳ En attente : %d", pending);
        gtk_label_set_text(GTK_LABEL(l2), buf);
    }

    if (l3) {
        sprintf(buf, "🟢 Acceptées : %d", accepted);
        gtk_label_set_text(GTK_LABEL(l3), buf);
    }

    if (l4) {
        sprintf(buf, "🔴 Refusées : %d", refused);
        gtk_label_set_text(GTK_LABEL(l4), buf);
    }
}


void show_faceid_scanner()
{
    FACEID_SCANNER = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(FACEID_SCANNER), "FaceID");
    gtk_window_set_default_size(GTK_WINDOW(FACEID_SCANNER), 260, 130);
    gtk_window_set_modal(GTK_WINDOW(FACEID_SCANNER), TRUE);
    gtk_window_set_position(GTK_WINDOW(FACEID_SCANNER), GTK_WIN_POS_CENTER);
    gtk_window_set_decorated(GTK_WINDOW(FACEID_SCANNER), FALSE);

    GtkWidget *fixed = gtk_fixed_new();
    gtk_container_add(GTK_CONTAINER(FACEID_SCANNER), fixed);

    /* Spinner : cercle animé */
    FACEID_SPINNER = gtk_label_new("🔄");
    gtk_fixed_put(GTK_FIXED(fixed), FACEID_SPINNER, 110, 20);

    GtkWidget *label = gtk_label_new("Scanning du visage...");
    gtk_fixed_put(GTK_FIXED(fixed), label, 60, 70);

    gtk_widget_show_all(FACEID_SCANNER);

    /* lancer l’animation */
    g_timeout_add(120, faceid_animation_step, NULL);
}
const char *frames[] = { "🔄", "↻", "⟳", "⤾" };
int current_frame = 0;

gboolean faceid_animation_step(gpointer data)
{
    if (FACEID_SPINNER == NULL)
        return FALSE;

    gtk_label_set_text(GTK_LABEL(FACEID_SPINNER), frames[current_frame]);

    current_frame = (current_frame + 1) % 4;

    return TRUE; // continue l'animation
}
gboolean close_scanner_and_show_popup(gpointer data)
{
    if (FACEID_SCANNER != NULL) {
        gtk_widget_destroy(FACEID_SCANNER);
        FACEID_SCANNER = NULL;
        FACEID_SPINNER = NULL;
    }

    show_faceid_popup(NULL);
    return FALSE;
}

gboolean show_faceid_popup(gpointer data)
{
    GtkWidget *dialog = gtk_message_dialog_new(
        NULL,
        GTK_DIALOG_MODAL,
        GTK_MESSAGE_INFO,
        GTK_BUTTONS_OK,
        "😁 Fonction FaceID non disponible pour le moment.\n"
        "Elle sera ajoutée bientôt !"
    );

    gtk_window_set_title(GTK_WINDOW(dialog), "FaceID");
    gtk_dialog_run(GTK_DIALOG(dialog));
    gtk_widget_destroy(dialog);

    return FALSE;
}
void on_button_faceid_clicked(GtkButton *button, gpointer user_data)
{
    show_faceid_scanner();

    // 2 secondes d'animation
    g_timeout_add(2000, close_scanner_and_show_popup, NULL);
}

/* ========================================================
 *  GESTION DES MEMBRES
 * ======================================================== */

/* Initialiser le TreeView des membres au démarrage */
void init_members_interface(void)
{
    GtkWidget *tree = lookup_widget(WIN_ADMIN, "treeview11");
    if (!tree) {
        g_warning("⚠️ TreeView 'treeview11' introuvable !");
        return;
    }

    /* Vider le TreeView avant de le remplir */
    GtkTreeModel *model = gtk_tree_view_get_model(GTK_TREE_VIEW(tree));
    if (model) {
        gtk_list_store_clear(GTK_LIST_STORE(model));
    } else {
        /* Initialiser le TreeView si le modèle n'existe pas */
        init_members_treeview(tree);
    }

    /* Charger les membres depuis le fichier */
    /* Essayer d'abord le chemin relatif au répertoire courant */
    FILE *test = fopen(g_members_filepath, "r");
    if (!test) {
        strcpy(g_members_filepath, "../membres.txt");
        test = fopen(g_members_filepath, "r");
    }
    if (test) fclose(test);
    
    g_print("📂 Chemin du fichier: %s\n", g_members_filepath);
    
    g_members = load_members_from_file(g_members_filepath);

    /* Remplir le TreeView */
    if (g_members) {
        populate_treeview_from_list(tree, g_members);
        g_print("✔ %d membres chargés\n", g_list_length(g_members));
    } else {
        g_print("⚠ Aucun membre trouvé ou fichier vide\n");
    }
}

/* Bouton AJOUTER - Affiche le formulaire d'ajout */
void on_button22_clicked(GtkButton *button, gpointer user_data)
{
    g_print(">>> BOUTON AJOUTER CLIQUÉ\n");

    if (WIN_AJOUT_MEMBRE == NULL) {
        g_print("Création du formulaire...\n");
        WIN_AJOUT_MEMBRE = create_ajouter_un_membre();
        if (WIN_AJOUT_MEMBRE) {
            g_print("✔ Formulaire créé avec succès\n");
        } else {
            g_warning("❌ Erreur: Formulaire NULL\n");
            return;
        }
    }

    if (WIN_AJOUT_MEMBRE) {
        gtk_window_present(GTK_WINDOW(WIN_AJOUT_MEMBRE));
        gtk_widget_show_all(WIN_AJOUT_MEMBRE);
        g_print("✔ Formulaire affiché\n");
    }
}

/* Bouton MODIFIER - Permet l'édition inline */
void on_button23_clicked(GtkButton *button, gpointer user_data)
{
    g_print(">>> BOUTON MODIFIER CLIQUÉ\n");

    GtkWidget *tree = lookup_widget(WIN_ADMIN, "treeview11");
    if (!tree) return;

    GtkTreeSelection *selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(tree));
    GtkTreeIter iter;
    GtkTreeModel *model;

    if (gtk_tree_selection_get_selected(selection, &model, &iter)) {
        /* Rendre les cellules éditables */
        GList *columns = gtk_tree_view_get_columns(GTK_TREE_VIEW(tree));
        for (int i = 1; i < 6; i++) {
            GtkTreeViewColumn *col = g_list_nth_data(columns, i);
            if (col) {
                GList *cells = gtk_tree_view_column_get_cell_renderers(col);
                GtkCellRenderer *renderer = cells->data;
                g_object_set(renderer, "editable", TRUE, NULL);
                g_list_free(cells);
            }
        }
        g_list_free(columns);

        g_print("✔ Mode édition activé\n");
    } else {
        g_warning("⚠ Aucune ligne sélectionnée");
    }
}

/* Bouton SUPPRIMER - Supprime la ligne sélectionnée */
void on_button24_clicked(GtkButton *button, gpointer user_data)
{
    g_print(">>> BOUTON SUPPRIMER CLIQUÉ\n");

    GtkWidget *tree = lookup_widget(WIN_ADMIN, "treeview11");
    if (!tree) {
        g_warning("❌ TreeView introuvable");
        return;
    }

    GtkTreeSelection *selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(tree));
    if (!selection) {
        g_warning("❌ Sélection introuvable");
        return;
    }

    GtkTreeIter iter;
    GtkTreeModel *model;

    if (gtk_tree_selection_get_selected(selection, &model, &iter)) {
        gchar *username_str = NULL;
        gtk_tree_model_get(model, &iter, 0, &username_str, -1);

        if (!username_str) {
            g_warning("❌ Username NULL");
            return;
        }

        g_print("Suppression du membre: %s\n", username_str);

        /* Confirmation */
        GtkWidget *dialog = gtk_message_dialog_new(
            GTK_WINDOW(WIN_ADMIN),
            GTK_DIALOG_MODAL,
            GTK_MESSAGE_QUESTION,
            GTK_BUTTONS_YES_NO,
            "Êtes-vous sûr de vouloir supprimer ce membre ?"
        );

        int response = gtk_dialog_run(GTK_DIALOG(dialog));
        gtk_widget_destroy(dialog);

        if (response == GTK_RESPONSE_YES) {
            /* Supprimer de la liste */
            delete_member_from_list(&g_members, username_str);

            /* Supprimer du TreeView */
            gtk_list_store_remove(GTK_LIST_STORE(model), &iter);

            /* Sauvegarder */
            save_members_to_file(g_members, g_members_filepath);

            g_print("✔ Membre supprimé\n");
        }

        g_free(username_str);
    } else {
        g_warning("⚠ Aucune ligne sélectionnée");
    }
}

/* Bouton RECHERCHER - Filtre les résultats */
void on_button25_clicked(GtkButton *button, gpointer user_data)
{
    g_print(">>> BOUTON RECHERCHER CLIQUÉ\n");

    GtkWidget *entry_search = lookup_widget(WIN_ADMIN, "entry8");
    GtkWidget *combo_filter = lookup_widget(WIN_ADMIN, "comboboxentry6");
    GtkWidget *tree = lookup_widget(WIN_ADMIN, "treeview11");

    if (!entry_search || !combo_filter || !tree) {
        g_warning("⚠ Widgets manquants");
        return;
    }

    const char *search_text = gtk_entry_get_text(GTK_ENTRY(entry_search));
    gchar *filter_type = gtk_combo_box_get_active_text(GTK_COMBO_BOX(combo_filter));

    if (!filter_type || strlen(search_text) == 0) {
        /* Afficher tous les membres */
        clear_treeview(tree);
        populate_treeview_from_list(tree, g_members);
        g_print("✔ Affichage complet\n");
        return;
    }

    /* Filtrer selon le type sélectionné */
    clear_treeview(tree);

    GtkTreeModel *model = gtk_tree_view_get_model(GTK_TREE_VIEW(tree));
    GtkListStore *store = GTK_LIST_STORE(model);
    GtkTreeIter iter;
    char age_str[10];

    for (GList *node = g_members; node; node = node->next) {
        Member *member = (Member *)node->data;
        int match = 0;

        if (strstr(filter_type, "Nom") != NULL) {
            match = strstr(member->nom, search_text) != NULL;
        } else if (strstr(filter_type, "prénom") != NULL) {
            match = strstr(member->prenom, search_text) != NULL;
        } else if (strstr(filter_type, "identifiant") != NULL) {
            match = strstr(member->username, search_text) != NULL;
        } else if (strstr(filter_type, "sexe") != NULL) {
            match = strcmp(member->sexe, search_text) == 0;
        } else if (strstr(filter_type, "age") != NULL) {
            sprintf(age_str, "%d", member->age);
            match = strcmp(age_str, search_text) == 0;
        } else if (strstr(filter_type, "téléphone") != NULL) {
            match = strstr(member->telephone, search_text) != NULL;
        }

        if (match) {
            sprintf(age_str, "%d", member->age);

            gtk_list_store_append(store, &iter);
            gtk_list_store_set(store, &iter,
                              0, member->username,
                              1, member->nom,
                              2, member->prenom,
                              3, member->sexe,
                              4, age_str,
                              5, member->telephone,
                              -1);
        }
    }

    g_free(filter_type);
    g_print("✔ Recherche effectuée\n");
}

/* Signal de modification de cellule */
void on_cell_edited(GtkCellRendererText *renderer, gchar *path_string,
                   gchar *new_text, gpointer user_data)
{
    g_print(">>> CELLULE MODIFIÉE\n");

    GtkWidget *tree = lookup_widget(WIN_ADMIN, "treeview11");
    if (!tree) return;

    GtkTreeModel *model = gtk_tree_view_get_model(GTK_TREE_VIEW(tree));
    GtkTreePath *path = gtk_tree_path_new_from_string(path_string);
    GtkTreeIter iter;

    if (gtk_tree_model_get_iter(model, &iter, path)) {
        int column = GPOINTER_TO_INT(user_data);
        gchar *username_str = NULL;

        gtk_tree_model_get(model, &iter, 0, &username_str, -1);

        /* Trouver le membre */
        Member *member = find_member_by_username(g_members, username_str);
        if (member) {
            /* Mettre à jour selon la colonne */
            switch (column) {
                case 1: strncpy(member->nom, new_text, sizeof(member->nom) - 1); break;
                case 2: strncpy(member->prenom, new_text, sizeof(member->prenom) - 1); break;
                case 3: strncpy(member->sexe, new_text, sizeof(member->sexe) - 1); break;
                case 4: member->age = atoi(new_text); break;
                case 5: strncpy(member->telephone, new_text, sizeof(member->telephone) - 1); break;
            }

            /* Mettre à jour le TreeView */
            gtk_list_store_set(GTK_LIST_STORE(model), &iter, column, new_text, -1);

            /* Sauvegarder */
            save_members_to_file(g_members, g_members_filepath);

            g_print("✔ Modification sauvegardée\n");
        }

        g_free(username_str);
    }

    gtk_tree_path_free(path);
}

/* Formulaire d'ajout - Bouton AJOUTER */
void on_btn_ajouter_form_clicked(GtkButton *button, gpointer user_data)
{
    g_print(">>> BOUTON AJOUTER FORMULAIRE CLIQUÉ\n");

    GtkWidget *win_form = gtk_widget_get_toplevel(GTK_WIDGET(button));

    GtkWidget *radio_homme = NULL;
    GtkWidget *radio_femme = NULL;

    /* Récupérer les widgets avec les IDs corrects du fichier Glade */
    GtkWidget *entry_id = lookup_widget(win_form, "entry_id_membre");
    GtkWidget *entry_nom = lookup_widget(win_form, "entry_nom_membre");
    GtkWidget *entry_prenom = lookup_widget(win_form, "entry_prenom_membre");
    GtkWidget *entry_tel = lookup_widget(win_form, "entry_tel_membre");
    GtkWidget *entry_sexe = lookup_widget(win_form, "entry_sexe_membre");

    if (!entry_id || !entry_nom || !entry_prenom || !entry_tel || !entry_sexe) {
        g_warning("⚠ Widgets du formulaire manquants (vérifiez les IDs dans Glade)");
        /* Tentative de fallback sur les anciens IDs si les nouveaux échouent (pour compatibilité) */
        if (!entry_id) entry_id = lookup_widget(win_form, "entry9");
        if (!entry_nom) entry_nom = lookup_widget(win_form, "entry10");
        if (!entry_prenom) entry_prenom = lookup_widget(win_form, "entry11");
        if (!entry_tel) entry_tel = lookup_widget(win_form, "entry12");
        
        if (!entry_id || !entry_nom || !entry_prenom || !entry_tel) {
             g_warning("⚠ Impossible de trouver les widgets même avec les anciens IDs");
             return;
        }
    }

    const char *username = gtk_entry_get_text(GTK_ENTRY(entry_id));
    const char *nom = gtk_entry_get_text(GTK_ENTRY(entry_nom));
    const char *prenom = gtk_entry_get_text(GTK_ENTRY(entry_prenom));
    const char *tel = gtk_entry_get_text(GTK_ENTRY(entry_tel));
    const char *sexe = "";
    
    if (entry_sexe) {
        sexe = gtk_entry_get_text(GTK_ENTRY(entry_sexe));
    } else {
        /* Fallback radio buttons si entry_sexe n'existe pas */
        radio_homme = lookup_widget(win_form, "radio_homme");
        radio_femme = lookup_widget(win_form, "radio_femme");

        if (radio_homme && gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(radio_homme))) {
            sexe = "Homme";
        } else if (radio_femme && gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(radio_femme))) {
            sexe = "Femme";
        } else {
            sexe = "Inconnu";
        }
    }

    /* Validation */
    if (strlen(username) == 0 || strlen(nom) == 0 || strlen(prenom) == 0 || strlen(tel) == 0) {
        GtkWidget *dialog = gtk_message_dialog_new(
            GTK_WINDOW(win_form),
            GTK_DIALOG_DESTROY_WITH_PARENT,
            GTK_MESSAGE_ERROR,
            GTK_BUTTONS_OK,
            "Tous les champs sont obligatoires !"
        );
        g_signal_connect_swapped(dialog, "response", G_CALLBACK(gtk_widget_destroy), dialog);
        gtk_widget_show(dialog);
        return;
    }

    /* Pour l'âge, utiliser une valeur par défaut (0) car l'interface eventbox2 n'a pas d'âge */
    int age = 0;
    char age_str[10];
    sprintf(age_str, "%d", age);

    /* Créer le membre */
    Member *member = create_member(username, nom, prenom, sexe, age, tel);

    /* Ajouter à la liste */
    add_member_to_list(&g_members, member);

    /* Sauvegarder */
    save_members_to_file(g_members, g_members_filepath);

    /* Ajouter au TreeView */
    GtkWidget *tree = lookup_widget(WIN_ADMIN, "treeview11");
    if (tree) {
        GtkTreeModel *model = gtk_tree_view_get_model(GTK_TREE_VIEW(tree));
        GtkListStore *store = GTK_LIST_STORE(model);
        GtkTreeIter iter;

        gtk_list_store_append(store, &iter);
        gtk_list_store_set(store, &iter,
                          0, username,
                          1, nom,
                          2, prenom,
                          3, sexe,
                          4, age_str,
                          5, tel,
                          -1);
    }

    /* Vider le formulaire */
    gtk_entry_set_text(GTK_ENTRY(entry_id), "");
    gtk_entry_set_text(GTK_ENTRY(entry_nom), "");
    gtk_entry_set_text(GTK_ENTRY(entry_prenom), "");
    gtk_entry_set_text(GTK_ENTRY(entry_tel), "");

    if (entry_sexe) {
        gtk_entry_set_text(GTK_ENTRY(entry_sexe), "");
    } else if (radio_homme) {
        gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(radio_homme), TRUE);
    }

    /* Fermer le formulaire */
    gtk_widget_hide(win_form);

    g_print("✔ Membre ajouté avec succès\n");
}

/* Formulaire d'ajout - Bouton FERMER */
void on_btn_fermer_form_clicked(GtkButton *button, gpointer user_data)
{
    g_print(">>> BOUTON FERMER FORMULAIRE CLIQUÉ\n");

    GtkWidget *win_form = gtk_widget_get_toplevel(GTK_WIDGET(button));
    gtk_widget_hide(win_form);
}

/* ========== DEMANDE DE COACH PRIVÉ ========== */

/* Initialiser la liste des coaches disponibles dans le TreeView */
void init_coaches_interface(GtkWidget *tree)
{
    if (!tree) {
        g_warning("⚠️ TreeView 'tableau_des_coach_prive' introuvable !");
        return;
    }

    /* Si un modèle existe déjà, on ne recrée pas tout */
    if (gtk_tree_view_get_model(GTK_TREE_VIEW(tree)) != NULL)
        return;

    /* Charger les coaches depuis le fichier si ce n'est pas fait */
    if (g_coaches == NULL) {
        g_print("📂 Chargement des coaches depuis : %s\n", g_coaches_filepath);
        load_coaches_from_file(&g_coaches, g_coaches_filepath);
    }

    /* Modèle : 3 colonnes (Nom, Spécialité, Téléphone) */
    GtkListStore *store = gtk_list_store_new(
        3,
        G_TYPE_STRING,   /* 0 : Nom du coach */
        G_TYPE_STRING,   /* 1 : Spécialité */
        G_TYPE_STRING    /* 2 : Téléphone */
    );

    gtk_tree_view_set_model(GTK_TREE_VIEW(tree), GTK_TREE_MODEL(store));
    g_object_unref(store);

    /* Création des colonnes visibles */
    GtkCellRenderer *renderer;
    const char *titles[3] = {"Coach", "Spécialité", "Téléphone"};

    for (int i = 0; i < 3; ++i) {
        renderer = gtk_cell_renderer_text_new();
        gtk_tree_view_insert_column_with_attributes(
            GTK_TREE_VIEW(tree),
            -1,
            titles[i],
            renderer,
            "text", i,
            NULL
        );
    }

    /* Ajouter les coaches depuis la liste */
    GtkTreeIter iter;
    int coach_count = 0;
    for (GList *list_iter = g_coaches; list_iter != NULL; list_iter = list_iter->next) {
        Coach *coach = (Coach *)list_iter->data;
        gtk_list_store_append(store, &iter);
        gtk_list_store_set(store, &iter,
                          0, coach->nom,
                          1, coach->specialite,
                          2, coach->telephone,
                          -1);
        coach_count++;
        g_print("✔ Coach ajouté au TreeView : %s\n", coach->nom);
    }

    g_print("✔ TreeView des coaches initialisé avec %d coaches\n", coach_count);
}

/* Bouton "demander ce coach" - Récupérer les données et créer la demande */
void on_button66_clicked(GtkButton *button, gpointer user_data)
{
    g_print(">>> BOUTON DEMANDER COACH CLIQUÉ\n");

    /* Charger les demandes existantes */
    if (g_coach_requests == NULL) {
        g_print("📂 Chargement des demandes de coach...\n");
        load_coach_requests_from_file(&g_coach_requests, g_coach_requests_filepath);
    }

    /* Récupérer la fenêtre parente (WIN_MEMBRE) */
    GtkWidget *win = gtk_widget_get_toplevel(GTK_WIDGET(button));
    if (!GTK_IS_WINDOW(win)) {
        g_warning("⚠ Impossible de trouver la fenêtre parente");
        return;
    }
    g_print("✔ Fenêtre parente trouvée\n");

    /* Récupérer les widgets du formulaire */
    GtkWidget *spin_day = lookup_widget(win, "spinbutton16");
    GtkWidget *spin_month = lookup_widget(win, "spinbutton17");
    GtkWidget *spin_year = lookup_widget(win, "spinbutton18");
    GtkWidget *spin_hour = lookup_widget(win, "spinbutton19");
    GtkWidget *tree_coaches = lookup_widget(win, "tableau_des_coach_prive");

    g_print("Widgets trouvés: day=%p, month=%p, year=%p, hour=%p, tree=%p\n",
            spin_day, spin_month, spin_year, spin_hour, tree_coaches);

    if (!spin_day || !spin_month || !spin_year || !spin_hour || !tree_coaches) {
        g_warning("⚠ Widgets du formulaire manquants");
        return;
    }

    /* Initialiser le TreeView si ce n'est pas fait */
    init_coaches_interface(tree_coaches);

    /* Récupérer le coach sélectionné dans le TreeView */
    GtkTreeSelection *selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(tree_coaches));
    GtkTreeIter iter;
    GtkTreeModel *model;
    gchar *coach_name = NULL;

    g_print("📋 Vérification de la sélection du coach...\n");
    if (!gtk_tree_selection_get_selected(selection, &model, &iter)) {
        g_print("❌ Aucun coach sélectionné\n");
        GtkWidget *dialog = gtk_message_dialog_new(
            GTK_WINDOW(win),
            GTK_DIALOG_MODAL,
            GTK_MESSAGE_ERROR,
            GTK_BUTTONS_OK,
            "Veuillez sélectionner un coach dans la liste !"
        );
        gtk_dialog_run(GTK_DIALOG(dialog));
        gtk_widget_destroy(dialog);
        return;
    }

    /* Coach sélectionné dans le TreeView */
    gtk_tree_model_get(model, &iter, 0, &coach_name, -1);
    g_print("✔ Coach sélectionné : %s\n", coach_name);
    
    /* Valider que le coach est sélectionné */
    if (!coach_name || strlen(coach_name) == 0) {
        g_print("❌ Nom du coach vide\n");
        GtkWidget *dialog = gtk_message_dialog_new(
            GTK_WINDOW(win),
            GTK_DIALOG_MODAL,
            GTK_MESSAGE_ERROR,
            GTK_BUTTONS_OK,
            "Erreur : coach non valide !"
        );
        gtk_dialog_run(GTK_DIALOG(dialog));
        gtk_widget_destroy(dialog);
        if (coach_name) g_free(coach_name);
        return;
    }

    /* Récupérer la date et l'heure */
    int day = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin_day));
    int month = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin_month));
    int year = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin_year));
    int hour = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin_hour));
    int minute = 0;  /* Par défaut, 0 minute */

    /* Valider la date */
    if (day < 1 || day > 31 || month < 1 || month > 12 || year < 2024) {
        GtkWidget *dialog = gtk_message_dialog_new(
            GTK_WINDOW(win),
            GTK_DIALOG_MODAL,
            GTK_MESSAGE_ERROR,
            GTK_BUTTONS_OK,
            "Date invalide ! Veuillez vérifier la date."
        );
        gtk_dialog_run(GTK_DIALOG(dialog));
        gtk_widget_destroy(dialog);
        return;
    }

    /* Valider l'heure */
    if (hour < 0 || hour > 23) {
        GtkWidget *dialog = gtk_message_dialog_new(
            GTK_WINDOW(win),
            GTK_DIALOG_MODAL,
            GTK_MESSAGE_ERROR,
            GTK_BUTTONS_OK,
            "Heure invalide ! Veuillez entrer une heure entre 0 et 23."
        );
        gtk_dialog_run(GTK_DIALOG(dialog));
        gtk_widget_destroy(dialog);
        return;
    }

    /* Formater la date */
    char date_str[20];
    sprintf(date_str, "%02d/%02d/%04d", day, month, year);

    /* Créer la demande de coach */
    /* Utiliser un ID membre par défaut si non défini */
    const char *member_id = (strlen(g_current_member_id) > 0) ? g_current_member_id : "membre_anonyme";

    CoachRequest *request = create_coach_request(member_id, coach_name, date_str, hour, minute);
    if (!request) {
        g_warning("⚠ Erreur lors de la création de la demande");
        return;
    }

    /* Ajouter à la liste */
    add_coach_request_to_list(&g_coach_requests, request);

    /* Sauvegarder dans le fichier */
    save_coach_requests_to_file(g_coach_requests, g_coach_requests_filepath);

    /* Afficher un message de confirmation */
    GtkWidget *dialog = gtk_message_dialog_new(
        GTK_WINDOW(win),
        GTK_DIALOG_MODAL,
        GTK_MESSAGE_INFO,
        GTK_BUTTONS_OK,
        "✔ Demande de coach privé envoyée avec succès !\n\n"
        "Coach : %s\n"
        "Date : %s\n"
        "Heure : %02d:00\n\n"
        "Statut : En attente de confirmation",
        coach_name, date_str, hour
    );
    gtk_dialog_run(GTK_DIALOG(dialog));
    gtk_widget_destroy(dialog);

    /* Vider les champs du formulaire */
    gtk_spin_button_set_value(GTK_SPIN_BUTTON(spin_day), 1);
    gtk_spin_button_set_value(GTK_SPIN_BUTTON(spin_month), 1);
    gtk_spin_button_set_value(GTK_SPIN_BUTTON(spin_year), 2025);
    gtk_spin_button_set_value(GTK_SPIN_BUTTON(spin_hour), 1);

    /* Libérer la mémoire du nom du coach */
    g_free(coach_name);

    g_print("✔ Demande de coach créée et sauvegardée\n");
}

/* Fonction pour définir l'ID du membre connecté (à appeler lors du login) */
void set_current_member_id(const char *member_id)
{
    strncpy(g_current_member_id, member_id, sizeof(g_current_member_id) - 1);
    g_current_member_id[sizeof(g_current_member_id) - 1] = '\0';
    g_print("✔ ID du membre défini : %s\n", g_current_member_id);
    
    /* Rafraîchir les notifications d'abonnement après définition de l'ID */
    refresh_subscription_notifications();
}

/* Rafraîchir les notifications d'abonnement du membre connecté */
void refresh_subscription_notifications(void)
{
    g_print("🔄 Rafraîchissement des notifications d'abonnement...\n");
    
    /* Charger les membres si ce n'est pas fait */
    if (g_members == NULL) {
        g_print("📂 Chargement des membres depuis %s\n", g_members_filepath);
        g_members = load_members_from_file(g_members_filepath);
        g_print("✔ %d membres chargés\n", g_list_length(g_members));
    }
    
    /* Chercher la fenêtre du membre */
    GtkWidget *win_membre = NULL;
    GList *toplevels = gtk_window_list_toplevels();
    for (GList *iter = toplevels; iter != NULL; iter = iter->next) {
        GtkWidget *toplevel = GTK_WIDGET(iter->data);
        const char *title = gtk_window_get_title(GTK_WINDOW(toplevel));
        if (title && strcmp(title, "gestion membres") == 0) {
            win_membre = toplevel;
            break;
        }
    }
    g_list_free(toplevels);

    if (!win_membre) {
        g_print("⚠️ Fenêtre du membre non trouvée\n");
        return;
    }

    /* Récupérer fixed46 */
    GtkWidget *fixed46 = lookup_widget(win_membre, "fixed46");
    if (!fixed46) {
        g_print("⚠️ fixed46 non trouvé\n");
        return;
    }

    /* Nettoyer fixed46 */
    GList *children = gtk_container_get_children(GTK_CONTAINER(fixed46));
    for (GList *iter = children; iter != NULL; iter = iter->next) {
        gtk_widget_destroy(GTK_WIDGET(iter->data));
    }
    g_list_free(children);

    /* Recréer les notifications */
    init_subscription_notifications_interface(fixed46);
    g_print("✔ Notifications d'abonnement rafraîchies\n");
}

/* Initialiser le TreeView des demandes de coach pour un membre */
void init_coach_requests_interface(GtkWidget *tree)
{
    if (!tree) {
        g_warning("⚠️ TreeView des demandes introuvable !");
        return;
    }

    /* Si un modèle existe déjà, on ne recrée pas tout */
    if (gtk_tree_view_get_model(GTK_TREE_VIEW(tree)) != NULL) {
        /* Nettoyer le modèle existant */
        gtk_tree_view_set_model(GTK_TREE_VIEW(tree), NULL);
    }

    /* Charger les demandes depuis le fichier si ce n'est pas fait */
    if (g_coach_requests == NULL) {
        load_coach_requests_from_file(&g_coach_requests, g_coach_requests_filepath);
    }

    /* Modèle : 4 colonnes (Coach, Date, Heure, Statut) */
    GtkListStore *store = gtk_list_store_new(
        4,
        G_TYPE_STRING,   /* 0 : Nom du coach */
        G_TYPE_STRING,   /* 1 : Date */
        G_TYPE_STRING,   /* 2 : Heure */
        G_TYPE_STRING    /* 3 : Statut */
    );

    gtk_tree_view_set_model(GTK_TREE_VIEW(tree), GTK_TREE_MODEL(store));
    g_object_unref(store);

    /* Création des colonnes visibles */
    GtkCellRenderer *renderer;
    const char *titles[4] = {"Coach", "Date", "Heure", "Statut"};

    for (int i = 0; i < 4; ++i) {
        renderer = gtk_cell_renderer_text_new();
        gtk_tree_view_insert_column_with_attributes(
            GTK_TREE_VIEW(tree),
            -1,
            titles[i],
            renderer,
            "text", i,
            NULL
        );
    }

    /* Ajouter les demandes du membre depuis la liste */
    GtkTreeIter iter;
    int request_count = 0;
    for (GList *list_iter = g_coach_requests; list_iter != NULL; list_iter = list_iter->next) {
        CoachRequest *request = (CoachRequest *)list_iter->data;
        
        /* Afficher seulement les demandes du membre connecté */
        if (strcmp(request->id_membre, g_current_member_id) == 0) {
            char time_str[10];
            sprintf(time_str, "%02d:00", request->heure_seance);
            
            gtk_list_store_append(store, &iter);
            gtk_list_store_set(store, &iter,
                              0, request->nom_coach,
                              1, request->date_seance,
                              2, time_str,
                              3, request->statut,
                              -1);
            request_count++;
            g_print("✔ Demande ajoutée au TreeView : %s - %s\n", request->nom_coach, request->statut);
        }
    }

    g_print("✔ TreeView des demandes initialisé avec %d demandes\n", request_count);
}

/* Initialiser le TreeView des notifications de réservation de coach */
void init_coach_notifications_interface(GtkWidget *tree)
{
    if (!tree) {
        g_warning("⚠️ TreeView des notifications introuvable !");
        return;
    }

    /* Si un modèle existe déjà, on ne recrée pas tout */
    if (gtk_tree_view_get_model(GTK_TREE_VIEW(tree)) != NULL) {
        /* Nettoyer le modèle existant */
        gtk_tree_view_set_model(GTK_TREE_VIEW(tree), NULL);
    }

    /* Charger les demandes depuis le fichier si ce n'est pas fait */
    if (g_coach_requests == NULL) {
        load_coach_requests_from_file(&g_coach_requests, g_coach_requests_filepath);
    }

    /* Modèle : 5 colonnes (Coach, Date, Heure, Statut, Message) */
    GtkListStore *store = gtk_list_store_new(
        5,
        G_TYPE_STRING,   /* 0 : Nom du coach */
        G_TYPE_STRING,   /* 1 : Date */
        G_TYPE_STRING,   /* 2 : Heure */
        G_TYPE_STRING,   /* 3 : Statut */
        G_TYPE_STRING    /* 4 : Message de notification */
    );

    gtk_tree_view_set_model(GTK_TREE_VIEW(tree), GTK_TREE_MODEL(store));
    g_object_unref(store);

    /* Création des colonnes visibles */
    GtkCellRenderer *renderer;
    const char *titles[5] = {"Coach", "Date", "Heure", "Statut", "Notification"};

    for (int i = 0; i < 5; ++i) {
        renderer = gtk_cell_renderer_text_new();
        gtk_tree_view_insert_column_with_attributes(
            GTK_TREE_VIEW(tree),
            -1,
            titles[i],
            renderer,
            "text", i,
            NULL
        );
    }

    /* Ajouter les notifications du membre (demandes acceptées ou refusées) */
    GtkTreeIter iter;
    int notification_count = 0;
    for (GList *list_iter = g_coach_requests; list_iter != NULL; list_iter = list_iter->next) {
        CoachRequest *request = (CoachRequest *)list_iter->data;
        
        /* Afficher seulement les demandes du membre connecté avec statut acceptée ou refusée */
        if (strcmp(request->id_membre, g_current_member_id) == 0 && 
            (strcmp(request->statut, "acceptée") == 0 || strcmp(request->statut, "refusée") == 0)) {
            
            char time_str[10];
            sprintf(time_str, "%02d:00", request->heure_seance);
            
            /* Message de notification */
            char notification_msg[256];
            if (strcmp(request->statut, "acceptée") == 0) {
                sprintf(notification_msg, "✔ Votre demande a été acceptée par %s", request->nom_coach);
            } else {
                sprintf(notification_msg, "✗ Votre demande a été refusée par %s", request->nom_coach);
            }
            
            gtk_list_store_append(store, &iter);
            gtk_list_store_set(store, &iter,
                              0, request->nom_coach,
                              1, request->date_seance,
                              2, time_str,
                              3, request->statut,
                              4, notification_msg,
                              -1);
            notification_count++;
            g_print("✔ Notification ajoutée au TreeView : %s - %s\n", request->nom_coach, request->statut);
        }
    }

    g_print("✔ TreeView des notifications initialisé avec %d notifications\n", notification_count);
}

/* Initialiser le TreeView des demandes de coach pour les entraineurs */
void init_coach_requests_for_trainers_interface(GtkWidget *tree)
{
    g_print(">>> INIT COACH REQUESTS FOR TRAINERS INTERFACE APPELÉE\n");
    
    if (!tree) {
        g_warning("⚠️ TreeView des demandes (entraineurs) introuvable !");
        return;
    }

    g_print("✔ TreeView trouvé\n");

    /* Si un modèle existe déjà, on ne recrée pas tout */
    if (gtk_tree_view_get_model(GTK_TREE_VIEW(tree)) != NULL) {
        gtk_tree_view_set_model(GTK_TREE_VIEW(tree), NULL);
    }

    /* Charger les demandes depuis le fichier si ce n'est pas fait */
    if (g_coach_requests == NULL) {
        g_print("✔ Chargement des demandes depuis %s\n", g_coach_requests_filepath);
        load_coach_requests_from_file(&g_coach_requests, g_coach_requests_filepath);
    } else {
        g_print("✔ Demandes déjà chargées en mémoire\n");
    }

    /* Modèle : 5 colonnes (Membre, Coach, Date, Heure, Statut) */
    GtkListStore *store = gtk_list_store_new(
        5,
        G_TYPE_STRING,   /* 0 : ID demande (caché) */
        G_TYPE_STRING,   /* 1 : Membre */
        G_TYPE_STRING,   /* 2 : Coach */
        G_TYPE_STRING,   /* 3 : Date */
        G_TYPE_STRING    /* 4 : Heure */
    );

    gtk_tree_view_set_model(GTK_TREE_VIEW(tree), GTK_TREE_MODEL(store));
    g_object_unref(store);

    /* Création des colonnes visibles */
    GtkCellRenderer *renderer;
    const char *titles[5] = {"ID Demande", "Membre", "Coach", "Date", "Heure"};

    for (int i = 0; i < 5; ++i) {
        renderer = gtk_cell_renderer_text_new();
        gtk_tree_view_insert_column_with_attributes(
            GTK_TREE_VIEW(tree),
            -1,
            titles[i],
            renderer,
            "text", i,
            NULL
        );
    }

    /* Ajouter les demandes en attente depuis la liste */
    GtkTreeIter iter;
    int request_count = 0;
    int total_count = 0;
    
    for (GList *list_iter = g_coach_requests; list_iter != NULL; list_iter = list_iter->next) {
        total_count++;
        CoachRequest *request = (CoachRequest *)list_iter->data;
        g_print("  - Demande trouvée : %s (statut: %s)\n", request->id_demande, request->statut);
        
        /* Afficher seulement les demandes en attente */
        if (strcmp(request->statut, "en attente") == 0) {
            char time_str[10];
            sprintf(time_str, "%02d:00", request->heure_seance);
            
            gtk_list_store_append(store, &iter);
            gtk_list_store_set(store, &iter,
                              0, request->id_demande,
                              1, request->id_membre,
                              2, request->nom_coach,
                              3, request->date_seance,
                              4, time_str,
                              -1);
            request_count++;
            g_print("✔ Demande affichée pour entraineur : %s - %s\n", request->nom_coach, request->id_membre);
        }
    }

    g_print("✔ TreeView des demandes (entraineurs) initialisé : %d/%d demandes en attente\n", request_count, total_count);
}

/* Callback : Accepter une demande de coach */
void on_button_accepter_demande_clicked(GtkButton *button, gpointer user_data)
{
    g_print(">>> BOUTON ACCEPTER DEMANDE CLIQUÉ\n");

    /* Récupérer la fenêtre parente */
    GtkWidget *win = gtk_widget_get_toplevel(GTK_WIDGET(button));
    if (!GTK_IS_WINDOW(win)) {
        g_warning("⚠ Impossible de trouver la fenêtre parente");
        return;
    }

    /* Récupérer le TreeView des demandes */
    GtkWidget *tree = lookup_widget(win, "tableau_demandes_coach_entraineur");
    if (!tree) {
        g_warning("⚠ TreeView des demandes introuvable");
        return;
    }

    /* Récupérer la sélection */
    GtkTreeSelection *selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(tree));
    GtkTreeIter iter;
    GtkTreeModel *model;
    gchar *id_demande = NULL;

    if (!gtk_tree_selection_get_selected(selection, &model, &iter)) {
        GtkWidget *dialog = gtk_message_dialog_new(
            GTK_WINDOW(win),
            GTK_DIALOG_DESTROY_WITH_PARENT,
            GTK_MESSAGE_ERROR,
            GTK_BUTTONS_OK,
            "Veuillez sélectionner une demande !"
        );
        g_signal_connect_swapped(dialog, "response", G_CALLBACK(gtk_widget_destroy), dialog);
        gtk_widget_show(dialog);
        return;
    }

    /* Récupérer l'ID de la demande */
    gtk_tree_model_get(model, &iter, 0, &id_demande, -1);

    /* Trouver et mettre à jour la demande */
    for (GList *list_iter = g_coach_requests; list_iter != NULL; list_iter = list_iter->next) {
        CoachRequest *request = (CoachRequest *)list_iter->data;
        if (strcmp(request->id_demande, id_demande) == 0) {
            strcpy(request->statut, "acceptée");
            g_print("✔ Demande acceptée : %s\n", id_demande);
            break;
        }
    }

    /* Sauvegarder les modifications */
    save_coach_requests_to_file(g_coach_requests, g_coach_requests_filepath);

    /* Rafraîchir le TreeView */
    init_coach_requests_for_trainers_interface(tree);

    /* Rafraîchir les notifications du membre (chercher la fenêtre du membre) */
    GtkWidget *win_membre = NULL;
    GList *toplevels = gtk_window_list_toplevels();
    for (GList *iter = toplevels; iter != NULL; iter = iter->next) {
        GtkWidget *toplevel = GTK_WIDGET(iter->data);
        const char *title = gtk_window_get_title(GTK_WINDOW(toplevel));
        if (title && strcmp(title, "gestion membres") == 0) {
            win_membre = toplevel;
            break;
        }
    }
    g_list_free(toplevels);

    if (win_membre) {
        GtkWidget *tree_notif = lookup_widget(win_membre, "tableau_notifications_coach");
        if (tree_notif) {
            init_coach_notifications_interface(tree_notif);
            g_print("✔ TreeView des notifications du membre rafraîchi\n");
        }
    }

    /* Afficher un message de confirmation non-bloquant */
    GtkWidget *dialog = gtk_message_dialog_new(
        GTK_WINDOW(win),
        GTK_DIALOG_DESTROY_WITH_PARENT,
        GTK_MESSAGE_INFO,
        GTK_BUTTONS_OK,
        "✔ Demande acceptée avec succès !"
    );
    g_signal_connect_swapped(dialog, "response", G_CALLBACK(gtk_widget_destroy), dialog);
    gtk_widget_show(dialog);

    g_free(id_demande);
}

/* Rafraîchir le TreeView des notifications du membre */
void refresh_member_notifications(void)
{
    /* Chercher la fenêtre du membre */
    GtkWidget *win = lookup_widget(NULL, "login_membres");
    if (!win) {
        g_print("⚠ Fenêtre du membre non trouvée\n");
        return;
    }

    /* Récupérer le TreeView des notifications */
    GtkWidget *tree = lookup_widget(win, "tableau_notifications_coach");
    if (!tree) {
        g_print("⚠ TreeView des notifications non trouvé\n");
        return;
    }

    /* Rafraîchir le TreeView */
    init_coach_notifications_interface(tree);
    g_print("✔ TreeView des notifications rafraîchi\n");
}

/* Initialiser le TreeView des notifications d'abonnement dans fixed46 */
void init_subscription_notifications_interface(GtkWidget *fixed46)
{
    if (!fixed46) {
        g_warning("⚠️ fixed46 introuvable !");
        return;
    }

    /* Créer un label pour le titre */
    GtkWidget *label_title = gtk_label_new("Notifications d'abonnement");
    gtk_widget_show(label_title);
    gtk_fixed_put(GTK_FIXED(fixed46), label_title, 16, 16);
    gtk_widget_set_size_request(label_title, 800, 25);

    /* Créer le TreeView */
    GtkWidget *tree = gtk_tree_view_new();
    gtk_widget_show(tree);
    gtk_fixed_put(GTK_FIXED(fixed46), tree, 16, 48);
    gtk_widget_set_size_request(tree, 800, 400);
    gtk_tree_view_set_headers_visible(GTK_TREE_VIEW(tree), TRUE);

    /* Modèle : 3 colonnes (Membre, Date Expiration, Message) */
    GtkListStore *store = gtk_list_store_new(
        3,
        G_TYPE_STRING,   /* 0 : Membre */
        G_TYPE_STRING,   /* 1 : Date d'expiration */
        G_TYPE_STRING    /* 2 : Message de notification */
    );

    gtk_tree_view_set_model(GTK_TREE_VIEW(tree), GTK_TREE_MODEL(store));
    g_object_unref(store);

    /* Création des colonnes visibles */
    GtkCellRenderer *renderer;
    const char *titles[3] = {"Membre", "Date d'expiration", "Notification"};

    for (int i = 0; i < 3; ++i) {
        renderer = gtk_cell_renderer_text_new();
        gtk_tree_view_insert_column_with_attributes(
            GTK_TREE_VIEW(tree),
            -1,
            titles[i],
            renderer,
            "text", i,
            NULL
        );
    }

    /* Ajouter les notifications d'abonnement du membre connecté */
    GtkTreeIter iter;
    int notification_count = 0;

    g_print("📋 Vérification des notifications - Membre connecté: %s\n", g_current_member_id);
    g_print("📋 Nombre de membres chargés: %d\n", g_list_length(g_members));

    if (g_members) {
        for (GList *list_iter = g_members; list_iter != NULL; list_iter = list_iter->next) {
            Member *member = (Member *)list_iter->data;
            
            g_print("  - Vérification membre: %s (connecté: %s)\n", member->username, g_current_member_id);
            
            /* Vérifier si c'est le membre connecté */
            if (strlen(g_current_member_id) > 0 && strcmp(member->username, g_current_member_id) == 0) {
                g_print("    ✔ Membre trouvé! Date signup: %s\n", member->date_signup);
                
                /* Calculer la date d'expiration (30 jours après signup) */
                struct tm signup_tm = {0};
                int day, month, year;
                sscanf(member->date_signup, "%d/%d/%d", &day, &month, &year);
                signup_tm.tm_mday = day;
                signup_tm.tm_mon = month - 1;  /* tm_mon est 0-11 */
                signup_tm.tm_year = year - 1900;  /* tm_year est depuis 1900 */
                
                time_t signup_time = mktime(&signup_tm);
                time_t expiration_time = signup_time + (30 * 24 * 60 * 60);  /* +30 jours */
                time_t now = time(NULL);
                
                /* Calculer les jours restants */
                int days_remaining = (int)((expiration_time - now) / (24 * 60 * 60));
                
                g_print("    📅 Jours restants: %d\n", days_remaining);
                
                /* Afficher si moins de 5 jours restants */
                if (days_remaining <= 5 && days_remaining > 0) {
                    struct tm *exp_tm = localtime(&expiration_time);
                    char exp_date[20];
                    strftime(exp_date, sizeof(exp_date), "%d/%m/%Y", exp_tm);
                    
                    char notification_msg[256];
                    sprintf(notification_msg, "⚠️ Votre abonnement expire dans %d jour(s) !", days_remaining);
                    
                    gtk_list_store_append(store, &iter);
                    gtk_list_store_set(store, &iter,
                                      0, member->username,
                                      1, exp_date,
                                      2, notification_msg,
                                      -1);
                    notification_count++;
                    g_print("✔ Notification d'abonnement ajoutée : %s - %d jours restants\n", member->username, days_remaining);
                } else if (days_remaining <= 0) {
                    char notification_msg[256];
                    sprintf(notification_msg, "❌ Votre abonnement a expiré !");
                    
                    gtk_list_store_append(store, &iter);
                    gtk_list_store_set(store, &iter,
                                      0, member->username,
                                      1, member->date_signup,
                                      2, notification_msg,
                                      -1);
                    notification_count++;
                    g_print("✔ Notification d'expiration ajoutée : %s\n", member->username);
                }
            }
        }
    }

    g_print("✔ TreeView des notifications d'abonnement initialisé avec %d notifications\n", notification_count);
}

/* Callback : Refuser une demande de coach */
void on_button_refuser_demande_clicked(GtkButton *button, gpointer user_data)
{
    g_print(">>> BOUTON REFUSER DEMANDE CLIQUÉ\n");

    /* Récupérer la fenêtre parente */
    GtkWidget *win = gtk_widget_get_toplevel(GTK_WIDGET(button));
    if (!GTK_IS_WINDOW(win)) {
        g_warning("⚠ Impossible de trouver la fenêtre parente");
        return;
    }

    /* Récupérer le TreeView des demandes */
    GtkWidget *tree = lookup_widget(win, "tableau_demandes_coach_entraineur");
    if (!tree) {
        g_warning("⚠ TreeView des demandes introuvable");
        return;
    }

    /* Récupérer la sélection */
    GtkTreeSelection *selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(tree));
    GtkTreeIter iter;
    GtkTreeModel *model;
    gchar *id_demande = NULL;

    if (!gtk_tree_selection_get_selected(selection, &model, &iter)) {
        GtkWidget *dialog = gtk_message_dialog_new(
            GTK_WINDOW(win),
            GTK_DIALOG_DESTROY_WITH_PARENT,
            GTK_MESSAGE_ERROR,
            GTK_BUTTONS_OK,
            "Veuillez sélectionner une demande !"
        );
        g_signal_connect_swapped(dialog, "response", G_CALLBACK(gtk_widget_destroy), dialog);
        gtk_widget_show(dialog);
        return;
    }

    /* Récupérer l'ID de la demande */
    gtk_tree_model_get(model, &iter, 0, &id_demande, -1);

    /* Trouver et mettre à jour la demande */
    for (GList *list_iter = g_coach_requests; list_iter != NULL; list_iter = list_iter->next) {
        CoachRequest *request = (CoachRequest *)list_iter->data;
        if (strcmp(request->id_demande, id_demande) == 0) {
            strcpy(request->statut, "refusée");
            g_print("✔ Demande refusée : %s\n", id_demande);
            break;
        }
    }

    /* Sauvegarder les modifications */
    save_coach_requests_to_file(g_coach_requests, g_coach_requests_filepath);

    /* Rafraîchir le TreeView */
    init_coach_requests_for_trainers_interface(tree);

    /* Rafraîchir les notifications du membre (chercher la fenêtre du membre) */
    GtkWidget *win_membre = NULL;
    GList *toplevels = gtk_window_list_toplevels();
    for (GList *iter = toplevels; iter != NULL; iter = iter->next) {
        GtkWidget *toplevel = GTK_WIDGET(iter->data);
        const char *title = gtk_window_get_title(GTK_WINDOW(toplevel));
        if (title && strcmp(title, "gestion membres") == 0) {
            win_membre = toplevel;
            break;
        }
    }
    g_list_free(toplevels);

    if (win_membre) {
        GtkWidget *tree_notif = lookup_widget(win_membre, "tableau_notifications_coach");
        if (tree_notif) {
            init_coach_notifications_interface(tree_notif);
            g_print("✔ TreeView des notifications du membre rafraîchi\n");
        }
    }

    /* Afficher un message de confirmation non-bloquant */
    GtkWidget *dialog = gtk_message_dialog_new(
        GTK_WINDOW(win),
        GTK_DIALOG_DESTROY_WITH_PARENT,
        GTK_MESSAGE_INFO,
        GTK_BUTTONS_OK,
        "✔ Demande refusée !"
    );
    g_signal_connect_swapped(dialog, "response", G_CALLBACK(gtk_widget_destroy), dialog);
    gtk_widget_show(dialog);

    g_free(id_demande);
}

/* Callback : Générer une proposition de régime */
void on_button36_clicked(GtkButton *button, gpointer user_data)
{
    g_print(">>> BOUTON VALIDER RÉGIME CLIQUÉ\n");
    
    GtkWidget *win = gtk_widget_get_toplevel(GTK_WIDGET(button));
    
    /* Récupérer les informations du membre depuis les champs */
    GtkWidget *entry25 = lookup_widget(win, "entry25");  /* identifiant */
    GtkWidget *entry26 = lookup_widget(win, "entry26");  /* nom */
    GtkWidget *entry27 = lookup_widget(win, "entry27");  /* prénom */
    GtkWidget *entry31 = lookup_widget(win, "entry31");  /* maladie chronique */
    GtkWidget *entry32 = lookup_widget(win, "entry32");  /* poids */
    GtkWidget *entry35 = lookup_widget(win, "entry35");  /* infos supplémentaires */
    GtkWidget *tree_regime = lookup_widget(win, "tree_regime");  /* TreeView régime */
    GtkWidget *radiobutton8 = lookup_widget(win, "radiobutton8");  /* homme */
    
    if (!entry25 || !entry26 || !tree_regime) {
        g_print("⚠️ Widgets non trouvés\n");
        return;
    }
    
    const char *identifiant = gtk_entry_get_text(GTK_ENTRY(entry25));
    const char *nom = gtk_entry_get_text(GTK_ENTRY(entry26));
    const char *prenom = gtk_entry_get_text(GTK_ENTRY(entry27));
    const char *maladie_chronique = gtk_entry_get_text(GTK_ENTRY(entry31));
    const char *poids_str = gtk_entry_get_text(GTK_ENTRY(entry32));
    const char *infos_supp = gtk_entry_get_text(GTK_ENTRY(entry35));
    
    /* Vérifier les champs obligatoires */
    if (strlen(identifiant) == 0 || strlen(nom) == 0) {
        GtkWidget *dialog = gtk_message_dialog_new(
            GTK_WINDOW(win),
            GTK_DIALOG_DESTROY_WITH_PARENT,
            GTK_MESSAGE_ERROR,
            GTK_BUTTONS_OK,
            "Veuillez remplir l'identifiant et le nom !"
        );
        g_signal_connect_swapped(dialog, "response", G_CALLBACK(gtk_widget_destroy), dialog);
        gtk_widget_show(dialog);
        return;
    }
    
    /* Déterminer le sexe */
    gboolean est_homme = gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(radiobutton8));
    const char *sexe = est_homme ? "Homme" : "Femme";
    
    /* Créer le modèle pour le TreeView */
    GtkListStore *store = gtk_list_store_new(2, G_TYPE_STRING, G_TYPE_STRING);
    gtk_tree_view_set_model(GTK_TREE_VIEW(tree_regime), GTK_TREE_MODEL(store));
    g_object_unref(store);
    
    /* Ajouter les colonnes */
    GtkCellRenderer *renderer = gtk_cell_renderer_text_new();
    gtk_tree_view_insert_column_with_attributes(GTK_TREE_VIEW(tree_regime), -1, "Catégorie", renderer, "text", 0, NULL);
    gtk_tree_view_insert_column_with_attributes(GTK_TREE_VIEW(tree_regime), -1, "Recommandation", renderer, "text", 1, NULL);
    
    GtkTreeIter iter;
    
    /* Ajouter les données */
    gtk_list_store_append(store, &iter);
    gtk_list_store_set(store, &iter, 0, "Profil", 1, g_strdup_printf("%s %s (%s)", prenom, nom, sexe), -1);
    
    gtk_list_store_append(store, &iter);
    gtk_list_store_set(store, &iter, 0, "Hydratation", 1, "2-3 litres d'eau par jour", -1);
    
    gtk_list_store_append(store, &iter);
    gtk_list_store_set(store, &iter, 0, "Proteines", 1, "Viandes maigres, poisson, oeufs, legumineuses", -1);
    
    gtk_list_store_append(store, &iter);
    gtk_list_store_set(store, &iter, 0, "Fruits & Legumes", 1, "5 portions par jour (variees et colorees)", -1);
    
    gtk_list_store_append(store, &iter);
    gtk_list_store_set(store, &iter, 0, "Feculents", 1, "Riz complet, pates completes, pain complet", -1);
    
    gtk_list_store_append(store, &iter);
    gtk_list_store_set(store, &iter, 0, "Produits laitiers", 1, "Yaourt, fromage blanc, lait ecreme", -1);
    
    /* Recommandations selon le poids */
    if (strlen(poids_str) > 0) {
        int poids = atoi(poids_str);
        if (poids > 80) {
            gtk_list_store_append(store, &iter);
            gtk_list_store_set(store, &iter, 0, "Poids eleve", 1, "Reduction calorique: limiter sucres et graisses saturees", -1);
            gtk_list_store_append(store, &iter);
            gtk_list_store_set(store, &iter, 0, "Activite physique", 1, "30 min d'exercice modere, 5 jours/semaine", -1);
        } else if (poids < 60) {
            gtk_list_store_append(store, &iter);
            gtk_list_store_set(store, &iter, 0, "Poids faible", 1, "Augmenter apport calorique avec collations saines", -1);
            gtk_list_store_append(store, &iter);
            gtk_list_store_set(store, &iter, 0, "Collations", 1, "Noix, fruits secs, yaourt, fromage blanc", -1);
        }
    }
    
    /* Recommandations selon les conditions de sante */
    if (strlen(maladie_chronique) > 0) {
        gtk_list_store_append(store, &iter);
        gtk_list_store_set(store, &iter, 0, "Maladie chronique", 1, g_strdup_printf("Consulter un medecin: %s", maladie_chronique), -1);
    }
    
    /* Ajouter les infos supplementaires */
    if (strlen(infos_supp) > 0) {
        gtk_list_store_append(store, &iter);
        gtk_list_store_set(store, &iter, 0, "Notes personnelles", 1, infos_supp, -1);
    }
    
    gtk_list_store_append(store, &iter);
    gtk_list_store_set(store, &iter, 0, "Conseil", 1, "Consulter un nutritionniste pour un regime personnalise", -1);
    
    g_print("✔ Proposition de régime générée pour %s\n", identifiant);
}

/* Initialiser le TreeView des centres */
void init_centres_interface(GtkWidget *tree)
{
    if (!tree) {
        g_warning("⚠️ TreeView des centres introuvable !");
        return;
    }

    /* Charger les centres si ce n'est pas fait */
    if (g_centres == NULL) {
        g_centres = load_centres_from_file(g_centres_filepath);
        g_print("✔ %d centres chargés depuis %s\n", g_list_length(g_centres), g_centres_filepath);
    }

    /* Si un modèle existe déjà, on ne recrée pas tout */
    if (gtk_tree_view_get_model(GTK_TREE_VIEW(tree)) != NULL) {
        gtk_tree_view_set_model(GTK_TREE_VIEW(tree), NULL);
    }

    /* Modèle : 6 colonnes (ID, Nom, Adresse, Specialite, Places, Horaires) */
    GtkListStore *store = gtk_list_store_new(
        6,
        G_TYPE_STRING,   /* 0 : ID */
        G_TYPE_STRING,   /* 1 : Nom */
        G_TYPE_STRING,   /* 2 : Adresse */
        G_TYPE_STRING,   /* 3 : Specialite */
        G_TYPE_STRING,   /* 4 : Places */
        G_TYPE_STRING    /* 5 : Horaires */
    );

    gtk_tree_view_set_model(GTK_TREE_VIEW(tree), GTK_TREE_MODEL(store));
    g_object_unref(store);

    /* Ajouter les colonnes avec édition inline */
    GtkCellRenderer *renderer;
    const char *titles[6] = {"ID", "Nom", "Adresse", "Specialite", "Places", "Horaires"};

    for (int i = 0; i < 6; ++i) {
        renderer = gtk_cell_renderer_text_new();
        g_object_set(renderer, "editable", TRUE, NULL);
        
        /* Connecter le signal "edited" pour sauvegarder les modifications */
        g_signal_connect(renderer, "edited", G_CALLBACK(on_centre_cell_edited), GINT_TO_POINTER(i));
        
        gtk_tree_view_insert_column_with_attributes(
            GTK_TREE_VIEW(tree),
            -1,
            titles[i],
            renderer,
            "text", i,
            NULL
        );
    }

    /* Ajouter les centres au TreeView */
    GtkTreeIter iter;
    for (GList *list_iter = g_centres; list_iter != NULL; list_iter = list_iter->next) {
        Centre *centre = (Centre *)list_iter->data;
        
        gtk_list_store_append(store, &iter);
        gtk_list_store_set(store, &iter,
                          0, centre->id,
                          1, centre->nom,
                          2, centre->adresse,
                          3, centre->specialite,
                          4, g_strdup_printf("%d", centre->places),
                          5, centre->horaires,
                          -1);
        
        g_print("✔ Centre ajouté au TreeView : %s\n", centre->nom);
    }

    g_print("✔ TreeView des centres initialisé avec %d centres\n", g_list_length(g_centres));
}

/* Callback : Ajouter un centre - Afficher le formulaire existant */
void on_button18_centres_clicked(GtkButton *button, gpointer user_data)
{
    g_print(">>> BOUTON AJOUTER CENTRE CLIQUÉ\n");
    
    /* Récupérer la fenêtre "ajout d'un centre" en cherchant dans les top-level windows */
    GtkWidget *form_window = NULL;
    GList *toplevels = gtk_window_list_toplevels();
    for (GList *iter = toplevels; iter != NULL; iter = iter->next) {
        GtkWidget *toplevel = GTK_WIDGET(iter->data);
        const char *title = gtk_window_get_title(GTK_WINDOW(toplevel));
        if (title && strcmp(title, "window1") == 0) {
            form_window = toplevel;
            break;
        }
    }
    g_list_free(toplevels);
    
    if (!form_window) {
        g_print("⚠️ Fenêtre 'ajout d'un centre' non trouvée\n");
        return;
    }
    
    /* Vider les champs */
    GtkWidget *entry73 = lookup_widget(form_window, "entry73");
    GtkWidget *entry74 = lookup_widget(form_window, "entry74");
    GtkWidget *entry75 = lookup_widget(form_window, "entry75");
    
    if (entry73) gtk_entry_set_text(GTK_ENTRY(entry73), "");
    if (entry74) gtk_entry_set_text(GTK_ENTRY(entry74), "");
    if (entry75) gtk_entry_set_text(GTK_ENTRY(entry75), "");
    
    /* Afficher la fenêtre */
    gtk_widget_show_all(form_window);
    g_print("✔ Formulaire d'ajout de centre affiché\n");
}

/* Callback : Supprimer un centre */
void on_button20_centres_clicked(GtkButton *button, gpointer user_data)
{
    g_print(">>> BOUTON SUPPRIMER CENTRE CLIQUÉ\n");
    
    GtkWidget *win = gtk_widget_get_toplevel(GTK_WIDGET(button));
    GtkWidget *tree = lookup_widget(win, "treeview8");
    
    if (!tree) {
        g_print("⚠️ TreeView non trouvé\n");
        return;
    }
    
    GtkTreeSelection *selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(tree));
    GtkTreeModel *model;
    GtkTreeIter iter;
    
    if (!gtk_tree_selection_get_selected(selection, &model, &iter)) {
        GtkWidget *dialog = gtk_message_dialog_new(
            GTK_WINDOW(win),
            GTK_DIALOG_DESTROY_WITH_PARENT,
            GTK_MESSAGE_ERROR,
            GTK_BUTTONS_OK,
            "Veuillez sélectionner un centre à supprimer !"
        );
        g_signal_connect_swapped(dialog, "response", G_CALLBACK(gtk_widget_destroy), dialog);
        gtk_widget_show(dialog);
        return;
    }
    
    /* Récupérer l'ID du centre */
    gchar *centre_id = NULL;
    gtk_tree_model_get(model, &iter, 0, &centre_id, -1);
    
    /* Supprimer le centre */
    delete_centre_from_list(&g_centres, centre_id);
    save_centres_to_file(g_centres, g_centres_filepath);
    
    /* Rafraîchir le TreeView */
    init_centres_interface(tree);
    
    GtkWidget *dialog = gtk_message_dialog_new(
        GTK_WINDOW(win),
        GTK_DIALOG_DESTROY_WITH_PARENT,
        GTK_MESSAGE_INFO,
        GTK_BUTTONS_OK,
        "Centre supprimé avec succès !"
    );
    g_signal_connect_swapped(dialog, "response", G_CALLBACK(gtk_widget_destroy), dialog);
    gtk_widget_show(dialog);
    
    g_free(centre_id);
    g_print("✔ Centre supprimé\n");
}

/* Callback : Rechercher un centre */
void on_button21_centres_clicked(GtkButton *button, gpointer user_data)
{
    g_print(">>> BOUTON RECHERCHER CENTRE CLIQUÉ\n");
    
    GtkWidget *win = gtk_widget_get_toplevel(GTK_WIDGET(button));
    GtkWidget *tree = lookup_widget(win, "treeview8");
    GtkWidget *entry = lookup_widget(win, "entry79");
    GtkWidget *combo = lookup_widget(win, "comboboxentry19");  /* Filtre par ID/Nom/Adresse */
    
    if (!tree || !entry || !combo) {
        g_print("⚠️ Widgets non trouvés\n");
        return;
    }
    
    const char *search_text = gtk_entry_get_text(GTK_ENTRY(entry));
    gint filter_type = gtk_combo_box_get_active(GTK_COMBO_BOX(combo));
    
    if (strlen(search_text) == 0) {
        /* Si le champ est vide, afficher tous les centres */
        init_centres_interface(tree);
        return;
    }
    
    /* Récupérer le modèle existant */
    GtkTreeModel *model = gtk_tree_view_get_model(GTK_TREE_VIEW(tree));
    if (!model) {
        g_print("⚠️ Modèle du TreeView non trouvé\n");
        return;
    }
    
    GtkListStore *store = GTK_LIST_STORE(model);
    
    /* Vider le store */
    gtk_list_store_clear(store);
    
    /* Filtrer les centres */
    GtkTreeIter iter;
    int count = 0;
    for (GList *list_iter = g_centres; list_iter != NULL; list_iter = list_iter->next) {
        Centre *centre = (Centre *)list_iter->data;
        gboolean match = FALSE;
        
        switch (filter_type) {
            case 0: /* ID centre */
                match = strstr(centre->id, search_text) != NULL;
                break;
            case 1: /* Nom */
                match = strstr(centre->nom, search_text) != NULL;
                break;
            case 2: /* Adresse */
                match = strstr(centre->adresse, search_text) != NULL;
                break;
            default:
                match = TRUE;
        }
        
        if (match) {
            gtk_list_store_append(store, &iter);
            gtk_list_store_set(store, &iter,
                              0, centre->id,
                              1, centre->nom,
                              2, centre->adresse,
                              3, centre->specialite,
                              4, g_strdup_printf("%d", centre->places),
                              5, centre->horaires,
                              -1);
            count++;
        }
    }
    
    g_print("✔ %d centre(s) trouvé(s)\n", count);
}

/* Initialiser le TreeView des centres pour les entraineurs */
void init_centres_interface_for_trainers(GtkWidget *tree)
{
    if (!tree) {
        g_warning("⚠️ TreeView des centres introuvable !");
        return;
    }

    /* Charger les centres si ce n'est pas fait */
    if (g_centres == NULL) {
        g_centres = load_centres_from_file(g_centres_filepath);
        g_print("✔ %d centres chargés depuis %s\n", g_list_length(g_centres), g_centres_filepath);
    }

    /* Si un modèle existe déjà, on ne recrée pas tout */
    if (gtk_tree_view_get_model(GTK_TREE_VIEW(tree)) != NULL) {
        gtk_tree_view_set_model(GTK_TREE_VIEW(tree), NULL);
    }

    /* Modèle : 4 colonnes (ID, Nom, Specialite, Horaires) */
    GtkListStore *store = gtk_list_store_new(
        4,
        G_TYPE_STRING,   /* 0 : ID */
        G_TYPE_STRING,   /* 1 : Nom */
        G_TYPE_STRING,   /* 2 : Specialite */
        G_TYPE_STRING    /* 3 : Horaires */
    );

    gtk_tree_view_set_model(GTK_TREE_VIEW(tree), GTK_TREE_MODEL(store));
    g_object_unref(store);

    /* Création des colonnes */
    GtkCellRenderer *renderer;
    const char *titles[4] = {"ID", "Nom", "Specialite", "Horaires"};

    for (int i = 0; i < 4; ++i) {
        renderer = gtk_cell_renderer_text_new();
        gtk_tree_view_insert_column_with_attributes(
            GTK_TREE_VIEW(tree),
            -1,
            titles[i],
            renderer,
            "text", i,
            NULL
        );
    }

    /* Ajouter les centres au TreeView */
    GtkTreeIter iter;
    for (GList *list_iter = g_centres; list_iter != NULL; list_iter = list_iter->next) {
        Centre *centre = (Centre *)list_iter->data;
        
        gtk_list_store_append(store, &iter);
        gtk_list_store_set(store, &iter,
                          0, centre->id,
                          1, centre->nom,
                          2, centre->specialite,
                          3, centre->horaires,
                          -1);
        
        g_print("✔ Centre ajouté au TreeView : %s\n", centre->nom);
    }

    g_print("✔ TreeView des centres initialisé avec %d centres\n", g_list_length(g_centres));
}

/* Callback : Inscrire un entraineur à un centre */
void on_button68_clicked(GtkButton *button, gpointer user_data)
{
    g_print(">>> BOUTON INSCRIRE CENTRE CLIQUÉ\n");
    
    GtkWidget *win = gtk_widget_get_toplevel(GTK_WIDGET(button));
    GtkWidget *tree = lookup_widget(win, "treeview10");
    GtkWidget *entry_trainer_id = lookup_widget(win, "entry84");
    
    if (!tree || !entry_trainer_id) {
        g_print("⚠️ Widgets non trouvés\n");
        return;
    }
    
    /* Récupérer l'ID de l'entraineur */
    const char *trainer_id = gtk_entry_get_text(GTK_ENTRY(entry_trainer_id));
    if (strlen(trainer_id) == 0) {
        GtkWidget *dialog = gtk_message_dialog_new(
            GTK_WINDOW(win),
            GTK_DIALOG_DESTROY_WITH_PARENT,
            GTK_MESSAGE_ERROR,
            GTK_BUTTONS_OK,
            "Veuillez entrer votre ID d'entraineur !"
        );
        g_signal_connect_swapped(dialog, "response", G_CALLBACK(gtk_widget_destroy), dialog);
        gtk_widget_show(dialog);
        return;
    }
    
    /* Récupérer la ligne sélectionnée */
    GtkTreeSelection *selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(tree));
    GtkTreeModel *model;
    GtkTreeIter iter;
    
    if (!gtk_tree_selection_get_selected(selection, &model, &iter)) {
        GtkWidget *dialog = gtk_message_dialog_new(
            GTK_WINDOW(win),
            GTK_DIALOG_DESTROY_WITH_PARENT,
            GTK_MESSAGE_ERROR,
            GTK_BUTTONS_OK,
            "Veuillez sélectionner un centre !"
        );
        g_signal_connect_swapped(dialog, "response", G_CALLBACK(gtk_widget_destroy), dialog);
        gtk_widget_show(dialog);
        return;
    }
    
    /* Récupérer les informations du centre */
    gchar *centre_id = NULL;
    gchar *centre_nom = NULL;
    gtk_tree_model_get(model, &iter, 0, &centre_id, 1, &centre_nom, -1);
    
    /* Recharger les demandes */
    if (g_centre_requests != NULL) {
        free_centre_requests_list(g_centre_requests);
        g_centre_requests = NULL;
    }
    g_centre_requests = load_centre_requests_from_file(g_centre_requests_filepath);
    
    /* Générer un ID unique pour la demande */
    char id_demande[50];
    snprintf(id_demande, sizeof(id_demande), "CR%ld", (long)time(NULL));
    
    /* Obtenir la date actuelle */
    time_t now = time(NULL);
    struct tm *tm_now = localtime(&now);
    char date_demande[20];
    strftime(date_demande, sizeof(date_demande), "%d/%m/%Y", tm_now);
    
    /* Créer la demande */
    CentreRequest *new_request = create_centre_request(
        id_demande,
        trainer_id,
        centre_id,
        centre_nom,
        date_demande,
        "en attente"
    );
    
    add_centre_request_to_list(&g_centre_requests, new_request);
    save_centre_requests_to_file(g_centre_requests, g_centre_requests_filepath);
    
    /* Rafraîchir le TreeView des demandes */
    GtkWidget *trainer_requests_tree = lookup_widget(win, "treeview_trainer_requests");
    if (trainer_requests_tree) {
        init_trainer_centre_requests_interface(trainer_requests_tree, trainer_id);
    }
    
    /* Afficher un message de succès */
    GtkWidget *success_dialog = gtk_message_dialog_new(
        GTK_WINDOW(win),
        GTK_DIALOG_DESTROY_WITH_PARENT,
        GTK_MESSAGE_INFO,
        GTK_BUTTONS_OK,
        "Demande d'inscription envoyée avec succès !"
    );
    g_signal_connect_swapped(success_dialog, "response", G_CALLBACK(gtk_widget_destroy), success_dialog);
    gtk_widget_show(success_dialog);
    
    g_free(centre_id);
    g_free(centre_nom);
    
    g_print("✔ Demande d'inscription créée : %s\n", id_demande);
}

/* Initialiser le TreeView des demandes envoyées par l'entraineur */
void init_trainer_centre_requests_interface(GtkWidget *tree, const char *trainer_id)
{
    if (!tree) {
        g_warning("⚠️ TreeView introuvable !");
        return;
    }

    /* Si trainer_id est NULL ou vide, afficher un message */
    if (!trainer_id || strlen(trainer_id) == 0) {
        g_print("⚠️ Aucun ID entraineur fourni - TreeView vide\n");
        trainer_id = "";
    }

    /* Recharger les demandes à chaque fois pour avoir les données à jour */
    if (g_centre_requests != NULL) {
        free_centre_requests_list(g_centre_requests);
        g_centre_requests = NULL;
    }
    
    g_centre_requests = load_centre_requests_from_file(g_centre_requests_filepath);
    g_print("✔ %d demandes chargées depuis %s\n", g_list_length(g_centre_requests), g_centre_requests_filepath);

    /* Récupérer ou créer le modèle */
    GtkTreeModel *model = gtk_tree_view_get_model(GTK_TREE_VIEW(tree));
    GtkListStore *store;
    
    if (model == NULL) {
        /* Créer un nouveau modèle : 4 colonnes (Centre, Date, Statut, Message) */
        store = gtk_list_store_new(
            4,
            G_TYPE_STRING,   /* 0 : Nom Centre */
            G_TYPE_STRING,   /* 1 : Date */
            G_TYPE_STRING,   /* 2 : Statut */
            G_TYPE_STRING    /* 3 : Message */
        );
        gtk_tree_view_set_model(GTK_TREE_VIEW(tree), GTK_TREE_MODEL(store));
        g_object_unref(store);
        
        /* Création des colonnes (une seule fois) */
        GtkCellRenderer *renderer;
        const char *titles[4] = {"Centre", "Date", "Statut", "Message"};

        for (int i = 0; i < 4; ++i) {
            renderer = gtk_cell_renderer_text_new();
            gtk_tree_view_insert_column_with_attributes(
                GTK_TREE_VIEW(tree),
                -1,
                titles[i],
                renderer,
                "text", i,
                NULL
            );
        }
    } else {
        /* Réutiliser le modèle existant et le vider */
        store = GTK_LIST_STORE(model);
        gtk_list_store_clear(store);
    }

    /* Ajouter les demandes au TreeView */
    GtkTreeIter iter;
    int count = 0;
    for (GList *list_iter = g_centre_requests; list_iter != NULL; list_iter = list_iter->next) {
        CentreRequest *request = (CentreRequest *)list_iter->data;
        
        /* Afficher seulement les demandes de cet entraineur */
        if (strcmp(request->id_entraineur, trainer_id) == 0) {
            /* Générer un message selon le statut */
            const char *message = "";
            if (strcmp(request->statut, "acceptée") == 0) {
                message = "✔ Acceptée";
            } else if (strcmp(request->statut, "refusée") == 0) {
                message = "✗ Refusée";
            } else {
                message = "⏳ En attente";
            }
            
            gtk_list_store_append(store, &iter);
            gtk_list_store_set(store, &iter,
                              0, request->nom_centre,
                              1, request->date_demande,
                              2, request->statut,
                              3, message,
                              -1);
            
            count++;
            g_print("✔ Demande ajoutée au TreeView : %s (%s)\n", request->id_demande, request->statut);
        }
    }

    g_print("✔ TreeView des demandes initialisé avec %d demandes pour l'entraineur %s\n", count, trainer_id);
}

/* Initialiser le TreeView des demandes au démarrage avec l'ID de l'entraineur */
void init_trainer_centre_requests_on_startup(GtkWidget *tree, const char *trainer_id)
{
    if (!tree || !trainer_id || strlen(trainer_id) == 0) {
        g_print("⚠️ TreeView ou trainer_id invalide\n");
        return;
    }
    
    /* Initialiser le TreeView avec l'ID de l'entraineur */
    init_trainer_centre_requests_interface(tree, trainer_id);
    g_print("✔ TreeView des demandes initialisé au démarrage pour l'entraineur : %s\n", trainer_id);
}

/* Callback : Édition inline des cellules du TreeView des centres */
void on_centre_cell_edited(GtkCellRendererText *cell, gchar *path_string, gchar *new_text, gpointer user_data)
{
    int column = GPOINTER_TO_INT(user_data);
    GtkTreePath *path = gtk_tree_path_new_from_string(path_string);
    
    /* Récupérer le TreeView depuis la fenêtre admin */
    GtkWidget *admin_win = NULL;
    GList *toplevels = gtk_window_list_toplevels();
    for (GList *iter = toplevels; iter != NULL; iter = iter->next) {
        GtkWidget *toplevel = GTK_WIDGET(iter->data);
        const char *title = gtk_window_get_title(GTK_WINDOW(toplevel));
        if (title && strcmp(title, "gestionadmin") == 0) {
            admin_win = toplevel;
            break;
        }
    }
    g_list_free(toplevels);
    
    if (!admin_win) {
        gtk_tree_path_free(path);
        return;
    }
    
    GtkWidget *tree = lookup_widget(admin_win, "treeview8");
    if (!tree) {
        gtk_tree_path_free(path);
        return;
    }
    
    GtkTreeModel *model = gtk_tree_view_get_model(GTK_TREE_VIEW(tree));
    GtkTreeIter iter;
    
    if (!gtk_tree_model_get_iter(model, &iter, path)) {
        gtk_tree_path_free(path);
        return;
    }
    
    /* Récupérer l'ID du centre */
    gchar *centre_id = NULL;
    gtk_tree_model_get(model, &iter, 0, &centre_id, -1);
    
    /* Trouver le centre et le mettre à jour */
    Centre *centre = find_centre_by_id(g_centres, centre_id);
    if (centre) {
        switch (column) {
            case 0: /* ID */
                strncpy(centre->id, new_text, sizeof(centre->id) - 1);
                break;
            case 1: /* Nom */
                strncpy(centre->nom, new_text, sizeof(centre->nom) - 1);
                break;
            case 2: /* Adresse */
                strncpy(centre->adresse, new_text, sizeof(centre->adresse) - 1);
                break;
            case 3: /* Specialite */
                strncpy(centre->specialite, new_text, sizeof(centre->specialite) - 1);
                break;
            case 4: /* Places */
                centre->places = atoi(new_text);
                break;
            case 5: /* Horaires */
                strncpy(centre->horaires, new_text, sizeof(centre->horaires) - 1);
                break;
        }
        
        /* Mettre à jour le TreeView */
        gtk_list_store_set(GTK_LIST_STORE(model), &iter, column, new_text, -1);
        
        /* Sauvegarder dans le fichier */
        save_centres_to_file(g_centres, g_centres_filepath);
        g_print("✔ Centre modifié et sauvegardé\n");
    }
    
    gtk_tree_path_free(path);
    g_free(centre_id);
}

/* Callback : Valider le formulaire d'ajout de centre */
void on_centre_form_ok_clicked(GtkButton *button, gpointer user_data)
{
    g_print(">>> BOUTON OK FORMULAIRE CENTRE CLIQUÉ\n");
    
    /* Récupérer la fenêtre du formulaire en cherchant le parent du bouton */
    GtkWidget *form_window = gtk_widget_get_toplevel(GTK_WIDGET(button));
    
    if (!form_window || !GTK_IS_WINDOW(form_window)) {
        g_print("⚠️ Fenêtre du formulaire non trouvée\n");
        return;
    }
    
    /* Récupérer les champs du formulaire */
    GtkWidget *entry73 = lookup_widget(form_window, "entry73");  /* ID */
    GtkWidget *entry74 = lookup_widget(form_window, "entry74");  /* Nom */
    GtkWidget *entry75 = lookup_widget(form_window, "entry75");  /* Adresse */
    
    if (!entry73 || !entry74 || !entry75) {
        g_print("⚠️ Champs du formulaire non trouvés\n");
        return;
    }
    
    /* Récupérer les valeurs */
    const char *id = gtk_entry_get_text(GTK_ENTRY(entry73));
    const char *nom = gtk_entry_get_text(GTK_ENTRY(entry74));
    const char *adresse = gtk_entry_get_text(GTK_ENTRY(entry75));
    
    /* Valider les champs obligatoires */
    if (strlen(id) == 0 || strlen(nom) == 0 || strlen(adresse) == 0) {
        GtkWidget *error_dialog = gtk_message_dialog_new(
            GTK_WINDOW(form_window),
            GTK_DIALOG_DESTROY_WITH_PARENT,
            GTK_MESSAGE_ERROR,
            GTK_BUTTONS_OK,
            "Veuillez remplir tous les champs obligatoires !"
        );
        g_signal_connect_swapped(error_dialog, "response", G_CALLBACK(gtk_widget_destroy), error_dialog);
        gtk_widget_show(error_dialog);
        return;
    }
    
    /* Créer et ajouter le centre */
    Centre *new_centre = create_centre(id, nom, adresse, "fitness", 0, "Lun-Dim");
    add_centre_to_list(&g_centres, new_centre);
    save_centres_to_file(g_centres, g_centres_filepath);
    
    /* Rafraîchir le TreeView */
    GtkWidget *admin_win = NULL;
    GList *toplevels = gtk_window_list_toplevels();
    for (GList *iter = toplevels; iter != NULL; iter = iter->next) {
        GtkWidget *toplevel = GTK_WIDGET(iter->data);
        const char *title = gtk_window_get_title(GTK_WINDOW(toplevel));
        if (title && strcmp(title, "gestionadmin") == 0) {
            admin_win = toplevel;
            break;
        }
    }
    g_list_free(toplevels);
    
    if (admin_win) {
        GtkWidget *tree = lookup_widget(admin_win, "treeview8");
        if (tree) {
            init_centres_interface(tree);
        }
    }
    
    /* Vider et fermer le formulaire */
    gtk_entry_set_text(GTK_ENTRY(entry73), "");
    gtk_entry_set_text(GTK_ENTRY(entry74), "");
    gtk_entry_set_text(GTK_ENTRY(entry75), "");
    gtk_widget_hide(form_window);
    
    g_print("✔ Centre ajouté avec succès\n");
}

/* Initialiser le TreeView des demandes d'inscription à centre pour l'admin */
void init_centre_requests_for_admin_interface(GtkWidget *tree)
{
    if (!tree) {
        g_warning("⚠️ TreeView introuvable !");
        return;
    }

    /* Recharger les demandes */
    if (g_centre_requests != NULL) {
        free_centre_requests_list(g_centre_requests);
        g_centre_requests = NULL;
    }
    
    g_centre_requests = load_centre_requests_from_file(g_centre_requests_filepath);
    g_print("✔ %d demandes chargées depuis %s\n", g_list_length(g_centre_requests), g_centre_requests_filepath);

    /* Récupérer ou créer le modèle */
    GtkTreeModel *model = gtk_tree_view_get_model(GTK_TREE_VIEW(tree));
    GtkListStore *store;
    
    if (model == NULL) {
        /* Créer un nouveau modèle : 5 colonnes (ID Entraineur, Centre, Date, Statut, ID Demande) */
        store = gtk_list_store_new(
            5,
            G_TYPE_STRING,   /* 0 : ID Entraineur */
            G_TYPE_STRING,   /* 1 : Nom Centre */
            G_TYPE_STRING,   /* 2 : Date */
            G_TYPE_STRING,   /* 3 : Statut */
            G_TYPE_STRING    /* 4 : ID Demande (caché) */
        );
        gtk_tree_view_set_model(GTK_TREE_VIEW(tree), GTK_TREE_MODEL(store));
        g_object_unref(store);
        
        /* Création des colonnes (une seule fois) */
        GtkCellRenderer *renderer;
        const char *titles[4] = {"ID Entraineur", "Centre", "Date", "Statut"};

        for (int i = 0; i < 4; ++i) {
            renderer = gtk_cell_renderer_text_new();
            gtk_tree_view_insert_column_with_attributes(
                GTK_TREE_VIEW(tree),
                -1,
                titles[i],
                renderer,
                "text", i,
                NULL
            );
        }
    } else {
        /* Réutiliser le modèle existant et le vider */
        store = GTK_LIST_STORE(model);
        gtk_list_store_clear(store);
    }

    /* Ajouter les demandes au TreeView */
    GtkTreeIter iter;
    int count = 0;
    for (GList *list_iter = g_centre_requests; list_iter != NULL; list_iter = list_iter->next) {
        CentreRequest *request = (CentreRequest *)list_iter->data;
        
        gtk_list_store_append(store, &iter);
        gtk_list_store_set(store, &iter,
                          0, request->id_entraineur,
                          1, request->nom_centre,
                          2, request->date_demande,
                          3, request->statut,
                          4, request->id_demande,
                          -1);
        
        count++;
        g_print("✔ Demande ajoutée au TreeView : %s\n", request->id_demande);
    }

    g_print("✔ TreeView des demandes (admin) initialisé avec %d demandes\n", count);
}

/* Callback : Accepter une demande d'inscription à centre */
void on_button_accepter_centre_clicked(GtkButton *button, gpointer user_data)
{
    g_print(">>> BOUTON ACCEPTER CENTRE CLIQUÉ\n");
    
    GtkWidget *win = gtk_widget_get_toplevel(GTK_WIDGET(button));
    GtkWidget *tree = lookup_widget(win, "treeview_centre_requests");
    
    if (!tree) {
        g_print("⚠️ TreeView non trouvé\n");
        return;
    }
    
    /* Récupérer la ligne sélectionnée */
    GtkTreeSelection *selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(tree));
    GtkTreeModel *model;
    GtkTreeIter iter;
    
    if (!gtk_tree_selection_get_selected(selection, &model, &iter)) {
        GtkWidget *dialog = gtk_message_dialog_new(
            GTK_WINDOW(win),
            GTK_DIALOG_DESTROY_WITH_PARENT,
            GTK_MESSAGE_ERROR,
            GTK_BUTTONS_OK,
            "Veuillez sélectionner une demande !"
        );
        g_signal_connect_swapped(dialog, "response", G_CALLBACK(gtk_widget_destroy), dialog);
        gtk_widget_show(dialog);
        return;
    }
    
    /* Récupérer l'ID de la demande */
    gchar *id_demande = NULL;
    gtk_tree_model_get(model, &iter, 4, &id_demande, -1);
    
    /* Trouver et mettre à jour la demande */
    CentreRequest *request = find_centre_request_by_id(g_centre_requests, id_demande);
    if (request) {
        strncpy(request->statut, "acceptée", sizeof(request->statut) - 1);
        save_centre_requests_to_file(g_centre_requests, g_centre_requests_filepath);
        
        /* Rafraîchir le TreeView */
        init_centre_requests_for_admin_interface(tree);
        
        GtkWidget *success_dialog = gtk_message_dialog_new(
            GTK_WINDOW(win),
            GTK_DIALOG_DESTROY_WITH_PARENT,
            GTK_MESSAGE_INFO,
            GTK_BUTTONS_OK,
            "Demande acceptée !"
        );
        g_signal_connect_swapped(success_dialog, "response", G_CALLBACK(gtk_widget_destroy), success_dialog);
        gtk_widget_show(success_dialog);
        
        g_print("✔ Demande acceptée : %s\n", id_demande);
    }
    
    g_free(id_demande);
}

/* Callback : Refuser une demande d'inscription à centre */
void on_button_refuser_centre_clicked(GtkButton *button, gpointer user_data)
{
    g_print(">>> BOUTON REFUSER CENTRE CLIQUÉ\n");
    
    GtkWidget *win = gtk_widget_get_toplevel(GTK_WIDGET(button));
    GtkWidget *tree = lookup_widget(win, "treeview_centre_requests");
    
    if (!tree) {
        g_print("⚠️ TreeView non trouvé\n");
        return;
    }
    
    /* Récupérer la ligne sélectionnée */
    GtkTreeSelection *selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(tree));
    GtkTreeModel *model;
    GtkTreeIter iter;
    
    if (!gtk_tree_selection_get_selected(selection, &model, &iter)) {
        GtkWidget *dialog = gtk_message_dialog_new(
            GTK_WINDOW(win),
            GTK_DIALOG_DESTROY_WITH_PARENT,
            GTK_MESSAGE_ERROR,
            GTK_BUTTONS_OK,
            "Veuillez sélectionner une demande !"
        );
        g_signal_connect_swapped(dialog, "response", G_CALLBACK(gtk_widget_destroy), dialog);
        gtk_widget_show(dialog);
        return;
    }
    
    /* Récupérer l'ID de la demande */
    gchar *id_demande = NULL;
    gtk_tree_model_get(model, &iter, 4, &id_demande, -1);
    
    /* Trouver et mettre à jour la demande */
    CentreRequest *request = find_centre_request_by_id(g_centre_requests, id_demande);
    if (request) {
        strncpy(request->statut, "refusée", sizeof(request->statut) - 1);
        save_centre_requests_to_file(g_centre_requests, g_centre_requests_filepath);
        
        /* Rafraîchir le TreeView */
        init_centre_requests_for_admin_interface(tree);
        
        GtkWidget *success_dialog = gtk_message_dialog_new(
            GTK_WINDOW(win),
            GTK_DIALOG_DESTROY_WITH_PARENT,
            GTK_MESSAGE_INFO,
            GTK_BUTTONS_OK,
            "Demande refusée !"
        );
        g_signal_connect_swapped(success_dialog, "response", G_CALLBACK(gtk_widget_destroy), success_dialog);
        gtk_widget_show(success_dialog);
        
        g_print("✔ Demande refusée : %s\n", id_demande);
    }
    
    g_free(id_demande);
}

/* Callback pour le bouton de validation du formulaire d'ajout de membre */
void on_button26_clicked(GtkButton *button, gpointer user_data)
{
    g_print(">>> BOUTON VALIDER (AJOUTER MEMBRE) CLIQUÉ\n");
    
    if (!WIN_AJOUT_MEMBRE) {
        g_warning("❌ Fenêtre d'ajout de membre non initialisée");
        return;
    }
    
    /* Récupérer les champs du formulaire */
    GtkWidget *entry_id = lookup_widget(WIN_AJOUT_MEMBRE, "entry9");
    GtkWidget *entry_nom = lookup_widget(WIN_AJOUT_MEMBRE, "entry10");
    GtkWidget *entry_prenom = lookup_widget(WIN_AJOUT_MEMBRE, "entry11");
    GtkWidget *entry_telephone = lookup_widget(WIN_AJOUT_MEMBRE, "entry12");
    GtkWidget *combo_jour = lookup_widget(WIN_AJOUT_MEMBRE, "combo_entry4");
    GtkWidget *combo_mois = lookup_widget(WIN_AJOUT_MEMBRE, "combo_entry2");
    GtkWidget *combo_annee = lookup_widget(WIN_AJOUT_MEMBRE, "combo_entry3");
    GtkWidget *radio_femme = lookup_widget(WIN_AJOUT_MEMBRE, "radio_femme");
    
    if (!entry_id || !entry_nom || !entry_prenom || !entry_telephone) {
        g_warning("❌ Certains champs du formulaire sont introuvables");
        return;
    }
    
    const char *username = gtk_entry_get_text(GTK_ENTRY(entry_id));
    const char *nom = gtk_entry_get_text(GTK_ENTRY(entry_nom));
    const char *prenom = gtk_entry_get_text(GTK_ENTRY(entry_prenom));
    const char *telephone = gtk_entry_get_text(GTK_ENTRY(entry_telephone));
    
    /* Validation des champs obligatoires */
    if (strlen(username) == 0 || strlen(nom) == 0 || strlen(prenom) == 0 || strlen(telephone) == 0) {
        GtkWidget *error_dialog = gtk_message_dialog_new(
            GTK_WINDOW(WIN_AJOUT_MEMBRE),
            GTK_DIALOG_MODAL,
            GTK_MESSAGE_ERROR,
            GTK_BUTTONS_OK,
            "Erreur: Tous les champs sont obligatoires!"
        );
        gtk_dialog_run(GTK_DIALOG(error_dialog));
        gtk_widget_destroy(error_dialog);
        return;
    }
    
    /* Déterminer le sexe */
    const char *sexe = "Homme";
    if (radio_femme && gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(radio_femme))) {
        sexe = "Femme";
    }
    
    /* Calculer l'âge à partir de la date de naissance */
    const char *jour_str = gtk_entry_get_text(GTK_ENTRY(combo_jour));
    const char *mois_str = gtk_entry_get_text(GTK_ENTRY(combo_mois));
    const char *annee_str = gtk_entry_get_text(GTK_ENTRY(combo_annee));
    
    int jour = atoi(jour_str);
    int mois = atoi(mois_str);
    int annee = atoi(annee_str);
    
    time_t now = time(NULL);
    struct tm *timeinfo = localtime(&now);
    int current_year = timeinfo->tm_year + 1900;
    int current_month = timeinfo->tm_mon + 1;
    int current_day = timeinfo->tm_mday;
    
    int age = current_year - annee;
    if (current_month < mois || (current_month == mois && current_day < jour)) {
        age--;
    }
    
    if (age < 0) {
        GtkWidget *error_dialog = gtk_message_dialog_new(
            GTK_WINDOW(WIN_AJOUT_MEMBRE),
            GTK_DIALOG_MODAL,
            GTK_MESSAGE_ERROR,
            GTK_BUTTONS_OK,
            "Erreur: Date de naissance invalide!"
        );
        gtk_dialog_run(GTK_DIALOG(error_dialog));
        gtk_widget_destroy(error_dialog);
        return;
    }
    
    /* Créer le membre */
    Member *new_member = create_member(username, nom, prenom, sexe, age, telephone);
    if (!new_member) {
        g_warning("❌ Erreur lors de la création du membre");
        return;
    }
    
    /* Charger la liste existante */
    g_members = load_members_from_file(g_members_filepath);
    
    /* Vérifier si le membre existe déjà */
    if (find_member_by_username(g_members, username)) {
        GtkWidget *error_dialog = gtk_message_dialog_new(
            GTK_WINDOW(WIN_AJOUT_MEMBRE),
            GTK_DIALOG_MODAL,
            GTK_MESSAGE_ERROR,
            GTK_BUTTONS_OK,
            "Erreur: Ce membre existe déjà!"
        );
        gtk_dialog_run(GTK_DIALOG(error_dialog));
        gtk_widget_destroy(error_dialog);
        free(new_member);
        return;
    }
    
    /* Ajouter le membre à la liste */
    g_members = g_list_append(g_members, new_member);
    
    /* Sauvegarder dans le fichier */
    save_members_to_file(g_members, g_members_filepath);
    
    g_print("✔ Membre ajouté: %s %s\n", nom, prenom);
    
    /* Rafraîchir le TreeView des membres */
    if (WIN_ADMIN) {
        GtkWidget *tree = lookup_widget(WIN_ADMIN, "treeview11");
        if (tree) {
            init_members_interface();
            g_print("✔ TreeView des membres rafraîchi\n");
        }
    }
    
    /* Afficher un message de succès */
    GtkWidget *success_dialog = gtk_message_dialog_new(
        GTK_WINDOW(WIN_AJOUT_MEMBRE),
        GTK_DIALOG_MODAL,
        GTK_MESSAGE_INFO,
        GTK_BUTTONS_OK,
        "Membre ajouté avec succès!"
    );
    gtk_dialog_run(GTK_DIALOG(success_dialog));
    gtk_widget_destroy(success_dialog);
    
    /* Fermer le formulaire */
    gtk_widget_destroy(WIN_AJOUT_MEMBRE);
    WIN_AJOUT_MEMBRE = NULL;
}

/* Fonction pour afficher les statistiques des entraineurs dans treeview12 */
void init_trainers_statistics_interface(GtkWidget *tree)
{
    if (!tree) {
        g_warning("⚠️ TreeView 'treeview12' introuvable !");
        return;
    }

    /* Initialiser le TreeView avec 4 colonnes */
    GtkListStore *store = gtk_list_store_new(
        4,
        G_TYPE_STRING,   /* 0 : Statistique */
        G_TYPE_STRING,   /* 1 : Valeur */
        G_TYPE_STRING,   /* 2 : Détails */
        G_TYPE_STRING    /* 3 : Pourcentage */
    );

    gtk_tree_view_set_model(GTK_TREE_VIEW(tree), GTK_TREE_MODEL(store));
    g_object_unref(store);

    /* Créer les colonnes */
    GtkCellRenderer *renderer;
    const char *titles[4] = {"Statistique", "Valeur", "Détails", "Pourcentage"};

    for (int i = 0; i < 4; ++i) {
        renderer = gtk_cell_renderer_text_new();
        gtk_tree_view_insert_column_with_attributes(
            GTK_TREE_VIEW(tree),
            -1,
            titles[i],
            renderer,
            "text", i,
            NULL
        );
    }

    /* Charger les coaches et centres */
    load_coaches_from_file(&g_coaches, g_coaches_filepath);
    g_centres = load_centres_from_file(g_centres_filepath);
    g_centre_requests = load_centre_requests_from_file(g_centre_requests_filepath);

    int total_coaches = g_list_length(g_coaches);
    int total_centres = g_list_length(g_centres);
    int pending_requests = 0;
    int accepted_requests = 0;
    int refused_requests = 0;

    /* Compter les demandes par statut */
    for (GList *node = g_centre_requests; node; node = node->next) {
        CentreRequest *req = (CentreRequest *)node->data;
        if (strcmp(req->statut, "en attente") == 0) {
            pending_requests++;
        } else if (strcmp(req->statut, "acceptée") == 0) {
            accepted_requests++;
        } else if (strcmp(req->statut, "refusée") == 0) {
            refused_requests++;
        }
    }

    int total_requests = pending_requests + accepted_requests + refused_requests;

    /* Ajouter les statistiques au TreeView */
    GtkTreeIter iter;
    char value_str[50], details_str[200], percent_str[50];

    /* Statistique 1: Total des entraineurs */
    gtk_list_store_append(store, &iter);
    snprintf(value_str, sizeof(value_str), "%d", total_coaches);
    snprintf(percent_str, sizeof(percent_str), "100%%");
    gtk_list_store_set(store, &iter,
        0, "Total Entraineurs",
        1, value_str,
        2, "Nombre total d'entraineurs inscrits",
        3, percent_str,
        -1);

    /* Statistique 2: Total des centres */
    gtk_list_store_append(store, &iter);
    snprintf(value_str, sizeof(value_str), "%d", total_centres);
    snprintf(percent_str, sizeof(percent_str), "100%%");
    gtk_list_store_set(store, &iter,
        0, "Total Centres",
        1, value_str,
        2, "Nombre total de centres",
        3, percent_str,
        -1);

    /* Statistique 3: Demandes en attente */
    gtk_list_store_append(store, &iter);
    snprintf(value_str, sizeof(value_str), "%d", pending_requests);
    if (total_requests > 0) {
        snprintf(percent_str, sizeof(percent_str), "%.1f%%", 
                 (float)pending_requests / total_requests * 100);
    } else {
        snprintf(percent_str, sizeof(percent_str), "0%%");
    }
    snprintf(details_str, sizeof(details_str), "Demandes en attente de validation");
    gtk_list_store_set(store, &iter,
        0, "Demandes En Attente",
        1, value_str,
        2, details_str,
        3, percent_str,
        -1);

    /* Statistique 4: Demandes acceptées */
    gtk_list_store_append(store, &iter);
    snprintf(value_str, sizeof(value_str), "%d", accepted_requests);
    if (total_requests > 0) {
        snprintf(percent_str, sizeof(percent_str), "%.1f%%", 
                 (float)accepted_requests / total_requests * 100);
    } else {
        snprintf(percent_str, sizeof(percent_str), "0%%");
    }
    snprintf(details_str, sizeof(details_str), "Demandes validées par l'admin");
    gtk_list_store_set(store, &iter,
        0, "Demandes Acceptées",
        1, value_str,
        2, details_str,
        3, percent_str,
        -1);

    /* Statistique 5: Demandes refusées */
    gtk_list_store_append(store, &iter);
    snprintf(value_str, sizeof(value_str), "%d", refused_requests);
    if (total_requests > 0) {
        snprintf(percent_str, sizeof(percent_str), "%.1f%%", 
                 (float)refused_requests / total_requests * 100);
    } else {
        snprintf(percent_str, sizeof(percent_str), "0%%");
    }
    snprintf(details_str, sizeof(details_str), "Demandes refusées par l'admin");
    gtk_list_store_set(store, &iter,
        0, "Demandes Refusées",
        1, value_str,
        2, details_str,
        3, percent_str,
        -1);

    

    g_print("✔ Statistiques des entraineurs affichées\n");
}

/* =======================================================
 *  🚪 LOGOUT - DÉCONNEXION
 * ======================================================= */

void
on_button_logout_admin_clicked(GtkButton *button, gpointer user_data)
{
    if (WIN_ADMIN) {
        gtk_widget_hide(WIN_ADMIN);
        WIN_ADMIN = NULL;
    }
    
    if (WIN_LOGIN) {
        gtk_widget_show(WIN_LOGIN);
    }
    
    g_print("✔ Admin déconnecté\n");
}

void
on_button_logout_membres_clicked(GtkButton *button, gpointer user_data)
{
    if (WIN_MEMBRE) {
        gtk_widget_hide(WIN_MEMBRE);
        WIN_MEMBRE = NULL;
    }
    
    if (WIN_LOGIN) {
        gtk_widget_show(WIN_LOGIN);
    }
    
    g_print("✔ Membre déconnecté\n");
}

void
on_button_logout_entraineurs_clicked(GtkButton *button, gpointer user_data)
{
    if (WIN_ENTRAINEUR) {
        gtk_widget_hide(WIN_ENTRAINEUR);
        WIN_ENTRAINEUR = NULL;
    }
    
    if (WIN_LOGIN) {
        gtk_widget_show(WIN_LOGIN);
    }
    
    g_print("✔ Entraineur déconnecté\n");
}

/* =======================================================
 *  ⚙️ GESTION DES ÉQUIPEMENTS - ADMIN
 * ======================================================= */

/* Forward declaration */
static void on_clist_select_row(GtkCList *clist, gint row, gint column,
                               GdkEvent *event, gpointer user_data);

/**
 * Initialise l'interface de gestion des équipements (clist5)
 */
void init_equipments_interface(GtkWidget *tree)
{
    if (!tree) {
        g_warning("⚠️ TreeView 'clist5' introuvable !");
        return;
    }

    /* Charger les équipements */
    if (g_equipments) {
        free_equipments_list(g_equipments);
    }
    g_equipments = load_equipments(g_equipments_filepath);

    /* Vider le CList */
    gtk_clist_clear(GTK_CLIST(tree));

    /* Rendre les colonnes éditables */
    for (int i = 0; i < 5; i++) {
        gtk_clist_set_column_auto_resize(GTK_CLIST(tree), i, TRUE);
    }

    /* Ajouter les équipements au CList */
    for (GList *iter = g_equipments; iter; iter = iter->next) {
        Equipment *eq = (Equipment *)iter->data;
        const char *row_data[] = {
            eq->code_barre,
            eq->disponibilite,
            eq->marque,
            eq->centre,
            eq->type
        };
        gtk_clist_append(GTK_CLIST(tree), (gchar **)row_data);
    }

    /* Connecter le signal d'édition des cellules */
    g_signal_connect(G_OBJECT(tree), "select-row",
                    G_CALLBACK(on_clist_select_row), NULL);

    g_print("✔ Interface équipements initialisée (%d équipements)\n", 
            g_list_length(g_equipments));
}

/**
 * Callback bouton "Ajouter" équipement (button10)
 */
void on_button10_equipment_clicked(GtkButton *button, gpointer user_data)
{
    GtkWidget *dialog = gtk_dialog_new_with_buttons(
        "Ajouter un Équipement",
        GTK_WINDOW(WIN_ADMIN),
        GTK_DIALOG_MODAL | GTK_DIALOG_DESTROY_WITH_PARENT,
        GTK_STOCK_OK, GTK_RESPONSE_OK,
        GTK_STOCK_CANCEL, GTK_RESPONSE_CANCEL,
        NULL);

    GtkWidget *content = gtk_dialog_get_content_area(GTK_DIALOG(dialog));
    gtk_container_set_border_width(GTK_CONTAINER(content), 10);

    /* Champs du formulaire */
    GtkWidget *label_code = gtk_label_new("Code à Barre:");
    GtkWidget *entry_code = gtk_entry_new();
    
    GtkWidget *label_type = gtk_label_new("Type:");
    GtkWidget *combo_type = gtk_combo_box_entry_new_text();
    gtk_combo_box_append_text(GTK_COMBO_BOX(combo_type), "Haltère");
    gtk_combo_box_append_text(GTK_COMBO_BOX(combo_type), "Tapis Roulant");
    gtk_combo_box_append_text(GTK_COMBO_BOX(combo_type), "Vélo Stationnaire");
    gtk_combo_box_append_text(GTK_COMBO_BOX(combo_type), "Banc de Musculation");
    gtk_combo_box_set_active(GTK_COMBO_BOX(combo_type), 0);

    GtkWidget *label_centre = gtk_label_new("Centre:");
    GtkWidget *combo_centre = gtk_combo_box_entry_new_text();
    gtk_combo_box_append_text(GTK_COMBO_BOX(combo_centre), "Marsa");
    gtk_combo_box_append_text(GTK_COMBO_BOX(combo_centre), "Ariana");
    gtk_combo_box_append_text(GTK_COMBO_BOX(combo_centre), "Lac 1");
    gtk_combo_box_set_active(GTK_COMBO_BOX(combo_centre), 0);

    GtkWidget *label_marque = gtk_label_new("Marque:");
    GtkWidget *entry_marque = gtk_entry_new();

    /* Layout */
    GtkWidget *table = gtk_table_new(4, 2, FALSE);
    gtk_table_set_row_spacings(GTK_TABLE(table), 5);
    gtk_table_set_col_spacings(GTK_TABLE(table), 5);

    gtk_table_attach(GTK_TABLE(table), label_code, 0, 1, 0, 1, GTK_FILL, GTK_FILL, 0, 0);
    gtk_table_attach(GTK_TABLE(table), entry_code, 1, 2, 0, 1, GTK_FILL | GTK_EXPAND, GTK_FILL, 0, 0);

    gtk_table_attach(GTK_TABLE(table), label_type, 0, 1, 1, 2, GTK_FILL, GTK_FILL, 0, 0);
    gtk_table_attach(GTK_TABLE(table), combo_type, 1, 2, 1, 2, GTK_FILL | GTK_EXPAND, GTK_FILL, 0, 0);

    gtk_table_attach(GTK_TABLE(table), label_centre, 0, 1, 2, 3, GTK_FILL, GTK_FILL, 0, 0);
    gtk_table_attach(GTK_TABLE(table), combo_centre, 1, 2, 2, 3, GTK_FILL | GTK_EXPAND, GTK_FILL, 0, 0);

    gtk_table_attach(GTK_TABLE(table), label_marque, 0, 1, 3, 4, GTK_FILL, GTK_FILL, 0, 0);
    gtk_table_attach(GTK_TABLE(table), entry_marque, 1, 2, 3, 4, GTK_FILL | GTK_EXPAND, GTK_FILL, 0, 0);

    gtk_box_pack_start(GTK_BOX(content), table, TRUE, TRUE, 0);
    gtk_widget_show_all(content);

    if (gtk_dialog_run(GTK_DIALOG(dialog)) == GTK_RESPONSE_OK) {
        const char *code = gtk_entry_get_text(GTK_ENTRY(entry_code));
        const char *type = gtk_combo_box_get_active_text(GTK_COMBO_BOX(combo_type));
        const char *centre = gtk_combo_box_get_active_text(GTK_COMBO_BOX(combo_centre));
        const char *marque = gtk_entry_get_text(GTK_ENTRY(entry_marque));

        /* Validation */
        if (strlen(code) == 0 || strlen(marque) == 0) {
            GtkWidget *error_dialog = gtk_message_dialog_new(GTK_WINDOW(dialog), GTK_DIALOG_MODAL,
                GTK_MESSAGE_ERROR, GTK_BUTTONS_OK,
                "Veuillez remplir tous les champs !");
            gtk_dialog_run(GTK_DIALOG(error_dialog));
            gtk_widget_destroy(error_dialog);
        } else if (find_equipment_by_code(g_equipments, code) != NULL) {
            GtkWidget *error_dialog = gtk_message_dialog_new(GTK_WINDOW(dialog), GTK_DIALOG_MODAL,
                GTK_MESSAGE_ERROR, GTK_BUTTONS_OK,
                "Code à barre déjà existant !");
            gtk_dialog_run(GTK_DIALOG(error_dialog));
            gtk_widget_destroy(error_dialog);
        } else {
            /* Créer l'équipement */
            char id[50];
            snprintf(id, sizeof(id), "%d", (int)g_list_length(g_equipments) + 1);
            Equipment *eq = create_equipment(id, code, type, marque, centre, "Disponible");
            g_equipments = g_list_append(g_equipments, eq);
            save_equipments(g_equipments, g_equipments_filepath);

            /* Rafraîchir l'interface */
            GtkWidget *clist5 = lookup_widget(WIN_ADMIN, "clist5");
            init_equipments_interface(clist5);

            g_print("✔ Équipement ajouté : %s\n", code);
        }
    }

    gtk_widget_destroy(dialog);
}

/**
 * Callback pour édition directe dans le CList (double-clic)
 */
static void on_clist_select_row(GtkCList *clist, gint row, gint column,
                               GdkEvent *event, gpointer user_data)
{
    /* Double-clic pour éditer */
    if (event && event->type == GDK_2BUTTON_PRESS) {
        /* Récupérer l'équipement à éditer */
        Equipment *eq = (Equipment *)g_list_nth_data(g_equipments, row);
        if (!eq) return;

        /* Créer un formulaire modal d'édition */
        GtkWidget *dialog = gtk_dialog_new_with_buttons(
            "Modifier Équipement",
            GTK_WINDOW(WIN_ADMIN),
            GTK_DIALOG_MODAL | GTK_DIALOG_DESTROY_WITH_PARENT,
            GTK_STOCK_OK, GTK_RESPONSE_OK,
            GTK_STOCK_CANCEL, GTK_RESPONSE_CANCEL,
            NULL);

        GtkWidget *content = gtk_dialog_get_content_area(GTK_DIALOG(dialog));
        gtk_container_set_border_width(GTK_CONTAINER(content), 10);

        /* Champs du formulaire */
        GtkWidget *label_code = gtk_label_new("Code à Barre:");
        GtkWidget *entry_code = gtk_entry_new();
        gtk_entry_set_text(GTK_ENTRY(entry_code), eq->code_barre);
        
        GtkWidget *label_type = gtk_label_new("Type:");
        GtkWidget *combo_type = gtk_combo_box_entry_new_text();
        gtk_combo_box_append_text(GTK_COMBO_BOX(combo_type), "Haltère");
        gtk_combo_box_append_text(GTK_COMBO_BOX(combo_type), "Tapis Roulant");
        gtk_combo_box_append_text(GTK_COMBO_BOX(combo_type), "Vélo Stationnaire");
        gtk_combo_box_append_text(GTK_COMBO_BOX(combo_type), "Banc de Musculation");
        gtk_combo_box_set_active(GTK_COMBO_BOX(combo_type), 0);
        /* Sélectionner le type actuel */
        for (int i = 0; i < 4; i++) {
            const char *text = gtk_combo_box_get_active_text(GTK_COMBO_BOX(combo_type));
            if (strcmp(text, eq->type) == 0) {
                gtk_combo_box_set_active(GTK_COMBO_BOX(combo_type), i);
                break;
            }
        }

        GtkWidget *label_centre = gtk_label_new("Centre:");
        GtkWidget *combo_centre = gtk_combo_box_entry_new_text();
        gtk_combo_box_append_text(GTK_COMBO_BOX(combo_centre), "Marsa");
        gtk_combo_box_append_text(GTK_COMBO_BOX(combo_centre), "Ariana");
        gtk_combo_box_append_text(GTK_COMBO_BOX(combo_centre), "Lac 1");
        gtk_combo_box_set_active(GTK_COMBO_BOX(combo_centre), 0);
        /* Sélectionner le centre actuel */
        const char *centres[] = {"Marsa", "Ariana", "Lac 1"};
        for (int i = 0; i < 3; i++) {
            if (strcmp(centres[i], eq->centre) == 0) {
                gtk_combo_box_set_active(GTK_COMBO_BOX(combo_centre), i);
                break;
            }
        }

        GtkWidget *label_marque = gtk_label_new("Marque:");
        GtkWidget *entry_marque = gtk_entry_new();
        gtk_entry_set_text(GTK_ENTRY(entry_marque), eq->marque);

        GtkWidget *label_dispo = gtk_label_new("Disponibilité:");
        GtkWidget *combo_dispo = gtk_combo_box_entry_new_text();
        gtk_combo_box_append_text(GTK_COMBO_BOX(combo_dispo), "Disponible");
        gtk_combo_box_append_text(GTK_COMBO_BOX(combo_dispo), "Indisponible");
        gtk_combo_box_set_active(GTK_COMBO_BOX(combo_dispo), 0);
        /* Sélectionner la disponibilité actuelle */
        for (int i = 0; i < 2; i++) {
            const char *text = gtk_combo_box_get_active_text(GTK_COMBO_BOX(combo_dispo));
            if (strcmp(text, eq->disponibilite) == 0) {
                gtk_combo_box_set_active(GTK_COMBO_BOX(combo_dispo), i);
                break;
            }
        }

        /* Layout */
        GtkWidget *table = gtk_table_new(5, 2, FALSE);
        gtk_table_set_row_spacings(GTK_TABLE(table), 5);
        gtk_table_set_col_spacings(GTK_TABLE(table), 5);

        gtk_table_attach(GTK_TABLE(table), label_code, 0, 1, 0, 1, GTK_FILL, GTK_FILL, 0, 0);
        gtk_table_attach(GTK_TABLE(table), entry_code, 1, 2, 0, 1, GTK_FILL | GTK_EXPAND, GTK_FILL, 0, 0);

        gtk_table_attach(GTK_TABLE(table), label_type, 0, 1, 1, 2, GTK_FILL, GTK_FILL, 0, 0);
        gtk_table_attach(GTK_TABLE(table), combo_type, 1, 2, 1, 2, GTK_FILL | GTK_EXPAND, GTK_FILL, 0, 0);

        gtk_table_attach(GTK_TABLE(table), label_centre, 0, 1, 2, 3, GTK_FILL, GTK_FILL, 0, 0);
        gtk_table_attach(GTK_TABLE(table), combo_centre, 1, 2, 2, 3, GTK_FILL | GTK_EXPAND, GTK_FILL, 0, 0);

        gtk_table_attach(GTK_TABLE(table), label_marque, 0, 1, 3, 4, GTK_FILL, GTK_FILL, 0, 0);
        gtk_table_attach(GTK_TABLE(table), entry_marque, 1, 2, 3, 4, GTK_FILL | GTK_EXPAND, GTK_FILL, 0, 0);

        gtk_table_attach(GTK_TABLE(table), label_dispo, 0, 1, 4, 5, GTK_FILL, GTK_FILL, 0, 0);
        gtk_table_attach(GTK_TABLE(table), combo_dispo, 1, 2, 4, 5, GTK_FILL | GTK_EXPAND, GTK_FILL, 0, 0);

        gtk_box_pack_start(GTK_BOX(content), table, TRUE, TRUE, 0);
        gtk_widget_show_all(content);

        if (gtk_dialog_run(GTK_DIALOG(dialog)) == GTK_RESPONSE_OK) {
            const char *new_code = gtk_entry_get_text(GTK_ENTRY(entry_code));
            const char *new_type = gtk_combo_box_get_active_text(GTK_COMBO_BOX(combo_type));
            const char *new_centre = gtk_combo_box_get_active_text(GTK_COMBO_BOX(combo_centre));
            const char *new_marque = gtk_entry_get_text(GTK_ENTRY(entry_marque));
            const char *new_dispo = gtk_combo_box_get_active_text(GTK_COMBO_BOX(combo_dispo));

            /* Mettre à jour l'équipement */
            strncpy(eq->code_barre, new_code, sizeof(eq->code_barre) - 1);
            strncpy(eq->type, new_type, sizeof(eq->type) - 1);
            strncpy(eq->centre, new_centre, sizeof(eq->centre) - 1);
            strncpy(eq->marque, new_marque, sizeof(eq->marque) - 1);
            strncpy(eq->disponibilite, new_dispo, sizeof(eq->disponibilite) - 1);

            /* Sauvegarder */
            save_equipments(g_equipments, g_equipments_filepath);
            
            /* Rafraîchir l'interface */
            GtkWidget *clist5_widget = lookup_widget(WIN_ADMIN, "clist5");
            init_equipments_interface(clist5_widget);

            g_print("✔ Équipement modifié : %s\n", new_code);
        }

        gtk_widget_destroy(dialog);
    }
}

/**
 * Callback bouton "Modifier" (button11) - Supprimé selon la roadmap
 * La modification se fait directement dans le CList
 */
void on_button11_equipment_clicked(GtkButton *button, gpointer user_data)
{
    /* Bouton supprimé - la modification se fait directement dans clist5 */
    g_print("ℹ️ Modification directe dans le tableau (double-clic sur une cellule)\n");
}

/**
 * Callback bouton "Supprimer" (button12)
 */
void on_button12_equipment_clicked(GtkButton *button, gpointer user_data)
{
    GtkWidget *clist5 = lookup_widget(WIN_ADMIN, "clist5");
    if (!clist5) return;

    GList *selected = GTK_CLIST(clist5)->selection;
    if (!selected) {
        GtkWidget *warning_dialog = gtk_message_dialog_new(GTK_WINDOW(WIN_ADMIN), GTK_DIALOG_MODAL,
            GTK_MESSAGE_WARNING, GTK_BUTTONS_OK,
            "Veuillez sélectionner un équipement !");
        gtk_dialog_run(GTK_DIALOG(warning_dialog));
        gtk_widget_destroy(warning_dialog);
        return;
    }

    int row = GPOINTER_TO_INT(selected->data);
    GtkWidget *dialog = gtk_message_dialog_new(GTK_WINDOW(WIN_ADMIN),
        GTK_DIALOG_MODAL, GTK_MESSAGE_QUESTION, GTK_BUTTONS_YES_NO,
        "Êtes-vous sûr de vouloir supprimer cet équipement ?");

    if (gtk_dialog_run(GTK_DIALOG(dialog)) == GTK_RESPONSE_YES) {
        /* Supprimer de la liste */
        Equipment *eq = (Equipment *)g_list_nth_data(g_equipments, row);
        if (eq) {
            g_equipments = g_list_remove(g_equipments, eq);
            free_equipment(eq);
            save_equipments(g_equipments, g_equipments_filepath);
            init_equipments_interface(clist5);
            g_print("✔ Équipement supprimé\n");
        }
    }

    gtk_widget_destroy(dialog);
}

/**
 * Callback bouton "Rechercher" (button13)
 * Filtre par le champ sélectionné dans comboboxentry3
 */
void on_button13_equipment_clicked(GtkButton *button, gpointer user_data)
{
    GtkWidget *clist5 = lookup_widget(WIN_ADMIN, "clist5");
    GtkWidget *entry5 = lookup_widget(WIN_ADMIN, "entry5");
    GtkWidget *comboboxentry3 = lookup_widget(WIN_ADMIN, "comboboxentry3");

    if (!clist5 || !entry5 || !comboboxentry3) return;

    const char *search_value = gtk_entry_get_text(GTK_ENTRY(entry5));
    int filter_type = gtk_combo_box_get_active(GTK_COMBO_BOX(comboboxentry3));

    if (strlen(search_value) == 0) {
        /* Afficher tous les équipements */
        init_equipments_interface(clist5);
        return;
    }

    /* Vider le CList */
    gtk_clist_clear(GTK_CLIST(clist5));

    /* Filtrer et afficher */
    for (GList *iter = g_equipments; iter; iter = iter->next) {
        Equipment *eq = (Equipment *)iter->data;
        gboolean match = FALSE;

        switch (filter_type) {
            case 0:  /* Code à barre */
                match = strstr(eq->code_barre, search_value) != NULL;
                break;
            case 1:  /* Disponibilité */
                match = strstr(eq->disponibilite, search_value) != NULL;
                break;
            case 2:  /* Marque */
                match = strstr(eq->marque, search_value) != NULL;
                break;
            case 3:  /* Centre */
                match = strstr(eq->centre, search_value) != NULL;
                break;
            case 4:  /* Type */
                match = strstr(eq->type, search_value) != NULL;
                break;
        }

        if (match) {
            const char *row_data[] = {
                eq->code_barre,
                eq->disponibilite,
                eq->marque,
                eq->centre,
                eq->type
            };
            gtk_clist_append(GTK_CLIST(clist5), (gchar **)row_data);
        }
    }

    g_print("✔ Recherche effectuée\n");
}

/**
 * Callback édition directe dans le CList
 */
void on_equipment_cell_edited(GtkCellRendererText *renderer, gchar *path_string,
                             gchar *new_text, gpointer user_data)
{
    int row = atoi(path_string);
    Equipment *eq = (Equipment *)g_list_nth_data(g_equipments, row);

    if (!eq || !new_text || strlen(new_text) == 0) return;

    /* Mettre à jour le champ correspondant */
    int column = GPOINTER_TO_INT(user_data);
    switch (column) {
        case 0:  /* Code à barre */
            strncpy(eq->code_barre, new_text, sizeof(eq->code_barre) - 1);
            break;
        case 1:  /* Disponibilité */
            strncpy(eq->disponibilite, new_text, sizeof(eq->disponibilite) - 1);
            break;
        case 2:  /* Marque */
            strncpy(eq->marque, new_text, sizeof(eq->marque) - 1);
            break;
        case 3:  /* Centre */
            strncpy(eq->centre, new_text, sizeof(eq->centre) - 1);
            break;
        case 4:  /* Type */
            strncpy(eq->type, new_text, sizeof(eq->type) - 1);
            break;
    }

    save_equipments(g_equipments, g_equipments_filepath);
    g_print("✔ Équipement modifié\n");
}

static void populate_trainer_equipment_filter_combos(GtkWidget *parent_window)
{
    GtkWidget *combo_type = lookup_widget(parent_window, "combo_type");
    GtkWidget *combo_centre = lookup_widget(parent_window, "combo_centre");

    if (combo_type && GTK_IS_COMBO_BOX(combo_type)) {
        GtkTreeModel *m = gtk_combo_box_get_model(GTK_COMBO_BOX(combo_type));
        if (m && GTK_IS_LIST_STORE(m)) {
            gtk_list_store_clear(GTK_LIST_STORE(m));
        }
        gtk_combo_box_append_text(GTK_COMBO_BOX(combo_type), "Tous");
    }

    if (combo_centre && GTK_IS_COMBO_BOX(combo_centre)) {
        GtkTreeModel *m = gtk_combo_box_get_model(GTK_COMBO_BOX(combo_centre));
        if (m && GTK_IS_LIST_STORE(m)) {
            gtk_list_store_clear(GTK_LIST_STORE(m));
        }
        gtk_combo_box_append_text(GTK_COMBO_BOX(combo_centre), "Tous");
    }

    GHashTable *seen_types = g_hash_table_new_full(g_str_hash, g_str_equal, g_free, NULL);
    GHashTable *seen_centres = g_hash_table_new_full(g_str_hash, g_str_equal, g_free, NULL);

    for (GList *it = g_equipments; it; it = it->next) {
        Equipment *eq = (Equipment *)it->data;
        if (!eq) continue;

        if (combo_type && GTK_IS_COMBO_BOX(combo_type) && eq->type[0] != '\0') {
            if (!g_hash_table_lookup(seen_types, eq->type)) {
                g_hash_table_insert(seen_types, g_strdup(eq->type), GINT_TO_POINTER(1));
                gtk_combo_box_append_text(GTK_COMBO_BOX(combo_type), eq->type);
            }
        }

        if (combo_centre && GTK_IS_COMBO_BOX(combo_centre) && eq->centre[0] != '\0') {
            if (!g_hash_table_lookup(seen_centres, eq->centre)) {
                g_hash_table_insert(seen_centres, g_strdup(eq->centre), GINT_TO_POINTER(1));
                gtk_combo_box_append_text(GTK_COMBO_BOX(combo_centre), eq->centre);
            }
        }
    }

    g_hash_table_destroy(seen_types);
    g_hash_table_destroy(seen_centres);

    if (combo_type && GTK_IS_COMBO_BOX(combo_type)) {
        gtk_combo_box_set_active(GTK_COMBO_BOX(combo_type), 0);
    }
    if (combo_centre && GTK_IS_COMBO_BOX(combo_centre)) {
        gtk_combo_box_set_active(GTK_COMBO_BOX(combo_centre), 0);
    }
}

void on_button_rechercher_equipements_entraineur_clicked(GtkButton *button, gpointer user_data)
{
    (void)user_data;

    GtkWidget *win = gtk_widget_get_toplevel(GTK_WIDGET(button));
    if (!GTK_IS_WINDOW(win)) {
        return;
    }

    GtkWidget *treeview = lookup_widget(win, "treeview_equipments");
    GtkWidget *combo_type = lookup_widget(win, "combo_type");
    GtkWidget *combo_centre = lookup_widget(win, "combo_centre");

    if (!treeview) {
        return;
    }

    const char *selected_type = (combo_type && GTK_IS_COMBO_BOX(combo_type))
        ? gtk_combo_box_get_active_text(GTK_COMBO_BOX(combo_type))
        : NULL;
    const char *selected_centre = (combo_centre && GTK_IS_COMBO_BOX(combo_centre))
        ? gtk_combo_box_get_active_text(GTK_COMBO_BOX(combo_centre))
        : NULL;

    GtkTreeModel *model = gtk_tree_view_get_model(GTK_TREE_VIEW(treeview));
    if (!model) {
        GtkListStore *store = gtk_list_store_new(
            5,
            G_TYPE_STRING,
            G_TYPE_STRING,
            G_TYPE_STRING,
            G_TYPE_STRING,
            G_TYPE_STRING
        );
        gtk_tree_view_set_model(GTK_TREE_VIEW(treeview), GTK_TREE_MODEL(store));
        g_object_unref(store);
        model = gtk_tree_view_get_model(GTK_TREE_VIEW(treeview));
    }
    if (!model) {
        return;
    }

    gtk_list_store_clear(GTK_LIST_STORE(model));

    GtkTreeIter iter;
    for (GList *list_iter = g_equipments; list_iter; list_iter = list_iter->next) {
        Equipment *eq = (Equipment *)list_iter->data;
        if (!eq) continue;
        if (strcmp(eq->disponibilite, "Disponible") != 0) continue;

        gboolean type_match = (!selected_type || strcmp(selected_type, "Tous") == 0) || (strcmp(selected_type, eq->type) == 0);
        gboolean centre_match = (!selected_centre || strcmp(selected_centre, "Tous") == 0) || (strcmp(selected_centre, eq->centre) == 0);

        if (type_match && centre_match) {
            gtk_list_store_append(GTK_LIST_STORE(model), &iter);
            gtk_list_store_set(GTK_LIST_STORE(model), &iter,
                              0, eq->code_barre,
                              1, eq->type,
                              2, eq->marque,
                              3, eq->centre,
                              4, eq->disponibilite,
                              -1);
        }
    }
}

/* =======================================================
 *  🔧 RÉSERVATION DES ÉQUIPEMENTS - ENTRAINEUR
 * ======================================================= */

/**
 * Initialise le TreeView de réservation avec les équipements disponibles
 */
void init_equipment_reservation_interface(GtkWidget *fixed105)
{
    if (!fixed105) {
        g_warning("⚠️ fixed105 introuvable !");
        return;
    }

    /* Charger les équipements et réservations */
    if (g_equipments) {
        free_equipments_list(g_equipments);
    }
    g_equipments = load_equipments(g_equipments_filepath);

    if (g_reservations) {
        free_reservations_list(g_reservations);
    }
    g_reservations = load_reservations(g_reservations_filepath);

    /* Récupérer le TreeView */
    GtkWidget *treeview = lookup_widget(GTK_WIDGET(gtk_widget_get_toplevel(fixed105)), "treeview_equipments");
    if (!treeview) {
        g_warning("⚠️ TreeView équipements introuvable !");
        return;
    }

    /* Récupérer le modèle */
    GtkTreeModel *model = gtk_tree_view_get_model(GTK_TREE_VIEW(treeview));
    if (!model) {
        GtkListStore *store = gtk_list_store_new(
            5,
            G_TYPE_STRING,   /* 0 : Code Barre */
            G_TYPE_STRING,   /* 1 : Type */
            G_TYPE_STRING,   /* 2 : Marque */
            G_TYPE_STRING,   /* 3 : Centre */
            G_TYPE_STRING    /* 4 : Disponibilité */
        );
        gtk_tree_view_set_model(GTK_TREE_VIEW(treeview), GTK_TREE_MODEL(store));
        g_object_unref(store);
        model = gtk_tree_view_get_model(GTK_TREE_VIEW(treeview));
    }

    
        GList *cols = gtk_tree_view_get_columns(GTK_TREE_VIEW(treeview));
        int n_cols = g_list_length(cols);
        g_list_free(cols);

        if (n_cols == 0) {
        GtkCellRenderer *renderer;
        const char *titles[5] = {"Code Barre", "Type", "Marque", "Centre", "Disponibilité"};
        for (int i = 0; i < 5; i++) {
            renderer = gtk_cell_renderer_text_new();
            gtk_tree_view_insert_column_with_attributes(
                GTK_TREE_VIEW(treeview),
                -1,
                titles[i],
                renderer,
                "text", i,
                NULL
            );
        }
    }
    

    if (!model) {
        g_warning("⚠️ Modèle du TreeView introuvable !");
        return;
    }

    /* Vider le modèle */
    gtk_list_store_clear(GTK_LIST_STORE(model));

    GtkWidget *parent_window = GTK_WIDGET(gtk_widget_get_toplevel(fixed105));
    if (GTK_IS_WINDOW(parent_window)) {
        populate_trainer_equipment_filter_combos(parent_window);
    }

    /* Remplir le TreeView avec les équipements disponibles */
    GtkTreeIter iter;
    for (GList *list_iter = g_equipments; list_iter; list_iter = list_iter->next) {
        Equipment *eq = (Equipment *)list_iter->data;
        if (strcmp(eq->disponibilite, "Disponible") == 0) {
            gtk_list_store_append(GTK_LIST_STORE(model), &iter);
            gtk_list_store_set(GTK_LIST_STORE(model), &iter,
                              0, eq->code_barre,
                              1, eq->type,
                              2, eq->marque,
                              3, eq->centre,
                              4, eq->disponibilite,
                              -1);
        }
    }

    g_print("✔ TreeView réservation équipements rempli (%d équipements disponibles)\n", g_list_length(g_equipments));
}

/**
 * Affiche les réservations de l'entraineur connecté
 */
void init_trainer_reservations_interface(GtkWidget *tree)
{
    if (!tree) {
        g_warning("⚠️ TreeView introuvable !");
        return;
    }

    /* Charger les équipements si nécessaire */
    if (!g_equipments) {
        g_equipments = load_equipments(g_equipments_filepath);
    }

    /* Charger les réservations */
    if (g_reservations) {
        free_reservations_list(g_reservations);
    }
    g_reservations = load_reservations(g_reservations_filepath);

    /* Créer le modèle si nécessaire */
    GtkTreeModel *model = gtk_tree_view_get_model(GTK_TREE_VIEW(tree));
    GtkListStore *store;

    if (model == NULL) {
        store = gtk_list_store_new(
            5,
            G_TYPE_STRING,   /* 0 : Code Barre */
            G_TYPE_STRING,   /* 1 : Type */
            G_TYPE_STRING,   /* 2 : Centre */
            G_TYPE_STRING,   /* 3 : Jour */
            G_TYPE_STRING    /* 4 : Créneau */
        );
        gtk_tree_view_set_model(GTK_TREE_VIEW(tree), GTK_TREE_MODEL(store));
        g_object_unref(store);

        /* Créer les colonnes */
        GtkCellRenderer *renderer;
        const char *titles[5] = {"Code Barre", "Type", "Centre", "Jour", "Créneau"};
        for (int i = 0; i < 5; i++) {
            renderer = gtk_cell_renderer_text_new();
            gtk_tree_view_insert_column_with_attributes(
                GTK_TREE_VIEW(tree),
                -1,
                titles[i],
                renderer,
                "text", i,
                NULL
            );
        }
    } else {
        store = GTK_LIST_STORE(model);
        gtk_list_store_clear(store);
    }

    /* Remplir le TreeView avec les réservations de l'entraineur */
    GtkTreeIter iter;
    int count = 0;
    for (GList *list_iter = g_reservations; list_iter; list_iter = list_iter->next) {
        Reservation *res = (Reservation *)list_iter->data;

        /* Afficher seulement les réservations de cet entraineur */
        if (strcmp(res->id_entraineur, g_current_trainer_id) == 0) {
            /* Récupérer les infos de l'équipement */
            Equipment *eq = find_equipment_by_code(g_equipments, res->code_barre);
            const char *type = eq ? eq->type : "N/A";
            const char *centre = eq ? eq->centre : "N/A";

            gtk_list_store_append(store, &iter);
            gtk_list_store_set(store, &iter,
                              0, res->code_barre,
                              1, type,
                              2, centre,
                              3, res->jour,
                              4, res->creneau,
                              -1);
            count++;
        }
    }

    g_print("✔ TreeView réservations entraineur rempli (%d réservations pour %s)\n", count, g_current_trainer_id);
}

/**
 * Affiche l'historique de toutes les réservations pour l'admin
 */
void init_admin_reservations_interface(GtkWidget *tree)
{
    if (!tree) {
        g_warning("⚠️ TreeView introuvable !");
        return;
    }

    /* Charger les réservations */
    if (g_reservations) {
        free_reservations_list(g_reservations);
    }
    g_reservations = load_reservations(g_reservations_filepath);

    /* Créer le modèle si nécessaire */
    GtkTreeModel *model = gtk_tree_view_get_model(GTK_TREE_VIEW(tree));
    GtkListStore *store;

    if (model == NULL) {
        store = gtk_list_store_new(
            6,
            G_TYPE_STRING,   /* 0 : ID Réservation */
            G_TYPE_STRING,   /* 1 : Code Barre */
            G_TYPE_STRING,   /* 2 : Entraineur */
            G_TYPE_STRING,   /* 3 : Jour */
            G_TYPE_STRING,   /* 4 : Créneau */
            G_TYPE_STRING    /* 5 : Date */
        );
        gtk_tree_view_set_model(GTK_TREE_VIEW(tree), GTK_TREE_MODEL(store));
        g_object_unref(store);

        /* Créer les colonnes */
        GtkCellRenderer *renderer;
        const char *titles[6] = {"ID Réservation", "Code Barre", "Entraineur", "Jour", "Créneau", "Date"};
        for (int i = 0; i < 6; i++) {
            renderer = gtk_cell_renderer_text_new();
            gtk_tree_view_insert_column_with_attributes(
                GTK_TREE_VIEW(tree),
                -1,
                titles[i],
                renderer,
                "text", i,
                NULL
            );
        }
    } else {
        store = GTK_LIST_STORE(model);
        gtk_list_store_clear(store);
    }

    /* Remplir le TreeView avec toutes les réservations */
    GtkTreeIter iter;
    int count = 0;
    for (GList *list_iter = g_reservations; list_iter; list_iter = list_iter->next) {
        Reservation *res = (Reservation *)list_iter->data;

        gtk_list_store_append(store, &iter);
        gtk_list_store_set(store, &iter,
                          0, res->id_reservation,
                          1, res->code_barre,
                          2, res->id_entraineur,
                          3, res->jour,
                          4, res->creneau,
                          5, res->date,
                          -1);
        count++;
    }

    g_print("✔ TreeView réservations admin rempli (%d réservations)\n", count);
}

/**
 * Initialise l'interface de réservation des équipements
 */
void init_reservations_interface(GtkWidget *tree)
{
    if (!tree) {
        g_warning("⚠️ TreeView introuvable !");
        return;
    }

    /* Charger les équipements et réservations */
    if (g_equipments) {
        free_equipments_list(g_equipments);
    }
    g_equipments = load_equipments(g_equipments_filepath);

    if (g_reservations) {
        free_reservations_list(g_reservations);
    }
    g_reservations = load_reservations(g_reservations_filepath);

    g_print("✔ Interface réservations initialisée\n");
}

/**
 * Callback bouton "Confirmer réservation" (équipement)
 */
void on_button_confirm_equipment_reservation_clicked(GtkButton *button, gpointer user_data)
{
    GtkWidget *win = gtk_widget_get_toplevel(GTK_WIDGET(button));
    if (!GTK_IS_WINDOW(win)) {
        g_warning("⚠ Impossible de trouver la fenêtre parente");
        return;
    }

    /* Récupérer l'équipement sélectionné depuis le TreeView */
    GtkWidget *treeview = lookup_widget(win, "treeview_equipments");
    if (!treeview) {
        GtkWidget *dialog = gtk_message_dialog_new(
            GTK_WINDOW(win),
            GTK_DIALOG_DESTROY_WITH_PARENT,
            GTK_MESSAGE_ERROR,
            GTK_BUTTONS_OK,
            "Veuillez sélectionner un équipement !"
        );
        g_signal_connect_swapped(dialog, "response", G_CALLBACK(gtk_widget_destroy), dialog);
        gtk_widget_show(dialog);
        return;
    }

    GtkTreeSelection *selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(treeview));
    GtkTreeIter iter;
    GtkTreeModel *model;
    gchar *code_barre = NULL;

    if (!gtk_tree_selection_get_selected(selection, &model, &iter)) {
        GtkWidget *dialog = gtk_message_dialog_new(
            GTK_WINDOW(win),
            GTK_DIALOG_DESTROY_WITH_PARENT,
            GTK_MESSAGE_ERROR,
            GTK_BUTTONS_OK,
            "Veuillez sélectionner un équipement !"
        );
        g_signal_connect_swapped(dialog, "response", G_CALLBACK(gtk_widget_destroy), dialog);
        gtk_widget_show(dialog);
        return;
    }

    gtk_tree_model_get(model, &iter, 0, &code_barre, -1);

    /* Récupérer jour et créneau */
    GtkWidget *combo_jour = lookup_widget(win, "combo_jour_reservation");
    GtkWidget *combo_creneau = lookup_widget(win, "combo_creneau_reservation");
    
    const char *jour = combo_jour ? gtk_combo_box_get_active_text(GTK_COMBO_BOX(combo_jour)) : "Lundi";
    const char *creneau = combo_creneau ? gtk_combo_box_get_active_text(GTK_COMBO_BOX(combo_creneau)) : "8h-10h";

    /* Récupérer l'ID de l'entraineur (stocké lors du login) */
    extern char g_current_trainer_id[];
    const char *trainer_id = g_current_trainer_id;

    if (strlen(trainer_id) == 0) {
        GtkWidget *error_dialog = gtk_message_dialog_new(
            GTK_WINDOW(win),
            GTK_DIALOG_DESTROY_WITH_PARENT,
            GTK_MESSAGE_ERROR,
            GTK_BUTTONS_OK,
            "Erreur : ID entraineur non trouvé !"
        );
        g_signal_connect_swapped(error_dialog, "response", G_CALLBACK(gtk_widget_destroy), error_dialog);
        gtk_widget_show(error_dialog);
        g_free(code_barre);
        return;
    }

    /* Afficher confirmation avec les détails */
    GtkWidget *dialog_confirm = gtk_message_dialog_new(
        GTK_WINDOW(win),
        GTK_DIALOG_DESTROY_WITH_PARENT,
        GTK_MESSAGE_QUESTION,
        GTK_BUTTONS_OK_CANCEL,
        "Confirmer la réservation ?\n\nÉquipement : %s\nJour : %s\nCréneau : %s\nEntraineur : %s",
        code_barre, jour, creneau, trainer_id
    );

    if (gtk_dialog_run(GTK_DIALOG(dialog_confirm)) == GTK_RESPONSE_OK) {
        /* Vérifier la disponibilité */
        gboolean available = is_equipment_available(g_reservations, code_barre, jour, creneau);

        if (available) {
            /* Créer la réservation */
            char id_reservation[50];
            snprintf(id_reservation, sizeof(id_reservation), "RES%ld", (long)time(NULL));

            time_t now = time(NULL);
            struct tm *tm_now = localtime(&now);
            char date[20];
            strftime(date, sizeof(date), "%d/%m/%Y", tm_now);

            Reservation *new_res = create_reservation(
                id_reservation,
                code_barre,
                trainer_id,
                jour,
                creneau,
                date
            );

            g_reservations = g_list_append(g_reservations, new_res);
            save_reservations(g_reservations, g_reservations_filepath);

            /* Rafraîchir le TreeView des réservations */
            GtkWidget *treeview_my_reservations = lookup_widget(win, "treeview_my_reservations");
            if (treeview_my_reservations) {
                extern void init_trainer_reservations_interface(GtkWidget *tree);
                init_trainer_reservations_interface(treeview_my_reservations);
            }

            GtkWidget *success_dialog = gtk_message_dialog_new(
                GTK_WINDOW(win),
                GTK_DIALOG_DESTROY_WITH_PARENT,
                GTK_MESSAGE_INFO,
                GTK_BUTTONS_OK,
                "✔ Équipement réservé avec succès !\nID Réservation : %s",
                id_reservation
            );
            g_signal_connect_swapped(success_dialog, "response", G_CALLBACK(gtk_widget_destroy), success_dialog);
            gtk_widget_show(success_dialog);

            g_print("✔ Réservation créée : %s pour entraineur %s\n", id_reservation, trainer_id);
        } else {
            GtkWidget *error_dialog = gtk_message_dialog_new(
                GTK_WINDOW(win),
                GTK_DIALOG_DESTROY_WITH_PARENT,
                GTK_MESSAGE_ERROR,
                GTK_BUTTONS_OK,
                "✗ Équipement déjà réservé pour ce créneau !"
            );
            g_signal_connect_swapped(error_dialog, "response", G_CALLBACK(gtk_widget_destroy), error_dialog);
            gtk_widget_show(error_dialog);
        }
    }

    gtk_widget_destroy(dialog_confirm);
    g_free(code_barre);
}

/**
 * Callback bouton "Confirmer réservation" (ancien)
 */
void on_button_confirm_reservation_clicked(GtkButton *button, gpointer user_data)
{
    g_print("ℹ️ Réservation confirmée\n");
}

/* ============================================================================
   EQUIPMENT UI FUNCTIONS (migrated from interface.c)
   ============================================================================ */

/**
 * Callback pour filtrer le TreeView par Type et Centre
 */
static void on_filter_changed(GtkComboBox *combo, gpointer user_data)
{
    GtkWidget *parent_window = GTK_WIDGET(gtk_widget_get_toplevel(GTK_WIDGET(combo)));
    GtkWidget *treeview = lookup_widget(parent_window, "treeview_equipments");
    GtkWidget *combo_type = lookup_widget(parent_window, "combo_type_reservation");
    GtkWidget *combo_centre = lookup_widget(parent_window, "combo_centre_reservation");

    if (!treeview || !combo_type || !combo_centre) return;

    const char *selected_type = gtk_combo_box_get_active_text(GTK_COMBO_BOX(combo_type));
    const char *selected_centre = gtk_combo_box_get_active_text(GTK_COMBO_BOX(combo_centre));

    GtkTreeModel *model = gtk_tree_view_get_model(GTK_TREE_VIEW(treeview));
    if (!model) return;

    gtk_list_store_clear(GTK_LIST_STORE(model));

    /* Remplir le TreeView avec filtrage */
    GtkTreeIter iter;
    for (GList *list_iter = g_equipments; list_iter; list_iter = list_iter->next) {
        Equipment *eq = (Equipment *)list_iter->data;
        
        if (strcmp(eq->disponibilite, "Disponible") != 0) continue;

        gboolean type_match = (strcmp(selected_type, "Tous") == 0) || (strcmp(selected_type, eq->type) == 0);
        gboolean centre_match = (strcmp(selected_centre, "Tous") == 0) || (strcmp(selected_centre, eq->centre) == 0);

        if (type_match && centre_match) {
            gtk_list_store_append(GTK_LIST_STORE(model), &iter);
            gtk_list_store_set(GTK_LIST_STORE(model), &iter,
                              0, eq->code_barre,
                              1, eq->type,
                              2, eq->marque,
                              3, eq->centre,
                              4, eq->disponibilite,
                              -1);
        }
    }

    g_print("✔ Filtrage appliqué: Type=%s, Centre=%s\n", selected_type, selected_centre);
}

/**
 * Crée l'interface de réservation d'équipements dans fixed105
 */
void create_equipment_reservation_interface(GtkWidget *fixed105, GtkWidget *parent_window)
{
    if (!fixed105) return;

    /* Titre */
    GtkWidget *label_title = gtk_label_new("Réservation d'Équipements");
    gtk_widget_show(label_title);
    gtk_fixed_put(GTK_FIXED(fixed105), label_title, 16, 16);
    gtk_widget_set_size_request(label_title, 400, 30);

    /* Filtres - Type */
    GtkWidget *label_type = gtk_label_new("Type :");
    gtk_widget_show(label_type);
    gtk_fixed_put(GTK_FIXED(fixed105), label_type, 16, 56);
    gtk_widget_set_size_request(label_type, 80, 27);

    GtkWidget *combo_type = gtk_combo_box_entry_new_text();
    gtk_widget_show(combo_type);
    gtk_fixed_put(GTK_FIXED(fixed105), combo_type, 100, 56);
    gtk_widget_set_size_request(combo_type, 150, 27);
    gtk_combo_box_append_text(GTK_COMBO_BOX(combo_type), "Tous");
    gtk_combo_box_append_text(GTK_COMBO_BOX(combo_type), "Haltère");
    gtk_combo_box_append_text(GTK_COMBO_BOX(combo_type), "Tapis Roulant");
    gtk_combo_box_append_text(GTK_COMBO_BOX(combo_type), "Vélo Stationnaire");
    gtk_combo_box_append_text(GTK_COMBO_BOX(combo_type), "Banc de Musculation");
    gtk_combo_box_set_active(GTK_COMBO_BOX(combo_type), 0);
    GLADE_HOOKUP_OBJECT(parent_window, combo_type, "combo_type_reservation");
    g_signal_connect(G_OBJECT(combo_type), "changed", G_CALLBACK(on_filter_changed), NULL);

    /* Filtres - Centre */
    GtkWidget *label_centre = gtk_label_new("Centre :");
    gtk_widget_show(label_centre);
    gtk_fixed_put(GTK_FIXED(fixed105), label_centre, 280, 56);
    gtk_widget_set_size_request(label_centre, 80, 27);

    GtkWidget *combo_centre = gtk_combo_box_entry_new_text();
    gtk_widget_show(combo_centre);
    gtk_fixed_put(GTK_FIXED(fixed105), combo_centre, 364, 56);
    gtk_widget_set_size_request(combo_centre, 150, 27);
    gtk_combo_box_append_text(GTK_COMBO_BOX(combo_centre), "Tous");
    gtk_combo_box_append_text(GTK_COMBO_BOX(combo_centre), "Marsa");
    gtk_combo_box_append_text(GTK_COMBO_BOX(combo_centre), "Ariana");
    gtk_combo_box_append_text(GTK_COMBO_BOX(combo_centre), "Lac 1");
    gtk_combo_box_set_active(GTK_COMBO_BOX(combo_centre), 0);
    GLADE_HOOKUP_OBJECT(parent_window, combo_centre, "combo_centre_reservation");
    g_signal_connect(G_OBJECT(combo_centre), "changed", G_CALLBACK(on_filter_changed), NULL);

    /* TreeView Équipements */
    GtkWidget *label_equipments = gtk_label_new("Équipements Disponibles :");
    gtk_widget_show(label_equipments);
    gtk_fixed_put(GTK_FIXED(fixed105), label_equipments, 16, 100);
    gtk_widget_set_size_request(label_equipments, 300, 20);

    GtkWidget *treeview_equipments = gtk_tree_view_new();
    gtk_widget_show(treeview_equipments);
    gtk_fixed_put(GTK_FIXED(fixed105), treeview_equipments, 16, 130);
    gtk_widget_set_size_request(treeview_equipments, 500, 200);
    gtk_tree_view_set_headers_visible(GTK_TREE_VIEW(treeview_equipments), TRUE);
    GLADE_HOOKUP_OBJECT(parent_window, treeview_equipments, "treeview_equipments");

    /* Créer le modèle pour le TreeView */
    GtkListStore *store = gtk_list_store_new(5, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
    gtk_tree_view_set_model(GTK_TREE_VIEW(treeview_equipments), GTK_TREE_MODEL(store));
    g_object_unref(store);

    /* Ajouter les colonnes */
    GtkCellRenderer *renderer;
    const char *titles[5] = {"Code Barre", "Type", "Marque", "Centre", "Disponibilité"};
    for (int i = 0; i < 5; i++) {
        renderer = gtk_cell_renderer_text_new();
        gtk_tree_view_insert_column_with_attributes(GTK_TREE_VIEW(treeview_equipments), -1, titles[i], renderer, "text", i, NULL);
    }

    /* Jour */
    GtkWidget *label_jour = gtk_label_new("Jour :");
    gtk_widget_show(label_jour);
    gtk_fixed_put(GTK_FIXED(fixed105), label_jour, 540, 130);
    gtk_widget_set_size_request(label_jour, 80, 27);

    GtkWidget *combo_jour = gtk_combo_box_entry_new_text();
    gtk_widget_show(combo_jour);
    gtk_fixed_put(GTK_FIXED(fixed105), combo_jour, 620, 130);
    gtk_widget_set_size_request(combo_jour, 150, 27);
    gtk_combo_box_append_text(GTK_COMBO_BOX(combo_jour), "Lundi");
    gtk_combo_box_append_text(GTK_COMBO_BOX(combo_jour), "Mardi");
    gtk_combo_box_append_text(GTK_COMBO_BOX(combo_jour), "Mercredi");
    gtk_combo_box_append_text(GTK_COMBO_BOX(combo_jour), "Jeudi");
    gtk_combo_box_append_text(GTK_COMBO_BOX(combo_jour), "Vendredi");
    gtk_combo_box_append_text(GTK_COMBO_BOX(combo_jour), "Samedi");
    gtk_combo_box_append_text(GTK_COMBO_BOX(combo_jour), "Dimanche");
    gtk_combo_box_set_active(GTK_COMBO_BOX(combo_jour), 0);
    GLADE_HOOKUP_OBJECT(parent_window, combo_jour, "combo_jour_reservation");

    /* Créneau */
    GtkWidget *label_creneau = gtk_label_new("Créneau :");
    gtk_widget_show(label_creneau);
    gtk_fixed_put(GTK_FIXED(fixed105), label_creneau, 540, 170);
    gtk_widget_set_size_request(label_creneau, 80, 27);

    GtkWidget *combo_creneau = gtk_combo_box_entry_new_text();
    gtk_widget_show(combo_creneau);
    gtk_fixed_put(GTK_FIXED(fixed105), combo_creneau, 620, 170);
    gtk_widget_set_size_request(combo_creneau, 150, 27);
    gtk_combo_box_append_text(GTK_COMBO_BOX(combo_creneau), "8h-10h");
    gtk_combo_box_append_text(GTK_COMBO_BOX(combo_creneau), "10h-12h");
    gtk_combo_box_append_text(GTK_COMBO_BOX(combo_creneau), "13h30-15h");
    gtk_combo_box_append_text(GTK_COMBO_BOX(combo_creneau), "15h30-17h");
    gtk_combo_box_set_active(GTK_COMBO_BOX(combo_creneau), 0);
    GLADE_HOOKUP_OBJECT(parent_window, combo_creneau, "combo_creneau_reservation");

    /* Bouton Confirmer */
    GtkWidget *button_confirm = gtk_button_new_with_label("Confirmer Réservation");
    gtk_widget_show(button_confirm);
    gtk_fixed_put(GTK_FIXED(fixed105), button_confirm, 540, 220);
    gtk_widget_set_size_request(button_confirm, 230, 40);
    GLADE_HOOKUP_OBJECT(parent_window, button_confirm, "button_confirm_reservation");

    extern void on_button_confirm_equipment_reservation_clicked(GtkButton *button, gpointer user_data);
    g_signal_connect(G_OBJECT(button_confirm), "clicked", G_CALLBACK(on_button_confirm_equipment_reservation_clicked), NULL);

    /* ===== AFFICHAGE MES RÉSERVATIONS ===== */
    GtkWidget *label_my_reservations = gtk_label_new("Mes Réservations :");
    gtk_widget_show(label_my_reservations);
    gtk_fixed_put(GTK_FIXED(fixed105), label_my_reservations, 16, 350);
    gtk_widget_set_size_request(label_my_reservations, 300, 20);

    GtkWidget *treeview_my_reservations = gtk_tree_view_new();
    gtk_widget_show(treeview_my_reservations);
    gtk_fixed_put(GTK_FIXED(fixed105), treeview_my_reservations, 16, 380);
    gtk_widget_set_size_request(treeview_my_reservations, 700, 200);
    gtk_tree_view_set_headers_visible(GTK_TREE_VIEW(treeview_my_reservations), TRUE);
    GLADE_HOOKUP_OBJECT(parent_window, treeview_my_reservations, "treeview_my_reservations");

    /* Créer le modèle pour le TreeView */
    GtkListStore *store_my_res = gtk_list_store_new(5, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
    gtk_tree_view_set_model(GTK_TREE_VIEW(treeview_my_reservations), GTK_TREE_MODEL(store_my_res));
    g_object_unref(store_my_res);

    /* Ajouter les colonnes */
    const char *titles_my_res[5] = {"Code Barre", "Type", "Centre", "Jour", "Créneau"};
    for (int i = 0; i < 5; i++) {
        GtkCellRenderer *renderer = gtk_cell_renderer_text_new();
        gtk_tree_view_insert_column_with_attributes(GTK_TREE_VIEW(treeview_my_reservations), -1, titles_my_res[i], renderer, "text", i, NULL);
    }
}

/* Callback : Valider conseil bien-être */
void on_button_valider_conseil_clicked(GtkButton *button, gpointer user_data)
{
    g_print(">>> BOUTON VALIDER CONSEIL CLIQUÉ\n");
    
    GtkWidget *win = gtk_widget_get_toplevel(GTK_WIDGET(button));
    
    /* Exemple de récupération de widgets (à adapter selon les IDs réels) */
    /* GtkWidget *entry_poids = lookup_widget(win, "entry38"); */
    
    GtkWidget *dialog = gtk_message_dialog_new(
        GTK_WINDOW(win),
        GTK_DIALOG_DESTROY_WITH_PARENT,
        GTK_MESSAGE_INFO,
        GTK_BUTTONS_OK,
        "Conseil bien-être validé avec succès !"
    );
    gtk_dialog_run(GTK_DIALOG(dialog));
    gtk_widget_destroy(dialog);
}



/* ---------------- AJOUT COURS ---------------- */

void init_cours_interface(void)
{
    GtkWidget *tree = lookup_widget(WIN_ADMIN, "treeviewcours");
    if (!tree) return;

    /* Charger les cours si ce n’est pas déjà fait */
    if (g_cours == NULL) {
        g_cours = load_cours_from_file(g_cours_filepath);
    }

    afficher_cours(tree);
}
void on_buttonajoutcours0_clicked(GtkWidget *o, gpointer d)
{
    if (!WIN_AJOUT)
        WIN_AJOUT = create_ajoutcours();

    gtk_widget_show(WIN_AJOUT);
}
void on_buttonajoutcours1_clicked(GtkButton *button, gpointer user_data)
{
    /* 1️⃣ Récupérer les données */
    cours c = recuperer_saisie(WIN_AJOUT);

    /* 2️⃣ Créer un nouveau cours dynamique */
    cours *new_c = malloc(sizeof(cours));
    *new_c = c;

    /* 3️⃣ Ajouter à la liste globale */
    g_cours = g_list_append(g_cours, new_c);

    /* 4️⃣ Sauvegarder dans le fichier */
    save_cours_to_file(g_cours, g_cours_filepath);

    /* 5️⃣ Fermer la fenêtre AjoutCours */
    gtk_widget_hide(WIN_AJOUT);

    /* 6️⃣ Ouvrir Login Admin */
    if (!WIN_ADMIN)
        WIN_ADMIN = create_login_admin();

    gtk_widget_show(WIN_ADMIN);

    /* 7️⃣ Rafraîchir le TreeView */
    init_cours_interface();

    /* 8️⃣ Message de confirmation */
    GtkWidget *msg = gtk_message_dialog_new(
        GTK_WINDOW(WIN_ADMIN),
        GTK_DIALOG_MODAL,
        GTK_MESSAGE_INFO,
        GTK_BUTTONS_OK,
        "Cours ajouté avec succès !"
    );
    gtk_dialog_run(GTK_DIALOG(msg));
    gtk_widget_destroy(msg);
}

void on_buttonsupprimerc_clicked(GtkButton *button, gpointer user_data)
{
    GtkWidget *tree = lookup_widget(WIN_ADMIN, "treeviewcours");
    if (!tree) return;

    GtkTreeSelection *selection =
        gtk_tree_view_get_selection(GTK_TREE_VIEW(tree));

    GtkTreeIter iter;
    GtkTreeModel *model;

    if (!gtk_tree_selection_get_selected(selection, &model, &iter))
        return;

    /* récupérer ID (colonne 0) */
    gchar *id_str = NULL;
    gtk_tree_model_get(model, &iter, 0, &id_str, -1);
    int id = atoi(id_str);

    /* supprimer de la liste mémoire */
    delete_cours_from_list(&g_cours, id);

    /* supprimer du TreeView */
    gtk_list_store_remove(GTK_LIST_STORE(model), &iter);

    /* sauvegarder */
    save_cours_to_file(g_cours, g_cours_filepath);

    g_free(id_str);
}


void on_buttonmodifiercours_clicked(GtkButton *button, gpointer user_data)
{
    GtkWidget *tree = lookup_widget(WIN_ADMIN, "treeviewcours");
    if (!tree) return;

    GtkTreeSelection *selection =
        gtk_tree_view_get_selection(GTK_TREE_VIEW(tree));

    GtkTreeModel *model;
    GtkTreeIter iter;

    if (!gtk_tree_selection_get_selected(selection, &model, &iter)) {
        GtkWidget *msg = gtk_message_dialog_new(
            GTK_WINDOW(WIN_ADMIN),
            GTK_DIALOG_MODAL,
            GTK_MESSAGE_WARNING,
            GTK_BUTTONS_OK,
            "Veuillez sélectionner un cours à modifier !");
        gtk_dialog_run(GTK_DIALOG(msg));
        gtk_widget_destroy(msg);
        return;
    }

    /* Récupérer l'ID */
    gchar *id_str = NULL;
    gtk_tree_model_get(model, &iter, 0, &id_str, -1);
    int id = atoi(id_str);
    g_free(id_str);

    /* Trouver le cours réel */
    cours *c = find_cours_by_id(g_cours, id);
    if (!c) return;

    /* ================= Fenêtre de modification ================= */
    GtkWidget *dialog = gtk_dialog_new_with_buttons(
        "Modifier Cours",
        GTK_WINDOW(WIN_ADMIN),
        GTK_DIALOG_MODAL,
        GTK_STOCK_OK, GTK_RESPONSE_OK,
        GTK_STOCK_CANCEL, GTK_RESPONSE_CANCEL,
        NULL
    );

    GtkWidget *content = gtk_dialog_get_content_area(GTK_DIALOG(dialog));
    gtk_container_set_border_width(GTK_CONTAINER(content), 10);

    /* Champs */
    GtkWidget *entry_nom = gtk_entry_new();
    GtkWidget *entry_coach = gtk_entry_new();
    GtkWidget *entry_centre = gtk_entry_new();
    GtkWidget *entry_salle = gtk_entry_new();
    GtkWidget *entry_date = gtk_entry_new();
    GtkWidget *entry_heure = gtk_entry_new();
    GtkWidget *entry_prix = gtk_entry_new();
    GtkWidget *entry_places = gtk_entry_new();
    GtkWidget *entry_statut = gtk_entry_new();

    /* Pré-remplir */
    gtk_entry_set_text(GTK_ENTRY(entry_nom), c->Nom);
    gtk_entry_set_text(GTK_ENTRY(entry_coach), c->coach);
    gtk_entry_set_text(GTK_ENTRY(entry_centre), c->centre);
    gtk_entry_set_text(GTK_ENTRY(entry_salle), c->salle);
    gtk_entry_set_text(GTK_ENTRY(entry_date), c->date);
    gtk_entry_set_text(GTK_ENTRY(entry_heure), c->heure);

    char buf[20];
    sprintf(buf, "%.2f", c->prix);
    gtk_entry_set_text(GTK_ENTRY(entry_prix), buf);

    sprintf(buf, "%d", c->nombre_de_places);
    gtk_entry_set_text(GTK_ENTRY(entry_places), buf);

    gtk_entry_set_text(GTK_ENTRY(entry_statut), c->statut);

    /* Layout */
    GtkWidget *table = gtk_table_new(9, 2, FALSE);
    gtk_table_set_row_spacings(GTK_TABLE(table), 5);

    #define ADD_ROW(lbl, wid, r) \
        gtk_table_attach(GTK_TABLE(table), gtk_label_new(lbl), 0,1,r,r+1, GTK_FILL,0,0,0); \
        gtk_table_attach(GTK_TABLE(table), wid, 1,2,r,r+1, GTK_EXPAND|GTK_FILL,0,0,0);

    ADD_ROW("Nom", entry_nom, 0);
    ADD_ROW("Coach", entry_coach, 1);
    ADD_ROW("Centre", entry_centre, 2);
    ADD_ROW("Salle", entry_salle, 3);
    ADD_ROW("Date", entry_date, 4);
    ADD_ROW("Heure", entry_heure, 5);
    ADD_ROW("Prix", entry_prix, 6);
    ADD_ROW("Places", entry_places, 7);
    ADD_ROW("Statut", entry_statut, 8);

    gtk_box_pack_start(GTK_BOX(content), table, TRUE, TRUE, 0);
    gtk_widget_show_all(content);

    /* Validation */
    if (gtk_dialog_run(GTK_DIALOG(dialog)) == GTK_RESPONSE_OK) {
        strcpy(c->Nom, gtk_entry_get_text(GTK_ENTRY(entry_nom)));
        strcpy(c->coach, gtk_entry_get_text(GTK_ENTRY(entry_coach)));
        strcpy(c->centre, gtk_entry_get_text(GTK_ENTRY(entry_centre)));
        strcpy(c->salle, gtk_entry_get_text(GTK_ENTRY(entry_salle)));
        strcpy(c->date, gtk_entry_get_text(GTK_ENTRY(entry_date)));
        strcpy(c->heure, gtk_entry_get_text(GTK_ENTRY(entry_heure)));
        c->prix = atof(gtk_entry_get_text(GTK_ENTRY(entry_prix)));
        c->nombre_de_places = atoi(gtk_entry_get_text(GTK_ENTRY(entry_places)));
        strcpy(c->statut, gtk_entry_get_text(GTK_ENTRY(entry_statut)));

        save_cours_to_file(g_cours, g_cours_filepath);
        afficher_cours(tree);
    }

    gtk_widget_destroy(dialog);
}

void on_buttonrecherchercours_clicked(GtkButton *button, gpointer user_data)
{
    GtkWidget *tree  = lookup_widget(WIN_ADMIN, "treeviewcours");
    GtkWidget *entry = lookup_widget(WIN_ADMIN, "entryreferencecours");
    GtkWidget *combo = lookup_widget(WIN_ADMIN, "comboboxentryreference");

    if (!tree || !entry || !combo) return;

    const char *search_text = gtk_entry_get_text(GTK_ENTRY(entry));
    gchar *filter_type = gtk_combo_box_get_active_text(GTK_COMBO_BOX(combo));

    /* Si champ vide → afficher tous les cours */
    if (!filter_type || strlen(search_text) == 0) {
        afficher_cours(tree);
        if (filter_type) g_free(filter_type);
        return;
    }

    /* Nettoyer uniquement le TreeView */
    GtkTreeModel *model = gtk_tree_view_get_model(GTK_TREE_VIEW(tree));
    GtkListStore *store = GTK_LIST_STORE(model);
    gtk_list_store_clear(store);

    GtkTreeIter iter;

    for (GList *l = g_cours; l != NULL; l = l->next)
    {
        cours *c = (cours *)l->data;
        gboolean match = FALSE;

        if (strcmp(filter_type, "Nom") == 0)
            match = strstr(c->Nom, search_text) != NULL;
        else if (strcmp(filter_type, "Coach") == 0)
            match = strstr(c->coach, search_text) != NULL;
        else if (strcmp(filter_type, "Centre") == 0)
            match = strstr(c->centre, search_text) != NULL;
        else if (strcmp(filter_type, "Salle") == 0)
            match = strstr(c->salle, search_text) != NULL;
        else if (strcmp(filter_type, "Date") == 0)
            match = strstr(c->date, search_text) != NULL;
        else if (strcmp(filter_type, "Heure") == 0)
            match = strstr(c->heure, search_text) != NULL;
        else if (strcmp(filter_type, "Prix") == 0)
            match = (atof(search_text) == c->prix);
        else if (strcmp(filter_type, "Nombre de places") == 0)
            match = (atoi(search_text) == c->nombre_de_places);
        else if (strcmp(filter_type, "Statut") == 0)
            match = strstr(c->statut, search_text) != NULL;

        if (match)
        {
            char id[20], prix[20], places[20];
            sprintf(id, "%d", c->identifiant);
            sprintf(prix, "%.2f", c->prix);
            sprintf(places, "%d", c->nombre_de_places);

            gtk_list_store_append(store, &iter);
            gtk_list_store_set(store, &iter,
                0, id,
                1, c->Nom,
                2, c->coach,
                3, c->centre,
                4, c->salle,
                5, c->date,
                6, c->heure,
                7, prix,
                8, places,
                9, c->statut,
                -1);
        }
    }

    g_free(filter_type);
    g_print("✔ Recherche cours effectuée\n");
}
void init_membre_cours_requests_interface(GtkWidget *tree, const char *id_membre)
{
    if (!tree || !id_membre || strlen(id_membre) == 0)
        return;

    GList *requests = load_cours_requests_from_file("cours_requests.txt");

    GtkTreeModel *model = gtk_tree_view_get_model(GTK_TREE_VIEW(tree));
    GtkListStore *store;

    if (model == NULL) {
        store = gtk_list_store_new(3,
            G_TYPE_STRING, /* Nom cours */
            G_TYPE_STRING, /* Date */
            G_TYPE_STRING  /* Statut */
        );

        gtk_tree_view_set_model(GTK_TREE_VIEW(tree), GTK_TREE_MODEL(store));
        g_object_unref(store);

        GtkCellRenderer *renderer;
        const char *titles[] = {"Cours", "Date", "Statut"};

        for (int i = 0; i < 3; i++) {
            renderer = gtk_cell_renderer_text_new();
            gtk_tree_view_insert_column_with_attributes(
                GTK_TREE_VIEW(tree), -1,
                titles[i], renderer, "text", i, NULL);
        }
    } else {
        store = GTK_LIST_STORE(model);
        gtk_list_store_clear(store);
    }

    GtkTreeIter iter;

    for (GList *l = requests; l; l = l->next) {
        CoursRequest *r = l->data;

        if (strcmp(r->id_membre, id_membre) == 0) {
            const char *msg =
                strcmp(r->statut, "acceptée") == 0 ? "✔ Acceptée" :
                strcmp(r->statut, "refusée")  == 0 ? "✗ Refusée"  :
                                                     "⏳ En attente";

            gtk_list_store_append(store, &iter);
            gtk_list_store_set(store, &iter,
                0, r->nom_cours,
                1, r->date_demande,
                2, msg,
                -1);
        }
    }

    free_cours_requests_list(requests);
}



void init_cours_requests_admin_interface(GtkWidget *tree)
{
    if (!tree) return;

    GList *requests = load_cours_requests_from_file("cours_requests.txt");

    GtkTreeModel *model = gtk_tree_view_get_model(GTK_TREE_VIEW(tree));
    GtkListStore *store;

    if (model == NULL) {
        store = gtk_list_store_new(5,
            G_TYPE_STRING, /* ID membre */
            G_TYPE_STRING, /* Cours */
            G_TYPE_STRING, /* Date */
            G_TYPE_STRING, /* Statut */
            G_TYPE_STRING  /* ID demande caché */
        );

        gtk_tree_view_set_model(GTK_TREE_VIEW(tree), GTK_TREE_MODEL(store));
        g_object_unref(store);

        GtkCellRenderer *renderer;
        const char *titles[] = {"ID Membre", "Cours", "Date", "Statut"};

        for (int i = 0; i < 4; i++) {
            renderer = gtk_cell_renderer_text_new();
            gtk_tree_view_insert_column_with_attributes(
                GTK_TREE_VIEW(tree), -1,
                titles[i], renderer, "text", i, NULL);
        }
    } else {
        store = GTK_LIST_STORE(model);
        gtk_list_store_clear(store);
    }

    GtkTreeIter iter;
    for (GList *l = requests; l; l = l->next) {
        CoursRequest *r = l->data;

        gtk_list_store_append(store, &iter);
        gtk_list_store_set(store, &iter,
            0, r->id_membre,
            1, r->nom_cours,
            2, r->date_demande,
            3, r->statut,
            4, r->id_demande,
            -1);
    }

    free_cours_requests_list(requests);
}
void on_buttoninscours_clicked(GtkButton *button, gpointer user_data)
{
    GtkWidget *win = gtk_widget_get_toplevel(GTK_WIDGET(button));

    GtkWidget *tree = lookup_widget(win, "treeviewchoix");
    GtkWidget *entry = lookup_widget(win, "entryidins");

    if (!tree || !entry) return;

    const char *id_membre = gtk_entry_get_text(GTK_ENTRY(entry));
    if (strlen(id_membre) == 0) return;

    GtkTreeSelection *selection =
        gtk_tree_view_get_selection(GTK_TREE_VIEW(tree));
    GtkTreeModel *model;
    GtkTreeIter iter;

    if (!gtk_tree_selection_get_selected(selection, &model, &iter))
        return;

    gchar *id_cours = NULL;
    gchar *nom_cours = NULL;
    gtk_tree_model_get(model, &iter, 0, &id_cours, 1, &nom_cours, -1);

    GList *requests = load_cours_requests_from_file("cours_requests.txt");

    char id_demande[50];
    snprintf(id_demande, sizeof(id_demande), "CR%ld", time(NULL));

    char date_demande[20];
    strftime(date_demande, sizeof(date_demande),
             "%d/%m/%Y", localtime(&(time_t){time(NULL)}));

    CoursRequest *r = create_cours_request(
        id_demande, id_membre, id_cours, nom_cours, date_demande, "en attente");

    add_cours_request_to_list(&requests, r);
    save_cours_requests_to_file(requests, "cours_requests.txt");

    init_membre_cours_requests_interface(
        lookup_widget(win, "treeviewattentecours"), id_membre);

    free_cours_requests_list(requests);
    g_free(id_cours);
    g_free(nom_cours);
}
void on_buttonacceptecours_clicked(GtkButton *button, gpointer user_data)
{
    GtkWidget *win = gtk_widget_get_toplevel(GTK_WIDGET(button));
    GtkWidget *tree = lookup_widget(win, "treeviewacceptecours");

    GtkTreeSelection *sel =
        gtk_tree_view_get_selection(GTK_TREE_VIEW(tree));
    GtkTreeModel *model;
    GtkTreeIter iter;

    if (!gtk_tree_selection_get_selected(sel, &model, &iter))
        return;

    gchar *id_demande;
    gtk_tree_model_get(model, &iter, 4, &id_demande, -1);

    GList *requests = load_cours_requests_from_file("cours_requests.txt");
    CoursRequest *r = find_cours_request_by_id(requests, id_demande);

    if (r) strcpy(r->statut, "acceptée");

    save_cours_requests_to_file(requests, "cours_requests.txt");
    init_cours_requests_admin_interface(tree);

    free_cours_requests_list(requests);
    g_free(id_demande);
}
void on_buttonrefusecours_clicked(GtkButton *button, gpointer user_data)
{
    GtkWidget *win = gtk_widget_get_toplevel(GTK_WIDGET(button));
    GtkWidget *tree = lookup_widget(win, "treeviewacceptecours");

    GtkTreeSelection *sel =
        gtk_tree_view_get_selection(GTK_TREE_VIEW(tree));
    GtkTreeModel *model;
    GtkTreeIter iter;

    if (!gtk_tree_selection_get_selected(sel, &model, &iter))
        return;

    gchar *id_demande;
    gtk_tree_model_get(model, &iter, 4, &id_demande, -1);

    GList *requests = load_cours_requests_from_file("cours_requests.txt");
    CoursRequest *r = find_cours_request_by_id(requests, id_demande);

    if (r) strcpy(r->statut, "refusée");

    save_cours_requests_to_file(requests, "cours_requests.txt");
    init_cours_requests_admin_interface(tree);

    free_cours_requests_list(requests);
    g_free(id_demande);
}

void on_login_admin_show(GtkWidget *widget, gpointer user_data)
{
    GtkWidget *tree;

    tree = lookup_widget(widget, "treeviewacceptecours");
    if (!tree) {
        g_warning("treeviewacceptecours introuvable !");
        return;
    }

    init_cours_requests_admin_interface(tree);
    GtkWidget *treeStats = lookup_widget(widget, "treeviewStatsCours");
    init_cours_statistics_interface(treeStats); 


}
void init_cours_statistics_interface(GtkWidget *tree)
{
    if (!tree) {
        g_warning("⚠️ treeviewStatsCours introuvable !");
        return;
    }

    GtkListStore *store = gtk_list_store_new(
        4,
        G_TYPE_STRING,  // Statistique
        G_TYPE_STRING,  // Valeur
        G_TYPE_STRING,  // Détails
        G_TYPE_STRING   // Pourcentage
    );

    gtk_tree_view_set_model(GTK_TREE_VIEW(tree), GTK_TREE_MODEL(store));
    g_object_unref(store);

    GtkCellRenderer *renderer;
    const char *titles[] = {
        "Statistique",
        "Valeur",
        "Détails",
        "Pourcentage"
    };

    for (int i = 0; i < 4; i++) {
        renderer = gtk_cell_renderer_text_new();
        gtk_tree_view_insert_column_with_attributes(
            GTK_TREE_VIEW(tree),
            -1,
            titles[i],
            renderer,
            "text", i,
            NULL
        );
    }

    /* 🔥 Charger les cours depuis le fichier */
    GList *cours_list = load_cours_from_file(g_cours_filepath);
    if (!cours_list) return;

    int total = 0;
    int disponibles = 0;
    int satures = 0;
    int total_places = 0;

    for (GList *l = cours_list; l; l = l->next) {
        cours *c = l->data;
        total++;
        total_places += c->nombre_de_places;

        if (strcmp(c->statut, "disponible") == 0)
            disponibles++;
        else
            satures++;
    }

    GtkTreeIter iter;
    char v[50], p[50];

    /* Total cours */
    gtk_list_store_append(store, &iter);
    sprintf(v, "%d", total);
    strcpy(p, "100%");
    gtk_list_store_set(store, &iter,
        0, "Total cours",
        1, v,
        2, "Nombre total de cours",
        3, p,
        -1);

    /* Cours disponibles */
    gtk_list_store_append(store, &iter);
    sprintf(v, "%d", disponibles);
    sprintf(p, total ? "%.1f%%" : "0%%", (float)disponibles / total * 100);
    gtk_list_store_set(store, &iter,
        0, "Cours disponibles",
        1, v,
        2, "Cours ouverts à l'inscription",
        3, p,
        -1);

    /* Cours saturés */
    gtk_list_store_append(store, &iter);
    sprintf(v, "%d", satures);
    sprintf(p, total ? "%.1f%%" : "0%%", (float)satures / total * 100);
    gtk_list_store_set(store, &iter,
        0, "Cours saturés",
        1, v,
        2, "Cours complets",
        3, p,
        -1);

    /* Total places */
    gtk_list_store_append(store, &iter);
    sprintf(v, "%d", total_places);
    strcpy(p, "-");
    gtk_list_store_set(store, &iter,
        0, "Total places",
        1, v,
        2, "Somme des places disponibles",
        3, p,
        -1);

    free_cours_list(cours_list);

    g_print("✔ Statistiques des cours affichées\n");
}
