#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "coach_requests.h"

/* Créer une nouvelle demande de coach */
CoachRequest* create_coach_request(const char *id_membre, const char *nom_coach,
                                   const char *date_seance, int heure, int minute)
{
    CoachRequest *request = (CoachRequest *)malloc(sizeof(CoachRequest));
    if (!request) {
        g_warning("Erreur : allocation mémoire échouée");
        return NULL;
    }

    /* Générer un ID unique basé sur le timestamp */
    time_t now = time(NULL);
    sprintf(request->id_demande, "REQ_%ld", now);

    strncpy(request->id_membre, id_membre, sizeof(request->id_membre) - 1);
    request->id_membre[sizeof(request->id_membre) - 1] = '\0';

    strncpy(request->nom_coach, nom_coach, sizeof(request->nom_coach) - 1);
    request->nom_coach[sizeof(request->nom_coach) - 1] = '\0';

    strncpy(request->date_seance, date_seance, sizeof(request->date_seance) - 1);
    request->date_seance[sizeof(request->date_seance) - 1] = '\0';

    request->heure_seance = heure;
    request->minute_seance = minute;

    strcpy(request->statut, "en attente");

    return request;
}

/* Ajouter une demande à la liste */
void add_coach_request_to_list(GList **list, CoachRequest *request)
{
    if (!request) {
        g_warning("Erreur : demande NULL");
        return;
    }
    *list = g_list_append(*list, request);
    g_print("✔ Demande de coach ajoutée : %s\n", request->id_demande);
}

/* Charger les demandes depuis le fichier */
void load_coach_requests_from_file(GList **list, const char *filepath)
{
    FILE *file = fopen(filepath, "r");
    if (!file) {
        g_print("⚠ Fichier %s non trouvé, création d'une nouvelle liste\n", filepath);
        return;
    }

    char line[512];
    while (fgets(line, sizeof(line), file)) {
        /* Ignorer les lignes vides */
        if (line[0] == '\n' || line[0] == '\0')
            continue;

        /* Supprimer le newline */
        line[strcspn(line, "\n")] = '\0';

        CoachRequest *request = (CoachRequest *)malloc(sizeof(CoachRequest));
        if (!request) {
            g_warning("Erreur : allocation mémoire échouée");
            continue;
        }

        /* Format : id_demande|id_membre|nom_coach|date_seance|heure|minute|statut */
        if (sscanf(line, "%49[^|]|%49[^|]|%99[^|]|%19[^|]|%d|%d|%19[^|]",
                   request->id_demande,
                   request->id_membre,
                   request->nom_coach,
                   request->date_seance,
                   &request->heure_seance,
                   &request->minute_seance,
                   request->statut) == 7) {
            *list = g_list_append(*list, request);
        } else {
            g_warning("⚠ Ligne invalide : %s", line);
            free(request);
        }
    }

    fclose(file);
    g_print("✔ %d demandes chargées depuis %s\n", g_list_length(*list), filepath);
}

/* Sauvegarder les demandes dans le fichier */
void save_coach_requests_to_file(GList *list, const char *filepath)
{
    FILE *file = fopen(filepath, "w");
    if (!file) {
        g_warning("Erreur : impossible d'ouvrir %s en écriture", filepath);
        return;
    }

    for (GList *iter = list; iter != NULL; iter = iter->next) {
        CoachRequest *request = (CoachRequest *)iter->data;
        fprintf(file, "%s|%s|%s|%s|%d|%d|%s\n",
                request->id_demande,
                request->id_membre,
                request->nom_coach,
                request->date_seance,
                request->heure_seance,
                request->minute_seance,
                request->statut);
    }

    fclose(file);
    g_print("✔ %d demandes sauvegardées dans %s\n", g_list_length(list), filepath);
}

/* Supprimer une demande de la liste */
void delete_coach_request_from_list(GList **list, const char *id_demande)
{
    for (GList *iter = *list; iter != NULL; iter = iter->next) {
        CoachRequest *request = (CoachRequest *)iter->data;
        if (strcmp(request->id_demande, id_demande) == 0) {
            *list = g_list_remove(*list, request);
            free(request);
            g_print("✔ Demande supprimée : %s\n", id_demande);
            return;
        }
    }
    g_warning("⚠ Demande non trouvée : %s", id_demande);
}

/* Libérer la mémoire d'une demande */
void free_coach_request(CoachRequest *request)
{
    if (request)
        free(request);
}

/* Libérer la mémoire de la liste complète */
void free_coach_requests_list(GList *list)
{
    for (GList *iter = list; iter != NULL; iter = iter->next) {
        free_coach_request((CoachRequest *)iter->data);
    }
    g_list_free(list);
}
