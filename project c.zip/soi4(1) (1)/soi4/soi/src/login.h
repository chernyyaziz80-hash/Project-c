/* login.h */
#ifndef LOGIN_H
#define LOGIN_H

/* 
 * identifiant : texte saisi dans la zone "Identifiant"
 * motdepasse  : texte saisi dans la zone "mot de passe"
 * resultat    : message à afficher dans le label (Bienvenue / erreur)
 */
void traiter_login(char identifiant[], char motdepasse[], char resultat[]);

#endif

