#ifndef CALLBACKS_H
#define CALLBACKS_H

#include <gtk/gtk.h>
void init_membre_event_requests_interface(GtkWidget *tree, const char *idMembre);



/* Fenêtres globales */
extern GtkWidget *WIN_ADMIN;  /* login_admin : onglets, tableau événements */
extern GtkWidget *WIN_AJOUT;  /* l_ajout_d__un___v__nement_ : formulaire */
extern GtkWidget *WIN_SIGN_UP;
extern GtkWidget *WIN_LOGIN;

void on_button_login_clicked(GtkWidget *objet_graphique, gpointer user_data);
void on_buttonOuvrirAjoutEvenement_clicked(GtkButton *button, gpointer user_data);
void on_buttonAjoutEvenement_clicked(GtkButton *button, gpointer user_data);
void on_evenement_cell_edited(GtkCellRendererText *renderer,
                              gchar *path_string,
                              gchar *new_text,
                              gpointer user_data);

void init_evenements_treeview(void);

/* Callbacks pour la gestion des membres */
void init_members_interface(void);
void on_button22_clicked(GtkButton *button, gpointer user_data);
void on_button23_clicked(GtkButton *button, gpointer user_data);
void on_button24_clicked(GtkButton *button, gpointer user_data);
void on_button25_clicked(GtkButton *button, gpointer user_data);
void on_button26_clicked(GtkButton *button, gpointer user_data);
void on_cell_edited(GtkCellRendererText *renderer, gchar *path_string,
                   gchar *new_text, gpointer user_data);
void on_btn_ajouter_form_clicked(GtkButton *button, gpointer user_data);
void on_btn_fermer_form_clicked(GtkButton *button, gpointer user_data);

/* Callbacks pour la demande de coach privé */
void on_button66_clicked(GtkButton *button, gpointer user_data);
void set_current_member_id(const char *member_id);
void init_coaches_interface(GtkWidget *tree);
void init_coach_requests_interface(GtkWidget *tree);
void init_coach_notifications_interface(GtkWidget *tree);
void init_coach_requests_for_trainers_interface(GtkWidget *tree);
void refresh_member_notifications(void);
void on_button_accepter_demande_clicked(GtkButton *button, gpointer user_data);
void on_button_refuser_demande_clicked(GtkButton *button, gpointer user_data);
void init_subscription_notifications_interface(GtkWidget *fixed46);

/* Callbacks pour la gestion des équipements */
void init_equipments_interface(GtkWidget *tree);
void on_button10_equipment_clicked(GtkButton *button, gpointer user_data);
void on_button11_equipment_clicked(GtkButton *button, gpointer user_data);
void on_button12_equipment_clicked(GtkButton *button, gpointer user_data);
void on_button13_equipment_clicked(GtkButton *button, gpointer user_data);
void on_equipment_cell_edited(GtkCellRendererText *renderer, gchar *path_string, gchar *new_text, gpointer user_data);

/* Callbacks pour la réservation d'équipements (entraineur) */
void init_equipment_reservation_interface(GtkWidget *fixed105);
void on_button_rechercher_equipements_entraineur_clicked(GtkButton *button, gpointer user_data);
void on_button_confirm_equipment_reservation_clicked(GtkButton *button, gpointer user_data);
void init_trainer_reservations_interface(GtkWidget *tree);
void init_admin_reservations_interface(GtkWidget *tree);
void init_reservations_interface(GtkWidget *tree);
void on_button_confirm_reservation_clicked(GtkButton *button, gpointer user_data);
void create_equipment_reservation_interface(GtkWidget *fixed105, GtkWidget *parent_window);

#endif

void on_button_signup_clicked               (GtkButton       *button,
                                        gpointer         user_data);
void on_button_back_to_login_clicked        (GtkButton       *button,
                                        gpointer         user_data);
void refresh_subscription_notifications(void);
void on_button36_clicked                    (GtkButton       *button,
                                        gpointer         user_data);
void init_centres_interface(GtkWidget *tree);
void on_button18_centres_clicked(GtkButton *button, gpointer user_data);
void on_button19_centres_clicked(GtkButton *button, gpointer user_data);
void on_button20_centres_clicked(GtkButton *button, gpointer user_data);
void on_button21_centres_clicked(GtkButton *button, gpointer user_data);
void on_centre_cell_edited(GtkCellRendererText *renderer, gchar *path_string, gchar *new_text, gpointer user_data);
void on_centre_form_ok_clicked(GtkButton *button, gpointer user_data);
void init_centres_interface_for_trainers(GtkWidget *tree);
void on_button68_clicked(GtkButton *button, gpointer user_data);
void init_trainer_centre_requests_interface(GtkWidget *tree, const char *trainer_id);
void init_trainer_centre_requests_on_startup(GtkWidget *tree, const char *trainer_id);
void init_centre_requests_for_admin_interface(GtkWidget *tree);
void on_button_accepter_centre_clicked(GtkButton *button, gpointer user_data);
void on_button_refuser_centre_clicked(GtkButton *button, gpointer user_data);
void prefixe_role(char role[], char prefixe[]);
void init_trainers_statistics_interface(GtkWidget *tree);
void on_button_valider_conseil_clicked(GtkButton *button, gpointer user_data);

/* Callbacks pour les boutons logout */
void on_button_logout_admin_clicked(GtkButton *button, gpointer user_data);
void on_button_logout_membres_clicked(GtkButton *button, gpointer user_data);
void on_button_logout_entraineurs_clicked(GtkButton *button, gpointer user_data);

void
on_buttonOpenSignup_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_faceid_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_faceid_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_rechercher_equipements_entraineur_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_rechercher_equipements_entraineur_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonSupprimerEvenement_clicked    (GtkButton       *button,
                                        gpointer         user_data);



void
on_buttonResetRecherche_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonRechercherId_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonInscrireEvenement_clicked     (GtkButton       *button,
                                        gpointer         user_data);


void
on_WindowMembre_show                   (GtkWidget       *widget,
                                        gpointer         user_data);

void
on_login_admin_show                    (GtkWidget       *widget,
                                        gpointer         user_data);


void on_buttonmodifiercours_clicked(GtkButton *button, gpointer user_data);

void on_buttonsupprimerc_clicked(GtkButton *button, gpointer user_data);

void on_buttonrecherchercours_clicked(GtkButton *button, gpointer user_data);

void on_buttonacceptecours_clicked(GtkButton *button, gpointer user_data);

void on_buttonrefusecours_clicked(GtkButton *button, gpointer user_data);

void on_buttoninscours_clicked(GtkButton *button, gpointer user_data);
void on_buttonajoutcours0_clicked(GtkWidget *objet, gpointer user_data);
void on_buttonajoutcours1_clicked(GtkButton *button, gpointer user_data);
void init_cours_statistics_interface(GtkWidget *tree);

