#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "centre_requests.h"

/* Charger les demandes depuis le fichier */
GList* load_centre_requests_from_file(const char *filename)
{
    FILE *file = fopen(filename, "r");
    if (!file) {
        g_warning("Impossible d'ouvrir le fichier %s", filename);
        return NULL;
    }

    GList *requests = NULL;
    char line[512];

    while (fgets(line, sizeof(line), file)) {
        /* Supprimer le saut de ligne */
        line[strcspn(line, "\n")] = 0;

        if (strlen(line) == 0) continue;

        /* Parser la ligne : id_demande|id_entraineur|id_centre|nom_centre|date_demande|statut */
        char id_demande[50], id_entraineur[50], id_centre[50], nom_centre[100], date_demande[20], statut[20];

        if (sscanf(line, "%49[^|]|%49[^|]|%49[^|]|%99[^|]|%19[^|]|%19[^\n]",
                   id_demande, id_entraineur, id_centre, nom_centre, date_demande, statut) == 6) {
            CentreRequest *request = create_centre_request(id_demande, id_entraineur, id_centre, nom_centre, date_demande, statut);
            add_centre_request_to_list(&requests, request);
        }
    }

    fclose(file);
    return requests;
}

/* Sauvegarder les demandes dans le fichier */
void save_centre_requests_to_file(GList *requests, const char *filename)
{
    FILE *file = fopen(filename, "w");
    if (!file) {
        g_warning("Impossible d'ouvrir le fichier %s en écriture", filename);
        return;
    }

    for (GList *iter = requests; iter != NULL; iter = iter->next) {
        CentreRequest *request = (CentreRequest *)iter->data;
        fprintf(file, "%s|%s|%s|%s|%s|%s\n",
                request->id_demande, request->id_entraineur, request->id_centre,
                request->nom_centre, request->date_demande, request->statut);
    }

    fclose(file);
}

/* Créer une nouvelle demande */
CentreRequest* create_centre_request(const char *id_demande, const char *id_entraineur, const char *id_centre, const char *nom_centre, const char *date_demande, const char *statut)
{
    CentreRequest *request = (CentreRequest *)malloc(sizeof(CentreRequest));
    if (!request) return NULL;

    strncpy(request->id_demande, id_demande, sizeof(request->id_demande) - 1);
    strncpy(request->id_entraineur, id_entraineur, sizeof(request->id_entraineur) - 1);
    strncpy(request->id_centre, id_centre, sizeof(request->id_centre) - 1);
    strncpy(request->nom_centre, nom_centre, sizeof(request->nom_centre) - 1);
    strncpy(request->date_demande, date_demande, sizeof(request->date_demande) - 1);
    strncpy(request->statut, statut, sizeof(request->statut) - 1);

    return request;
}

/* Ajouter une demande à la liste */
void add_centre_request_to_list(GList **requests, CentreRequest *request)
{
    if (!requests || !request) return;
    *requests = g_list_append(*requests, request);
}

/* Supprimer une demande de la liste */
void delete_centre_request_from_list(GList **requests, const char *id_demande)
{
    if (!requests || !id_demande) return;

    for (GList *iter = *requests; iter != NULL; iter = iter->next) {
        CentreRequest *request = (CentreRequest *)iter->data;
        if (strcmp(request->id_demande, id_demande) == 0) {
            *requests = g_list_remove(*requests, request);
            free(request);
            return;
        }
    }
}

/* Trouver une demande par ID */
CentreRequest* find_centre_request_by_id(GList *requests, const char *id_demande)
{
    if (!id_demande) return NULL;

    for (GList *iter = requests; iter != NULL; iter = iter->next) {
        CentreRequest *request = (CentreRequest *)iter->data;
        if (strcmp(request->id_demande, id_demande) == 0) {
            return request;
        }
    }

    return NULL;
}

/* Libérer la liste des demandes */
void free_centre_requests_list(GList *requests)
{
    for (GList *iter = requests; iter != NULL; iter = iter->next) {
        free(iter->data);
    }
    g_list_free(requests);
}
