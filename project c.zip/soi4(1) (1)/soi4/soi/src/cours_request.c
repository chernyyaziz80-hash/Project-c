#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "cours_request.h"

GList* load_cours_requests_from_file(const char *filename)
{
    FILE *f = fopen(filename, "r");
    if (!f) return NULL;

    GList *list = NULL;
    char line[512];

    while (fgets(line, sizeof(line), f)) {
        CoursRequest *r = malloc(sizeof(CoursRequest));
        if (!r) continue;

        if (sscanf(line, "%49[^|]|%49[^|]|%49[^|]|%99[^|]|%19[^|]|%19[^\n]",
                   r->id_demande,
                   r->id_membre,
                   r->id_cours,
                   r->nom_cours,
                   r->date_demande,
                   r->statut) == 6)
        {
            list = g_list_append(list, r);
        }
        else free(r);
    }

    fclose(f);
    return list;
}

void save_cours_requests_to_file(GList *requests, const char *filename)
{
    FILE *f = fopen(filename, "w");
    if (!f) return;

    for (GList *l = requests; l; l = l->next) {
        CoursRequest *r = l->data;
        fprintf(f, "%s|%s|%s|%s|%s|%s\n",
                r->id_demande,
                r->id_membre,
                r->id_cours,
                r->nom_cours,
                r->date_demande,
                r->statut);
    }
    fclose(f);
}

CoursRequest* create_cours_request(
    const char *id_demande,
    const char *id_membre,
    const char *id_cours,
    const char *nom_cours,
    const char *date_demande,
    const char *statut)
{
    CoursRequest *r = malloc(sizeof(CoursRequest));
    if (!r) return NULL;

    strcpy(r->id_demande, id_demande);
    strcpy(r->id_membre, id_membre);
    strcpy(r->id_cours, id_cours);
    strcpy(r->nom_cours, nom_cours);
    strcpy(r->date_demande, date_demande);
    strcpy(r->statut, statut);

    return r;
}

void add_cours_request_to_list(GList **requests, CoursRequest *request)
{
    *requests = g_list_append(*requests, request);
}

CoursRequest* find_cours_request_by_id(GList *requests, const char *id_demande)
{
    for (GList *l = requests; l; l = l->next) {
        CoursRequest *r = l->data;
        if (strcmp(r->id_demande, id_demande) == 0)
            return r;
    }
    return NULL;
}

void free_cours_requests_list(GList *requests)
{
    for (GList *l = requests; l; l = l->next)
        free(l->data);
    g_list_free(requests);
}
