#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "event.h"

/* =========================
   CREATE EVENT REQUEST
   ========================= */
EventRequest *create_event_request(
    const char *id_demande,
    const char *id_membre,
    const char *id_evenement,
    const char *nom_evenement,
    const char *date,
    const char *statut
) {
    EventRequest *req = malloc(sizeof(EventRequest));
    if (!req) return NULL;

    strcpy(req->id_demande, id_demande);
    strcpy(req->id_membre, id_membre);
    strcpy(req->id_evenement, id_evenement);
    strcpy(req->nom_evenement, nom_evenement);
    strcpy(req->date, date);
    strcpy(req->statut, statut);

    return req;
}

/* =========================
   SAVE TO FILE
   ========================= */
void save_event_requests_to_file(GList *list, const char *filename)
{
    FILE *f = fopen(filename, "w");
    if (!f) return;

    for (GList *l = list; l; l = l->next) {
        EventRequest *r = l->data;
        fprintf(f, "%s|%s|%s|%s|%s|%s\n",
            r->id_demande,
            r->id_membre,
            r->id_evenement,
            r->nom_evenement,
            r->date,
            r->statut
        );
    }
    fclose(f);
}

/* =========================
   LOAD FROM FILE
   ========================= */
GList *load_event_requests_from_file(const char *filename)
{
    FILE *f = fopen(filename, "r");
    if (!f) return NULL;

    GList *list = NULL;
    char line[512];

    while (fgets(line, sizeof(line), f)) {
        EventRequest *r = malloc(sizeof(EventRequest));
        if (!r) continue;

        sscanf(line, "%49[^|]|%49[^|]|%49[^|]|%99[^|]|%19[^|]|%19[^\n]",
            r->id_demande,
            r->id_membre,
            r->id_evenement,
            r->nom_evenement,
            r->date,
            r->statut
        );

        list = g_list_append(list, r);
    }
    fclose(f);
    return list;
}

/* =========================
   FREE LIST
   ========================= */
void free_event_requests_list(GList *list)
{
    g_list_free_full(list, free);
}


