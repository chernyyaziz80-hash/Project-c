#include <gtk/gtk.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "fichier.h"
#include "support.h"
extern GtkWidget *WIN_AJOUT;
GList *g_cours = NULL;
char g_cours_filepath[256] = "cours.txt";
char g_current_member_id[50] = "";
enum {
    ID_COURS,
    NOM_COURS,
    COACH,
    CENTRE,
    SALLE,
    DATE,
    HEURE,
    PRIX,
    NB_PLACES,
    STATUT,
    COLUMNS
};


/* ===== Enregistrer cours ===== */
void ajouter_cours(cours c)
{
    FILE *f = fopen("cours.txt", "a");
    if (f) {
        fprintf(f, "%d %s %s %s %s %s %s %.2f %d %s\n",
                c.identifiant, c.Nom, c.coach, c.centre, c.salle,
                c.date, c.heure, c.prix, c.nombre_de_places, c.statut);
        fclose(f);
    }
}

/* ===== Récupérer champs depuis ajoutcours ===== */
cours recuperer_saisie(GtkWidget *w)
{
    cours c;

    GtkWidget *entryid = lookup_widget(w, "entryidcours");
    GtkWidget *cb_nom = lookup_widget(w, "comboboxcours");
    GtkWidget *cb_coach = lookup_widget(w, "comboboxcoach");
    GtkWidget *cb_centre = lookup_widget(w, "comboboxcentre");
    GtkWidget *entrysalle = lookup_widget(w, "entrysalle");
    GtkWidget *entrydate = lookup_widget(w, "entrydate");
    GtkWidget *entryheure = lookup_widget(w, "entryheure");
    GtkWidget *entryprix = lookup_widget(w, "entryprix");
    GtkWidget *spin = lookup_widget(w, "spinbuttonplace");
    GtkWidget *dispo = lookup_widget(w, "checkbuttondispo");
    GtkWidget *sat = lookup_widget(w, "checkbuttonsat");

    c.identifiant = atoi(gtk_entry_get_text(GTK_ENTRY(entryid)));

    gchar *txt;
    txt = gtk_combo_box_get_active_text(GTK_COMBO_BOX(cb_nom));
    strcpy(c.Nom, txt ? txt : ""); g_free(txt);

    txt = gtk_combo_box_get_active_text(GTK_COMBO_BOX(cb_coach));
    strcpy(c.coach, txt ? txt : ""); g_free(txt);

    txt = gtk_combo_box_get_active_text(GTK_COMBO_BOX(cb_centre));
    strcpy(c.centre, txt ? txt : ""); g_free(txt);

    strcpy(c.salle, gtk_entry_get_text(GTK_ENTRY(entrysalle)));
    strcpy(c.date, gtk_entry_get_text(GTK_ENTRY(entrydate)));
    strcpy(c.heure, gtk_entry_get_text(GTK_ENTRY(entryheure)));
    c.prix = atof(gtk_entry_get_text(GTK_ENTRY(entryprix)));
    c.nombre_de_places = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin));

    if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(dispo)))
        strcpy(c.statut, "disponible");
    else
        strcpy(c.statut, "sature");
    
    if (strlen(c.Nom) == 0) strcpy(c.Nom, "Inconnu");
    if (strlen(c.coach) == 0) strcpy(c.coach, "Inconnu");
    if (strlen(c.centre) == 0) strcpy(c.centre, "Inconnu");
    if (strlen(c.statut) == 0) strcpy(c.statut, "disponible");


    return c;
}
GList* load_cours_from_file(const char *filename)
{
    FILE *file = fopen(filename, "r");
    if (!file) {
        g_warning("Impossible d'ouvrir le fichier %s", filename);
        return NULL;
    }

    GList *cours_list = NULL;
    cours temp;

    while (fscanf(file,
    "%d;%49[^;];%49[^;];%49[^;];%29[^;];%19[^;];%9[^;];%f;%d;%19[^\n]\n",
    &temp.identifiant,
    temp.Nom,
    temp.coach,
    temp.centre,
    temp.salle,
    temp.date,
    temp.heure,
    &temp.prix,
    &temp.nombre_de_places,
    temp.statut
    ) == 10)
    {
	cours *c = malloc(sizeof(cours));
	*c = temp;
	cours_list = g_list_append(cours_list, c);
	}

    fclose(file);
    return cours_list;
}
void save_cours_to_file(GList *cours_list, const char *filename)
{
    FILE *f = fopen(filename, "w");
    if (!f) return;

    for (GList *l = cours_list; l != NULL; l = l->next) {
        cours *c = (cours *)l->data;

        fprintf(f, "%d;%s;%s;%s;%s;%s;%s;%.2f;%d;%s\n",
            c->identifiant,
            c->Nom,
            c->coach,
            c->centre,
            c->salle,
            c->date,
            c->heure,
            c->prix,
            c->nombre_de_places,
            c->statut
        );
    }

    fclose(f);
}
void afficher_cours(GtkWidget *liste)
{
    GtkCellRenderer *renderer;
    GtkTreeViewColumn *column;
    GtkListStore *store;

    store = gtk_tree_view_get_model(GTK_TREE_VIEW(liste));

    if (store == NULL)
    {
        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("ID", renderer, "text", 0, NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("Nom", renderer, "text", 1, NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("Coach", renderer, "text", 2, NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("Centre", renderer, "text", 3, NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("Salle", renderer, "text", 4, NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("Date", renderer, "text", 5, NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("Heure", renderer, "text", 6, NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("Prix", renderer, "text", 7, NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("Places", renderer, "text", 8, NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("Statut", renderer, "text", 9, NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
    }

    store = gtk_list_store_new(10,
        G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,
        G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING
    );

    GtkTreeIter iter;

    for (GList *l = g_cours; l != NULL; l = l->next)
    {
        cours *c = l->data;
        char id[20], prix[20], places[20];

        sprintf(id, "%d", c->identifiant);
        sprintf(prix, "%.2f", c->prix);
        sprintf(places, "%d", c->nombre_de_places);

        gtk_list_store_append(store, &iter);
        gtk_list_store_set(store, &iter,
            0, id,
            1, c->Nom,
            2, c->coach,
            3, c->centre,
            4, c->salle,
            5, c->date,
            6, c->heure,
            7, prix,
            8, places,
            9, c->statut,
            -1
        );
    }

    gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
    g_object_unref(store);
}
void delete_cours_from_list(GList **cours_list, int id)
{
    if (!cours_list) return;

    for (GList *node = *cours_list; node; node = node->next)
    {
        cours *c = (cours *)node->data;

        if (c->identifiant == id)
        {
            free(c);
            *cours_list = g_list_remove(*cours_list, c);
            return;
        }
    }
}
cours* find_cours_by_id(GList *cours_list, int id)
{
    for (GList *l = cours_list; l != NULL; l = l->next) {
        cours *c = (cours *)l->data;
        if (c->identifiant == id)
            return c;
    }
    return NULL;
}
void init_cours_choix_interface(GtkWidget *tree)
{
    GtkListStore *store;
    GtkTreeIter iter;

    if (!tree) return;

    /* Supprimer anciennes colonnes (GTK2 safe) */
    GtkTreeViewColumn *col;
    while ((col = gtk_tree_view_get_column(GTK_TREE_VIEW(tree), 0)) != NULL) {
        gtk_tree_view_remove_column(GTK_TREE_VIEW(tree), col);
    }

    store = gtk_list_store_new(3,
        G_TYPE_STRING,  /* ID */
        G_TYPE_STRING,  /* Nom */
        G_TYPE_STRING   /* Coach */
    );

    gtk_tree_view_set_model(GTK_TREE_VIEW(tree), GTK_TREE_MODEL(store));
    g_object_unref(store);

    GtkCellRenderer *renderer;
    const char *titles[] = {"ID", "Cours", "Coach"};

    for (int i = 0; i < 3; i++) {
        renderer = gtk_cell_renderer_text_new();
        gtk_tree_view_insert_column_with_attributes(
            GTK_TREE_VIEW(tree),
            -1,
            titles[i],
            renderer,
            "text", i,
            NULL
        );
    }

    /* Charger les cours depuis fichier */
    FILE *f = fopen("cours.txt", "r");
    if (!f) {
        g_warning("cours.txt introuvable !");
        return;
    }

    char id[50], nom[100], coach[100];
    while (fscanf(f, "%49[^;];%99[^;];%99[^\n]\n", id, nom, coach) == 3) {
        gtk_list_store_append(store, &iter);
        gtk_list_store_set(store, &iter,
            0, id,
            1, nom,
            2, coach,
            -1
        );
    }

    fclose(f);
}
void free_cours_list(GList *list)
{
    for (GList *l = list; l != NULL; l = l->next) {
        free(l->data);   // libère chaque cours
    }
    g_list_free(list);   // libère la liste
}
