#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <gtk/gtk.h>
#include "members.h"
#include "callbacks.h"

/* Charger les membres depuis le fichier */
GList* load_members_from_file(const char *filename)
{
    GList *members = NULL;
    FILE *file = fopen(filename, "r");
    
    if (!file) {
        g_warning("Impossible d'ouvrir le fichier %s", filename);
        return NULL;
    }
    
    char line[256];
    while (fgets(line, sizeof(line), file)) {
        /* Supprimer le retour à la ligne */
        line[strcspn(line, "\n")] = 0;
        
        if (strlen(line) == 0) continue;
        
        int age;
        char username[50], nom[100], prenom[100], sexe[20], telephone[20], date_signup[20];
        
        /* Parser la ligne : Username|Nom|Prénom|Sexe|Age|Téléphone|DateSignup */
        int parsed = sscanf(line, "%49[^|]|%99[^|]|%99[^|]|%19[^|]|%d|%19[^|]|%19[^|]",
                   username, nom, prenom, sexe, &age, telephone, date_signup);
        
        if (parsed >= 6) {
            Member *member = create_member(username, nom, prenom, sexe, age, telephone);
            if (parsed == 7) {
                strncpy(member->date_signup, date_signup, sizeof(member->date_signup) - 1);
                member->date_signup[sizeof(member->date_signup) - 1] = '\0';
            }
            members = g_list_append(members, member);
        }
    }
    
    fclose(file);
    return members;
}

/* Sauvegarder les membres dans le fichier */
void save_members_to_file(GList *members, const char *filename)
{
    FILE *file = fopen(filename, "w");
    
    if (!file) {
        g_warning("Impossible d'écrire dans le fichier %s", filename);
        return;
    }
    
    for (GList *node = members; node; node = node->next) {
        Member *member = (Member *)node->data;
        fprintf(file, "%s|%s|%s|%s|%d|%s|%s\n",
                member->username, member->nom, member->prenom,
                member->sexe, member->age, member->telephone, member->date_signup);
    }
    
    fclose(file);
}

/* Créer un nouveau membre */
Member* create_member(const char *username, const char *nom, const char *prenom, 
                     const char *sexe, int age, const char *telephone)
{
    Member *member = (Member *)malloc(sizeof(Member));
    if (!member) return NULL;
    
    strncpy(member->username, username, sizeof(member->username) - 1);
    member->username[sizeof(member->username) - 1] = '\0';
    
    strncpy(member->nom, nom, sizeof(member->nom) - 1);
    member->nom[sizeof(member->nom) - 1] = '\0';
    
    strncpy(member->prenom, prenom, sizeof(member->prenom) - 1);
    member->prenom[sizeof(member->prenom) - 1] = '\0';
    
    strncpy(member->sexe, sexe, sizeof(member->sexe) - 1);
    member->sexe[sizeof(member->sexe) - 1] = '\0';
    
    member->age = age;
    
    strncpy(member->telephone, telephone, sizeof(member->telephone) - 1);
    member->telephone[sizeof(member->telephone) - 1] = '\0';
    
    /* Initialiser date_signup avec la date actuelle au format DD/MM/YYYY */
    time_t now = time(NULL);
    struct tm *timeinfo = localtime(&now);
    strftime(member->date_signup, sizeof(member->date_signup), "%d/%m/%Y", timeinfo);
    
    return member;
}

/* Ajouter un membre à la liste */
void add_member_to_list(GList **members, Member *member)
{
    if (members && member) {
        *members = g_list_append(*members, member);
    }
}

/* Supprimer un membre de la liste par username */
void delete_member_from_list(GList **members, const char *username)
{
    if (!members) return;
    
    for (GList *node = *members; node; node = node->next) {
        Member *member = (Member *)node->data;
        if (strcmp(member->username, username) == 0) {
            free(member);
            *members = g_list_remove(*members, member);
            return;
        }
    }
}

/* Trouver un membre par username */
Member* find_member_by_username(GList *members, const char *username)
{
    for (GList *node = members; node; node = node->next) {
        Member *member = (Member *)node->data;
        if (strcmp(member->username, username) == 0) {
            return member;
        }
    }
    return NULL;
}

/* Libérer la mémoire de la liste */
void free_members_list(GList *members)
{
    for (GList *node = members; node; node = node->next) {
        free(node->data);
    }
    g_list_free(members);
}

/* Initialiser le TreeView avec les colonnes */
void init_members_treeview(GtkWidget *tree)
{
    if (!tree || !GTK_IS_TREE_VIEW(tree)) {
        g_warning("TreeView invalide");
        return;
    }
    
    /* Si un modèle existe déjà, ne pas recréer */
    if (gtk_tree_view_get_model(GTK_TREE_VIEW(tree)) != NULL)
        return;
    
    /* Modèle : 6 colonnes en texte */
    GtkListStore *store = gtk_list_store_new(
        6,
        G_TYPE_STRING,   /* 0 : ID       */
        G_TYPE_STRING,   /* 1 : Nom      */
        G_TYPE_STRING,   /* 2 : Prénom   */
        G_TYPE_STRING,   /* 3 : Sexe     */
        G_TYPE_STRING,   /* 4 : Age      */
        G_TYPE_STRING    /* 5 : Téléphone */
    );
    
    gtk_tree_view_set_model(GTK_TREE_VIEW(tree), GTK_TREE_MODEL(store));
    g_object_unref(store);
    
    /* Création des colonnes visibles */
    GtkCellRenderer *renderer;
    const char *titles[6] = {"ID", "Nom", "Prénom", "Sexe", "Age", "Téléphone"};
    
    for (int i = 0; i < 6; ++i) {
        renderer = gtk_cell_renderer_text_new();
        
        /* Rendre les cellules éditables (sauf ID) */
        if (i > 0) {
            g_object_set(renderer, "editable", TRUE, NULL);
            /* Connecter le signal d'édition */
            g_signal_connect(renderer, "edited",
                           G_CALLBACK(on_cell_edited),
                           GINT_TO_POINTER(i));
        }
        
        GtkTreeViewColumn *column = gtk_tree_view_column_new_with_attributes(
            titles[i],
            renderer,
            "text", i,
            NULL
        );
        
        gtk_tree_view_append_column(GTK_TREE_VIEW(tree), column);
    }
}

/* Remplir le TreeView avec les données */
void populate_treeview_from_list(GtkWidget *tree, GList *members)
{
    if (!tree || !GTK_IS_TREE_VIEW(tree)) {
        g_warning("TreeView invalide");
        return;
    }
    
    GtkTreeModel *model = gtk_tree_view_get_model(GTK_TREE_VIEW(tree));
    if (!model) {
        g_warning("Modèle du TreeView non initialisé");
        return;
    }
    
    GtkListStore *store = GTK_LIST_STORE(model);
    GtkTreeIter iter;
    char age_str[10];
    
    for (GList *node = members; node; node = node->next) {
        Member *member = (Member *)node->data;
        
        sprintf(age_str, "%d", member->age);
        
        gtk_list_store_append(store, &iter);
        gtk_list_store_set(store, &iter,
                          0, member->username,
                          1, member->nom,
                          2, member->prenom,
                          3, member->sexe,
                          4, age_str,
                          5, member->telephone,
                          -1);
    }
}

/* Vider le TreeView */
void clear_treeview(GtkWidget *tree)
{
    if (!tree || !GTK_IS_TREE_VIEW(tree)) {
        g_warning("TreeView invalide");
        return;
    }
    
    GtkTreeModel *model = gtk_tree_view_get_model(GTK_TREE_VIEW(tree));
    if (model && GTK_IS_LIST_STORE(model)) {
        gtk_list_store_clear(GTK_LIST_STORE(model));
    }
}
