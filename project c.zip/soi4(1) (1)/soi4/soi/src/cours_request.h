#ifndef COURS_REQUEST_H
#define COURS_REQUEST_H

#include <gtk/gtk.h>

typedef struct {
    char id_demande[50];
    char id_membre[50];
    char id_cours[50];
    char nom_cours[100];
    char date_demande[20];
    char statut[20];  /* en attente | acceptée | refusée */
} CoursRequest;

/* CRUD */
GList* load_cours_requests_from_file(const char *filename);
void save_cours_requests_to_file(GList *requests, const char *filename);

CoursRequest* create_cours_request(
    const char *id_demande,
    const char *id_membre,
    const char *id_cours,
    const char *nom_cours,
    const char *date_demande,
    const char *statut
);

void add_cours_request_to_list(GList **requests, CoursRequest *request);
CoursRequest* find_cours_request_by_id(GList *requests, const char *id_demande);
void free_cours_requests_list(GList *requests);

#endif
