#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "interface.h"
#include "support.h"
#include "callbacks.h"
#include "fichier.h"
/* Déclarations externes */
extern GtkWidget* create_ajout_d_un_centre(void);

/* 🔥 FENÊTRES GLOBALES */
GtkWidget *WIN_SIGN_UP = NULL;
GtkWidget *WIN_LOGIN   = NULL;
GtkWidget *WIN_ADMIN   = NULL;
GtkWidget *WIN_AJOUT   = NULL;
GtkWidget *WIN_ENTRAINEUR = NULL;
GtkWidget *WIN_MEMBRE = NULL;
GtkWidget *WIN_AJOUT_CENTRE = NULL;

int main (int argc, char *argv[])
{
    gtk_set_locale();
    gtk_init(&argc, &argv);

    add_pixmap_directory("../pixmaps");

    WIN_SIGN_UP = create_sign_up();
    WIN_LOGIN   = create_login();
    WIN_AJOUT_CENTRE = create_ajout_d_un_centre();

    /* =====================
     * 🎨 LOGIN STYLE NUDE
     * ===================== */
    {
        GdkColor nude_bg;
        gdk_color_parse("#F5E9DF", &nude_bg);
        gtk_widget_modify_bg(WIN_LOGIN, GTK_STATE_NORMAL, &nude_bg);

        gtk_container_set_border_width(GTK_CONTAINER(WIN_LOGIN), 20);

        /* 🔠 TITRE LOGIN : plus petit (24 px) */
        GtkWidget *label = lookup_widget(WIN_LOGIN, "labelTitre");
        if (label != NULL)
        {
            GdkColor brun;
            gdk_color_parse("#6A5246", &brun);
            gtk_widget_modify_fg(label, GTK_STATE_NORMAL, &brun);

            PangoFontDescription *font =
                pango_font_description_from_string("Serif Bold 30");  // ⭐ plus petit
            gtk_widget_modify_font(label, font);
            pango_font_description_free(font);
        }

        /* BOUTON LOGIN */
        GtkWidget *btn_login = lookup_widget(WIN_LOGIN, "on_button_login_clicked");
        if (btn_login != NULL)
        {
            GdkColor caramel;
            gdk_color_parse("#D8C3B3", &caramel);
            gtk_widget_modify_bg(btn_login, GTK_STATE_NORMAL, &caramel);

            GdkColor brun_fonce;
            gdk_color_parse("#4A3F35", &brun_fonce);
            gtk_widget_modify_fg(btn_login, GTK_STATE_NORMAL, &brun_fonce);

            PangoFontDescription *fontbtn =
                pango_font_description_from_string("Sans Bold 18");
            gtk_widget_modify_font(btn_login, fontbtn);
            pango_font_description_free(fontbtn);
        }
      gboolean hide_scan_and_show_login(GtkWidget *login)
    {
      GtkWidget *scan = lookup_widget(login, "scan_box");
      gtk_widget_hide(scan);  // cacher l'animation

      GtkWidget *form = lookup_widget(login, "zone_formulaire_login");
      gtk_widget_show_all(form);

      return FALSE; // une seule exécution
}

// lancer le scan pendant 1.5 secondes
g_timeout_add(1500, (GSourceFunc)hide_scan_and_show_login, WIN_LOGIN);

    }

    /* ======================
     * 🎨 SIGN UP STYLE NUDE
     * ====================== */
    {
        GdkColor nude_bg;
        gdk_color_parse("#F5E9DF", &nude_bg);
        gtk_widget_modify_bg(WIN_SIGN_UP, GTK_STATE_NORMAL, &nude_bg);

        /* TITRE SIGNUP : plus petit aussi (24 px) */
        GtkWidget *label_su = lookup_widget(WIN_SIGN_UP, "label523");
        if (label_su != NULL)
        {
            GdkColor brun;
            gdk_color_parse("#6A5246", &brun);
            gtk_widget_modify_fg(label_su, GTK_STATE_NORMAL, &brun);

            PangoFontDescription *font =
                pango_font_description_from_string("Serif Bold 8");
            gtk_widget_modify_font(label_su, font);
            pango_font_description_free(font);
        }

        /* Bouton S'inscrire */
        GtkWidget *btn_su = lookup_widget(WIN_SIGN_UP, "button_signup");
        if (btn_su != NULL)
        {
            GdkColor caramel;
            gdk_color_parse("#D8C3B3", &caramel);
            gtk_widget_modify_bg(btn_su, GTK_STATE_NORMAL, &caramel);

            GdkColor brun_fonce;
            gdk_color_parse("#4A3F35", &brun_fonce);
            gtk_widget_modify_fg(btn_su, GTK_STATE_NORMAL, &brun_fonce);

            PangoFontDescription *fontbtn =
                pango_font_description_from_string("Sans Bold 18");
            gtk_widget_modify_font(btn_su, fontbtn);
            pango_font_description_free(fontbtn);
        }
    }

    gtk_widget_show_all(WIN_SIGN_UP);

    gtk_main();
    return 0;
}
