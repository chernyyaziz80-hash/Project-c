#ifndef MEMBERS_H
#define MEMBERS_H

#include <gtk/gtk.h>

/* Structure pour un membre */
typedef struct {
    char username[50];
    char nom[100];
    char prenom[100];
    char sexe[20];
    int age;
    char telephone[20];
    char date_signup[20];  /* Format: DD/MM/YYYY */
} Member;

/* Fonctions CRUD */
GList* load_members_from_file(const char *filename);
void save_members_to_file(GList *members, const char *filename);
Member* create_member(const char *username, const char *nom, const char *prenom, const char *sexe, int age, const char *telephone);
void add_member_to_list(GList **members, Member *member);
void delete_member_from_list(GList **members, const char *username);
Member* find_member_by_username(GList *members, const char *username);
void free_members_list(GList *members);

/* Fonctions pour le TreeView */
void init_members_treeview(GtkWidget *tree);
void populate_treeview_from_list(GtkWidget *tree, GList *members);
void clear_treeview(GtkWidget *tree);

#endif
