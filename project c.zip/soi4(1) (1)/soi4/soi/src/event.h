#ifndef EVENT_H
#define EVENT_H

#include <glib.h>

/* =========================
   STRUCTURE EVENT REQUEST
   ========================= */
typedef struct {
    char id_demande[50];
    char id_membre[50];
    char id_evenement[50];
    char nom_evenement[100];
    char date[20];
    char statut[20];
} EventRequest;

/* =========================
   FONCTIONS
   ========================= */
EventRequest *create_event_request(
    const char *id_demande,
    const char *id_membre,
    const char *id_evenement,
    const char *nom_evenement,
    const char *date,
    const char *statut
);

void save_event_requests_to_file(GList *list, const char *filename);
GList *load_event_requests_from_file(const char *filename);
void free_event_requests_list(GList *list);

#endif

