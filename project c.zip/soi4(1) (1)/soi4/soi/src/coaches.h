#ifndef COACHES_H
#define COACHES_H

#include <glib.h>

typedef struct {
    char id[50];              /* ID unique du coach */
    char nom[100];            /* Nom du coach */
    char specialite[100];     /* Spécialité (Musculation, Yoga, etc.) */
    char disponibilite[200];  /* Disponibilité (Lun-Mer 08:00-12:00) */
    char telephone[20];       /* Numéro de téléphone */
} Coach;

/* Fonctions CRUD */
Coach* create_coach(const char *id, const char *nom, const char *specialite,
                   const char *disponibilite, const char *telephone);
void add_coach_to_list(GList **list, Coach *coach);
void load_coaches_from_file(GList **list, const char *filepath);
void free_coach(Coach *coach);
void free_coaches_list(GList *list);

#endif
